"""Tests fuer Schema, Jahrespflicht-Logik und Datenmodell.

Diese Tests pruefen die Cyclus-1-Aenderungen:
  1. Neue Excel-Spalten: GF, Dienstkleidung Groesse, CBRN Kleidergroesse
  2. Jahrespflicht: "ausstehend" statt "Angabe fehlt" bei fehlendem Datum
  3. SQLite-Modell: Bemerkungsfeld im Helferzusatz
  4. Kompatibilitaet: ERWARTETE_SPALTEN enthaelt alle neuen Spalten
"""

from __future__ import annotations

import sys
from datetime import date, datetime
from pathlib import Path

import pytest

# Das Projektverzeichnis in den Pfad aufnehmen.
PROJEKT = Path(__file__).resolve().parent.parent
if str(PROJEKT) not in sys.path:
    sys.path.insert(0, str(PROJEKT))

from app.dateizugriff.schema import (
    AUSWAHLWERTE,
    ERWARTETE_SPALTEN,
    FELDARTEN,
    Feldart,
    Person,
    Personenschluessel,
    SPALTE_CBRN_GROESSE,
    SPALTE_DIENSTKLEIDUNG_GROESSE,
    SPALTE_GF,
    GF_NIKLAS,
    GF_NINO,
    GF_WERTE,
)
from app.logic.jahrespflicht import (
    Jahresbefund,
    Jahreslage,
    PFLICHTEN,
    Pflicht,
    beurteile,
    befunde_fuer,
)
from app.logic.werte import Zustand
from app.models import Helferzusatz


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------

def _person(spalten: dict) -> Person:
    """Baut eine Test-Person aus einem Spaltenwerte-Dictionary."""
    return Person(
        schluessel=Personenschluessel("Gruppe 1", 2, spalten.get("Name", "Test")),
        werte=spalten,
    )


def _pflicht(zielgruppe: str = "alle") -> Pflicht:
    return Pflicht("Jahresgespräch", "Jahresgespräch", zielgruppe)


# ===========================================================================
# 1. Schema: Neue Excel-Spalten
# ===========================================================================

class TestNeueSpalten:
    """Prueft, dass die neuen Spalten korrekt im Schema registriert sind."""

    def test_gf_in_erwartete_spalten(self):
        assert SPALTE_GF in ERWARTETE_SPALTEN

    def test_dienstkleidung_groesse_in_erwartete_spalten(self):
        assert SPALTE_DIENSTKLEIDUNG_GROESSE in ERWARTETE_SPALTEN

    def test_cbrn_groesse_in_erwartete_spalten(self):
        assert SPALTE_CBRN_GROESSE in ERWARTETE_SPALTEN

    def test_gf_ist_auswahl(self):
        assert FELDARTEN[SPALTE_GF] is Feldart.AUSWAHL

    def test_dienstkleidung_groesse_ist_text(self):
        assert FELDARTEN[SPALTE_DIENSTKLEIDUNG_GROESSE] is Feldart.TEXT

    def test_cbrn_groesse_ist_text(self):
        assert FELDARTEN[SPALTE_CBRN_GROESSE] is Feldart.TEXT

    def test_gf_auswahlwerte_enthalten_niklas(self):
        assert GF_NIKLAS in AUSWAHLWERTE[SPALTE_GF]

    def test_gf_auswahlwerte_enthalten_nino(self):
        assert GF_NINO in AUSWAHLWERTE[SPALTE_GF]

    def test_gf_werte_sind_korrekt(self):
        assert GF_WERTE == (GF_NIKLAS, GF_NINO)

    def test_neue_spalten_am_ende_von_erwartete_spalten(self):
        """Die neuen Spalten haengen hinten an, wie bei der Migration ueblich."""
        idx_gf = ERWARTETE_SPALTEN.index(SPALTE_GF)
        idx_kleid = ERWARTETE_SPALTEN.index(SPALTE_DIENSTKLEIDUNG_GROESSE)
        idx_cbrn = ERWARTETE_SPALTEN.index(SPALTE_CBRN_GROESSE)
        assert idx_gf < idx_kleid < idx_cbrn
        # Alle drei sind die letzten drei Spalten.
        assert ERWARTETE_SPALTEN[-3:] == (SPALTE_GF, SPALTE_DIENSTKLEIDUNG_GROESSE, SPALTE_CBRN_GROESSE)

    def test_person_liest_gf_aus_werten(self):
        p = _person({"Name": "Test", SPALTE_GF: "Niklas"})
        assert p.wert(SPALTE_GF) == "Niklas"

    def test_person_liest_kleidung_groesse(self):
        p = _person({"Name": "Test", SPALTE_DIENSTKLEIDUNG_GROESSE: "M"})
        assert p.wert(SPALTE_DIENSTKLEIDUNG_GROESSE) == "M"

    def test_person_liest_cbrn_groesse(self):
        p = _person({"Name": "Test", SPALTE_CBRN_GROESSE: "L/CBRN"})
        assert p.wert(SPALTE_CBRN_GROESSE) == "L/CBRN"


# ===========================================================================
# 2. Jahrespflicht-Logik: ausstehend statt Angabe fehlt
# ===========================================================================

class TestJahrespflichtAusstehend:
    """Prueft die geaenderte Jahrespflicht-Bewertung."""

    def test_aktuelles_jahr_erledigt(self):
        p = _person({"Jahresgespräch": date(2026, 6, 15), "Führerschein": "B"})
        ergebnis = beurteile(PFLICHTEN[1], p, date(2026, 9, 1))
        assert ergebnis.lage is Jahreslage.ERLEDIGT
        assert ergebnis.hat_datum is True

    def test_aelteres_jahr_faellig_mit_datum(self):
        p = _person({"Jahresgespräch": date(2025, 3, 10), "Führerschein": "B"})
        ergebnis = beurteile(PFLICHTEN[1], p, date(2026, 9, 1))
        assert ergebnis.lage is Jahreslage.FAELLIG
        assert ergebnis.hat_datum is True
        assert ergebnis.ausstehend is False
        assert "Zuletzt am" in ergebnis.hinweis

    def test_leer_ist_ausstehend(self):
        p = _person({"Jahresgespräch": None, "Führerschein": "B"})
        ergebnis = beurteile(PFLICHTEN[1], p, date(2026, 9, 1))
        assert ergebnis.lage is Jahreslage.FAELLIG
        assert ergebnis.hat_datum is False
        assert ergebnis.ausstehend is True

    def test_n_ist_ausstehend(self):
        p = _person({"Jahresgespräch": "n", "Führerschein": "B"})
        ergebnis = beurteile(PFLICHTEN[1], p, date(2026, 9, 1))
        assert ergebnis.lage is Jahreslage.FAELLIG
        assert ergebnis.hat_datum is False
        assert ergebnis.ausstehend is True

    def test_freitext_y_ist_ausstehend_nicht_unklar(self):
        """Der Kern der Aenderung: y/HA/angemeldet erzeugen FAELLIG statt UNKLAR."""
        p = _person({"Jahresgespräch": "y", "Führerschein": "B"})
        ergebnis = beurteile(PFLICHTEN[1], p, date(2026, 9, 1))
        assert ergebnis.lage is Jahreslage.FAELLIG
        assert ergebnis.hat_datum is False
        assert ergebnis.ausstehend is True
        assert "y" in ergebnis.rohwert

    def test_freitext_ha_ist_ausstehend(self):
        p = _person({"Jahresgespräch": "HA", "Führerschein": "B"})
        ergebnis = beurteile(PFLICHTEN[1], p, date(2026, 9, 1))
        assert ergebnis.lage is Jahreslage.FAELLIG
        assert ergebnis.ausstehend is True

    def test_freitext_angemeldet_ist_ausstehend(self):
        p = _person({"Jahresgespräch": "angemeldet", "Führerschein": "B"})
        ergebnis = beurteile(PFLICHTEN[1], p, date(2026, 9, 1))
        assert ergebnis.lage is Jahreslage.FAELLIG
        assert ergebnis.ausstehend is True

    def test_rs_fortbildung_ausstehend_bei_text(self):
        """Auch RS-Fortbildung: Text statt Datum -> ausstehend."""
        p = _person({"Medizinisch": "RS", "RS Fortbildung": "HA"})
        ergebnis = beurteile(PFLICHTEN[0], p, date(2026, 9, 1))
        assert ergebnis.lage is Jahreslage.FAELLIG
        assert ergebnis.ausstehend is True

    def test_unterweisung_ausstehend_bei_text(self):
        """Auch Unterweisung SuW: Text statt Datum -> ausstehend."""
        p = _person({"Führerschein": "B", "Unterweisung S/W-Rechte": "y"})
        ergebnis = beurteile(PFLICHTEN[2], p, date(2026, 9, 1))
        assert ergebnis.lage is Jahreslage.FAELLIG
        assert ergebnis.ausstehend is True

    def test_nicht_betroffen_bleibt_nicht_noetig(self):
        p = _person({"Medizinisch": "NotSan", "Führerschein": ""})
        # RS-Fortbildung: Medizinisch ohne RS -> NEIN
        from app.logic.werte import hat_qualifikation_rs
        assert hat_qualifikation_rs("NotSan").zustand is Zustand.NEIN
        ergebnis = beurteile(PFLICHTEN[0], p, date(2026, 9, 1))
        assert ergebnis.lage is Jahreslage.NICHT_NOETIG

    def test_fehlende_angabe_zielgruppe_bleibt_unklar(self):
        """Wenn die Zielgruppen-Angabe fehlt (Medizinisch leer), bleibt es UNKLAR."""
        p = _person({"Medizinisch": "", "Führerschein": "B"})
        ergebnis = beurteile(PFLICHTEN[0], p, date(2026, 9, 1))
        assert ergebnis.lage is Jahreslage.UNKLAR
        assert "fehlt" in ergebnis.hinweis.lower()

    def test_befunde_fuer_liste_ausstehend(self):
        """Alle drei Pflichten als ausstehend, wenn kein Datum eingetragen."""
        p = _person({
            "Medizinisch": "RS",
            "RS Fortbildung": "y",
            "Jahresgespräch": "HA",
            "Führerschein": "B",
            "Unterweisung S/W-Rechte": "angemeldet",
        })
        befunde = befunde_fuer(p, date(2026, 9, 1))
        assert len(befunde) == 3
        for b in befunde:
            assert b.lage is Jahreslage.FAELLIG
            assert b.ausstehend is True

    def test_mixed_aktuelles_und_ausstehend(self):
        """Eine Pflicht erledigt, eine ausstehend."""
        p = _person({
            "Medizinisch": "RS",
            "RS Fortbildung": date(2026, 3, 1),
            "Jahresgespräch": "y",
            "Führerschein": "B",
            "Unterweisung S/W-Rechte": "",
        })
        befunde = befunde_fuer(p, date(2026, 9, 1))
        lagen = {b.pflicht.bezeichnung: b.lage for b in befunde}
        assert lagen["RS-Fortbildung"] is Jahreslage.ERLEDIGT
        assert lagen["Jahresgespräch"] is Jahreslage.FAELLIG
        # Unterweisung SuW: leer -> auch FAELLIG (ausstehend)
        assert lagen["Unterweisung Sonder- und Wegerechte"] is Jahreslage.FAELLIG


# ===========================================================================
# 3. Datenmodell: Bemerkungsfeld
# ===========================================================================

class TestHelferzusatzBemerkung:
    """Prueft, dass das Bemerkungsfeld korrekt im Modell existiert."""

    def test_bemerkung_spalte_vorhanden(self):
        spalten = {c.name for c in Helferzusatz.__table__.columns}
        assert "bemerkung" in spalten

    def test_bemerkung_ist_optional(self):
        """Die Spalte darf None enthalten (Mapped[str | None])."""
        from sqlalchemy import inspect
        mapper = inspect(Helferzusatz)
        bemerkung_col = mapper.columns.bemerkung
        assert bemerkung_col.nullable is True

    def test_bemerkung_ist_text_typ(self):
        """Die Spalte ist ein Text-Typ (langer String)."""
        from sqlalchemy import inspect
        mapper = inspect(Helferzusatz)
        bemerkung_col = mapper.columns.bemerkung
        from sqlalchemy import Text as SqlText
        assert isinstance(bemerkung_col.type, SqlText)


# ===========================================================================
# 4. Kompatibilitaet: Excel-Schema-Vollstaendigkeit
# ===========================================================================

class TestSchemaKompatibilitaet:
    """Prueft, dass alle noetigen Spalten vorhanden und konsistent sind."""

    def test_alle_feldarten_auch_fuer_neue_spalten(self):
        """Jede neue Spalte hat einen FELDARTEN-Eintrag."""
        for spalte in (SPALTE_GF, SPALTE_DIENSTKLEIDUNG_GROESSE, SPALTE_CBRN_GROESSE):
            assert spalte in FELDARTEN, f"Feldart fehlt fuer {spalte}"

    def test_gf_hat_auswahlwerte(self):
        assert SPALTE_GF in AUSWAHLWERTE
        assert len(AUSWAHLWERTE[SPALTE_GF]) == 2

    def test_keine_duplikate_in_erwartete_spalten(self):
        assert len(ERWARTETE_SPALTEN) == len(set(ERWARTETE_SPALTEN))

    def test_erkennung_als_auswahl_fuer_gf(self):
        """Das Formular erkennt GF als Auswahl-Feld."""
        feld = {
            "spalte": SPALTE_GF,
            "art": FELDARTEN[SPALTE_GF].value,
            "ist_ja_nein": FELDARTEN[SPALTE_GF] is Feldart.JA_NEIN,
            "ist_auswahl": FELDARTEN[SPALTE_GF] is Feldart.AUSWAHL,
        }
        assert feld["ist_auswahl"] is True
        assert feld["ist_ja_nein"] is False

    def test_erkennung_als_text_fuer_groessen(self):
        """Dienstkleidung und CBRN Groesse sind reine Textfelder."""
        for spalte in (SPALTE_DIENSTKLEIDUNG_GROESSE, SPALTE_CBRN_GROESSE):
            assert FELDARTEN[spalte] is Feldart.TEXT
