"""Tests der SharePoint-Synchronisation ueber Microsoft Graph.

Microsoft Graph wird mit einem MockTransport nachgestellt - es geht kein
Aufruf ins Netz. Abgedeckt sind der erfolgreiche Abgleich, die Erneuerung
eines abgelaufenen Tokens, Anmeldefehler, der eTag-Konflikt (412) und der
Offline-Fallback.

Zum Aufbau der Antworten wird eine kleine Excel-Datei im Speicher gebaut,
die das selbe Blatt "Gruppe 1" enthaelt wie die echte Arbeitskopie.
"""

from __future__ import annotations

import io
import sys
import urllib.parse
from datetime import datetime
from pathlib import Path

import httpx
import pytest

PROJEKT = Path(__file__).resolve().parent.parent
if str(PROJEKT) not in sys.path:
    sys.path.insert(0, str(PROJEKT))

import app.models  # noqa: F401 - Tabellen vor Base.metadata.create_all registrieren

from app.config import graph_konfiguriert
from app.database import Base, get_db
from app.dateizugriff.graph import (
    GraphAuthFehler,
    GraphClient,
    GraphHelferdatei,
    GraphNichtErreichbar,
    modus_aktuell,
    sync_status_aktualisieren,
    sync_status_holen,
)
from app.dateizugriff.schema import DateiVeraendert
from app.dateizugriff.sync_ordner import SyncOrdnerHelferdatei

BIBLIOTHEKS_PFAD = "Freigegebene Dokumente/Helfer - Bestand/Personal_Bestandsaufnahme.xlsx"
SITE = "maltesercloud.sharepoint.com,sites,Fhrung-Behandlungszug"


def _arbeitsmappe() -> bytes:
    """Eine kleine fuehrende Datei im Speicher (wie die echte Arbeitskopie)."""
    import openpyxl

    mappe = openpyxl.Workbook()
    blatt = mappe.active
    blatt.title = "Gruppe 1"
    blatt.append(["Nr", "Name", "Telefon", "PSNV", "GF"])
    blatt.append([1, "Anna Beispiel", "123", "n", "Niklas"])
    blatt.append([2, "Ben Muster", "", "n", None])

    puffer = io.BytesIO()
    mappe.save(puffer)
    mappe.close()
    return puffer.getvalue()


class GraphSimulation:
    """Faengt die Aufrufe ab und stellt die Rollen eines SharePoint-Sites dar."""

    def __init__(self) -> None:
        self.inhalt: bytes = _arbeitsmappe()
        self.etag = '"abc123"'
        self.offline = False            # Netz weg -> ConnectError
        self.auth_fehler = False        # Token-Endpunkt verweigert
        self.graph_fehler_zuerst = None  # Status, den der erste content-GET liefert
        self.graph_fehler_immer = None   # Status fuer jeden content-GET (401 probe)
        self.datei_fehlt = False        # content-GET -> 404
        self.protokoll: list[dict] = []
        self.token_zaehler = 0

    def _token_antwort(self) -> httpx.Response:
        self.token_zaehler += 1
        return httpx.Response(
            200,
            json={
                "access_token": f"frisches-token-{self.token_zaehler}",
                "expires_in": 3600,
            },
        )

    def __call__(self, request: httpx.Request) -> httpx.Response:
        host = request.url.host
        pfad = request.url.path
        auth = request.headers.get("authorization", "")
        if_match = request.headers.get("if-match")

        # Token-Endpunkt (andere Authority als graph.microsoft.com).
        if "login.microsoftonline.com" in host:
            if self.auth_fehler:
                return httpx.Response(
                    401, json={"error": {"code": "invalid_client",
                                         "message": "ungültige Anmeldedaten"}}
                )
            return self._token_antwort()

        self.protokoll.append(
            {"methode": request.method, "pfad": pfad, "auth": auth, "if_match": if_match}
        )

        if self.offline:
            raise httpx.ConnectError("Netz nicht erreichbar", request=request)

        if pfad.endswith(":/content") and request.method == "GET":
            if self.graph_fehler_immer:
                return httpx.Response(self.graph_fehler_immer)
            if self.graph_fehler_zuerst:
                status, self.graph_fehler_zuerst = self.graph_fehler_zuerst, None
                return httpx.Response(status)
            if self.datei_fehlt:
                return httpx.Response(
                    404, json={"error": {"message": "Das Element wurde nicht gefunden"}}
                )
            return httpx.Response(
                200, headers={"etag": self.etag}, content=self.inhalt
            )

        if pfad.endswith(":/content") and request.method == "PUT":
            if if_match != self.etag:
                return httpx.Response(
                    412,
                    json={"error": {"message": "Das Element wurde inzwischen geaendert"}},
                )
            self.inhalt = request.content
            self.etag = '"frisch-hochgeladen"'
            return httpx.Response(200, headers={"etag": self.etag})

        # Kopfdaten (Metadaten-Probe).
        if request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "id": "01",
                    "name": "Personal_Bestandsaufnahme.xlsx",
                    "eTag": self.etag,
                    "lastModifiedDateTime": "2026-09-16T10:00:00Z",
                    "size": len(self.inhalt),
                },
            )

        return httpx.Response(400)


@pytest.fixture
def sim() -> GraphSimulation:
    return GraphSimulation()


def _baue(sim: GraphSimulation, lokal: Path, start_synchronisierung: bool = True) -> GraphHelferdatei:
    return GraphHelferdatei(
        client=GraphClient(
            tenant="tenant",
            client_id="client",
            client_secret="geheim",
            transport=httpx.MockTransport(sim),
            token_vorbelegt="token-0",
        ),
        site_id=SITE,
        pfad_in_bibliothek=BIBLIOTHEKS_PFAD,
        lokal=lokal,
        start_synchronisierung=start_synchronisierung,
    )


@pytest.fixture
def graph_datei(sim: GraphSimulation, tmp_path: Path) -> GraphHelferdatei:
    return _baue(sim, tmp_path / "kopie" / "Personal_Bestandsaufnahme.xlsx")


# ===========================================================================
# GraphClient: Token und Aufrufe
# ===========================================================================

class TestGraphClientToken:
    def test_holen_und_verwenden_des_tokens(self, sim):
        client = GraphClient(
            tenant="t", client_id="c", client_secret="s",
            transport=httpx.MockTransport(sim),
        )
        antwort = client.anfrage("GET", "/sites/x")
        assert antwort.status_code == 200
        token_aufrufe = [e for e in sim.protokoll if e["methode"] == "GET"]
        assert token_aufrufe[0]["auth"] == "Bearer frisches-token-1"

    def test_401_erneuert_token_genau_einmal(self, sim, graph_datei):
        sim.graph_fehler_zuerst = 401
        personen = graph_datei.lade_personen()
        assert len(personen) == 2
        content_gets = [
            e for e in sim.protokoll
            if e["pfad"].endswith(":/content") and e["methode"] == "GET"
        ]
        # Erstversuch mit dem vorbelegten Token, Wiederholung mit frischem.
        assert [e["auth"] for e in content_gets] == ["Bearer token-0", "Bearer frisches-token-1"]

    def test_persistenter_401_verlaesst_sich_auf_offline_fallback(self, sim, tmp_path):
        sim.etag = '"x"'
        sim.inhalt = _arbeitsmappe()
        # Auch nach der Tokenerneuerung schlaegt der Abruf weiter fehl.
        sim.graph_fehler_immer = 401
        lokal = tmp_path / "k" / "d.xlsx"
        lokal.parent.mkdir(parents=True)
        lokal.write_bytes(_arbeitsmappe())
        datei = _baue(sim, lokal)
        personen = datei.lade_personen()
        assert len(personen) == 2
        assert datei._offline

    def test_anmeldefehler_wird_als_graphauthfehler_gemeldet(self, sim, tmp_path):
        sim.auth_fehler = True
        client = GraphClient(
            tenant="t", client_id="c", client_secret="s",
            transport=httpx.MockTransport(sim),
        )
        with pytest.raises(GraphAuthFehler):
            client.anfrage("GET", "/sites/x")

    def test_netzfehler_wird_als_graphnichterreichbar_gemeldet(self, sim):
        sim.offline = True
        client = GraphClient(
            tenant="t", client_id="c", client_secret="s",
            transport=httpx.MockTransport(sim),
            token_vorbelegt="token-0",
        )
        with pytest.raises(GraphNichtErreichbar):
            client.anfrage("GET", "/sites/x")


# ===========================================================================
# GraphHelferdatei: Abgleich
# ===========================================================================

class TestAbholen:
    def test_erfolgreicher_abruf_legt_lokale_kopie_an(self, sim, graph_datei):
        personen = graph_datei.lade_personen()
        assert len(personen) == 2
        assert graph_datei.pfad.is_file()
        assert not graph_datei._offline
        assert graph_datei.status_augenblick()["letzte_synchronisierung"] is not None

    def test_erreichbarkeit_haengt_von_der_lokalen_kopie_ab(self, sim, tmp_path):
        datei = _baue(sim, tmp_path / "kopie" / "Personal_Bestandsaufnahme.xlsx",
                      start_synchronisierung=False)
        assert not datei.ist_erreichbar()
        assert datei.abholen()
        assert datei.ist_erreichbar()

    def test_ist_gesperrt_in_sharepoint_immer_frei(self, graph_datei):
        assert graph_datei.ist_gesperrt() == (False, None)

    def test_offline_fallback_liest_letzten_lokalen_stand(self, sim, tmp_path):
        lokal = tmp_path / "kopie" / "Personal_Bestandsaufnahme.xlsx"
        lokal.parent.mkdir(parents=True)
        lokal.write_bytes(_arbeitsmappe())
        sim.offline = True
        datei = _baue(sim, lokal)
        personen = datei.lade_personen()
        assert len(personen) == 2
        assert datei._offline
        assert datei.status_augenblick()["letzte_meldung"]
        # Lesen funktioniert im Offline-Fallback weiterhin.
        assert datei.ist_erreichbar()

    def test_anmeldefehler_setzt_offline_fallback(self, sim, tmp_path):
        sim.auth_fehler = True
        client = GraphClient(
            tenant="t", client_id="c", client_secret="s",
            transport=httpx.MockTransport(sim),
        )
        datei = GraphHelferdatei(
            client=client,
            site_id=SITE,
            pfad_in_bibliothek=BIBLIOTHEKS_PFAD,
            lokal=tmp_path / "k" / "d.xlsx",
        )
        assert datei.abholen() is False
        assert datei._offline
        assert "Anmeldung" in datei.status_augenblick()["letzte_meldung"]

    def test_kopf_probe_erkennt_verbindung(self, sim, graph_datei):
        ok, meldung = graph_datei.pruefe_verbindung()
        assert ok
        assert "Personal_Bestandsaufnahme.xlsx" in meldung


class TestSpeichernUndHochladen:
    def test_aenderung_erreicht_sharepoint(self, sim, graph_datei, tmp_path):
        personen = graph_datei.lade_personen()
        anna = personen[0]
        saetze = graph_datei.speichere_person(anna.schluessel, {"PSNV": "y"})
        assert len(saetze) == 1
        assert not graph_datei._ausstehend

        fern = tmp_path / "fern.xlsx"
        fern.write_bytes(sim.inhalt)
        remote = SyncOrdnerHelferdatei(fern)
        assert remote.lade_personen()[0].wert("PSNV") == "y"

    def test_aenderung_hochgeladen_trotz_spaetem_abruf(self, sim, graph_datei):
        # Erst lesen (etag wird gemerkt), dann aendern und wieder lesen.
        graph_datei.lade_amu_katalog()
        personen = graph_datei.lade_personen()
        graph_datei.speichere_person(personen[1].schluessel, {"Telefon": "999"})
        # Nach dem Upload liegt kein ausstehender Eintrag mehr an.
        assert not graph_datei._ausstehend

    def test_ohne_aenderung_kein_upload(self, sim, graph_datei):
        vorher = list(sim.protokoll)
        personen = graph_datei.lade_personen()
        saetze = graph_datei.speichere_person(
            personen[0].schluessel, {"Telefon": "123"}
        )
        assert saetze == []
        puts = [e for e in sim.protokoll if e["methode"] == "PUT"]
        assert not puts

    def test_konflikt_wirft_dateiveraendert_und_holt_frische_fassung(
        self, sim, graph_datei
    ):
        graph_datei.lade_personen()
        anna = graph_datei.lade_personen()[0]
        # Jemand anderes hat zwischenzeitlich geschrieben.
        sim.etag = '"fremder-stand"'
        with pytest.raises(DateiVeraendert):
            graph_datei.speichere_person(anna.schluessel, {"PSNV": "y"})
        # Die eigene (verworfene) Aenderung ist nicht ausstehend, die lokale
        # Fassung entspricht wieder dem fernen Stand.
        assert graph_datei._ausstehend is False
        assert graph_datei._etag == sim.etag
        assert not graph_datei._offline

    def test_offline_schreiben_bleibt_lokal_und_ausstehend(self, sim, tmp_path):
        lokal = tmp_path / "kopie" / "Personal_Bestandsaufnahme.xlsx"
        lokal.parent.mkdir(parents=True)
        lokal.write_bytes(_arbeitsmappe())
        sim.offline = True
        datei = _baue(sim, lokal)
        anna = datei.lade_personen()[0]
        saetze = datei.speichere_person(anna.schluessel, {"Telefon": "555"})
        assert len(saetze) == 1
        assert datei._ausstehend
        # Die Aenderung ist in der lokalen Kopie sichtbar.
        assert datei.lade_personen()[0].wert("Telefon") == "555"

    def test_synchronisiere_jetzt_holt_und_laedt_ausstehende_hoch(
        self, sim, graph_datei, tmp_path
    ):
        graph_datei.lade_personen()
        sim.etag = '"weiterer-stand"'
        meldung = graph_datei.synchronisiere_jetzt()
        assert "übernommen" in meldung
        assert graph_datei._etag == sim.etag

    def test_synchronisiere_jetzt_offline_meldet_hoffnungslos(
        self, sim, tmp_path
    ):
        lokal = tmp_path / "k2" / "d.xlsx"
        lokal.parent.mkdir(parents=True)
        lokal.write_bytes(_arbeitsmappe())
        sim.offline = True
        datei = _baue(sim, lokal)
        meldung = datei.synchronisiere_jetzt()
        assert "schlägt fehl" in meldung
        assert datei._offline


# ===========================================================================
# Status in der Datenbank
# ===========================================================================

class TestSyncStatus:
    @pytest.fixture
    def db(self, tmp_path):
        from sqlalchemy import create_engine
        from sqlalchemy.orm import sessionmaker

        motor = create_engine(
            f"sqlite:///{tmp_path / 'status.db'}",
            connect_args={"check_same_thread": False},
        )
        Base.metadata.create_all(motor)
        Sitzung = sessionmaker(bind=motor)
        sitzung = Sitzung()
        yield sitzung
        sitzung.close()

    def test_anlegen_und_wiederverwenden_eines_datensatzes(self, db, monkeypatch):
        monkeypatch.setattr("app.config.SHAREPOINT_AKTIV", False)
        eintrag = sync_status_holen(db)
        assert eintrag.id == 1
        assert eintrag.modus == "lokal"
        assert sync_status_holen(db) is eintrag

    def test_aktualisieren_schreibt_felder(self, db):
        jetzt = datetime(2026, 9, 16, 12, 0, 0)
        sync_status_aktualisieren(
            db,
            modus="sharepoint",
            verbunden=True,
            offline=False,
            ausstehend=False,
            letzte_synchronisierung=jetzt,
            meldung="Mit SharePoint verbunden.",
        )
        eintrag = sync_status_holen(db)
        assert eintrag.verbunden is True
        assert eintrag.letzte_synchronisierung == jetzt
        assert eintrag.letzte_meldung == "Mit SharePoint verbunden."


# ===========================================================================
# Konfiguration: wann wird SharePoint ueberhaupt benutzt
# ===========================================================================

class TestKonfiguration:
    def test_graph_konfiguriert_meldet_fehlen(self, monkeypatch):
        for name in ("GRAPH_TENANT_ID", "GRAPH_CLIENT_ID", "GRAPH_CLIENT_SECRET", "GRAPH_SITE_ID"):
            monkeypatch.setattr(f"app.config.{name}", "")
        assert graph_konfiguriert() is not None

    def test_graph_konfiguriert_none_wenn_vollstaendig(self, monkeypatch):
        for name, wert in (
            ("GRAPH_TENANT_ID", "t"),
            ("GRAPH_CLIENT_ID", "c"),
            ("GRAPH_CLIENT_SECRET", "s"),
            ("GRAPH_SITE_ID", "s1"),
        ):
            monkeypatch.setattr(f"app.config.{name}", wert)
        assert graph_konfiguriert() is None

    def test_graf_aktiv_braucht_schalter_und_konfiguration(self, monkeypatch):
        for name, wert in (
            ("SHAREPOINT_AKTIV", False),
            ("GRAPH_TENANT_ID", "t"),
            ("GRAPH_CLIENT_ID", "c"),
            ("GRAPH_CLIENT_SECRET", "s"),
            ("GRAPH_SITE_ID", "s1"),
        ):
            monkeypatch.setattr(f"app.config.{name}", wert)
        from app.config import graf_aktiv

        assert graf_aktiv() is False

        monkeypatch.setattr("app.config.SHAREPOINT_AKTIV", True)
        assert graf_aktiv() is True

    def test_modus_aktuell_folgt_der_konfiguration(self, monkeypatch):
        monkeypatch.setattr("app.config.SHAREPOINT_AKTIV", False)
        assert modus_aktuell() == "lokal"

        monkeypatch.setattr("app.config.SHAREPOINT_AKTIV", True)
        for name, wert in (
            ("GRAPH_TENANT_ID", "t"),
            ("GRAPH_CLIENT_ID", "c"),
            ("GRAPH_CLIENT_SECRET", "s"),
            ("GRAPH_SITE_ID", "s1"),
        ):
            monkeypatch.setattr(f"app.config.{name}", wert)
        assert modus_aktuell() == "sharepoint"


# ===========================================================================
# Oberflaeche (Endpunkte)
# ===========================================================================

@pytest.fixture
def datei_objekt_local(tmp_path):
    """Eine echte Sync-Ordner-Datei auf der Platte (lokaler Modus)."""
    pfad = tmp_path / "lokal" / "Personal_Bestandsaufnahme.xlsx"
    pfad.parent.mkdir(parents=True)
    pfad.write_bytes(_arbeitsmappe())
    return SyncOrdnerHelferdatei(pfad)


def _web_client(tmp_path, monkeypatch, datei_objekt):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    motor = create_engine(
        f"sqlite:///{tmp_path / 'web.db'}", connect_args={"check_same_thread": False}
    )
    Base.metadata.create_all(motor)
    Sitzung = sessionmaker(bind=motor, autoflush=False, autocommit=False)

    def _get_db_ersatz():
        db = Sitzung()
        try:
            yield db
        finally:
            db.close()

    from app.routes import dashboard as dashboard_routen
    from app.routes import einstellungen as einstellungen_routen

    for ziel in (
        "app.deps.hole_helferdatei",
        "app.routes.einstellungen.hole_helferdatei",
        "app.routes.dashboard.hole_helferdatei",
    ):
        monkeypatch.setattr(ziel, lambda: datei_objekt)

    app = FastAPI(title="Sync-Test")
    app.include_router(dashboard_routen.router)
    app.include_router(einstellungen_routen.router)
    app.dependency_overrides[get_db] = _get_db_ersatz
    return TestClient(app)


class TestLokalerEndpunkt:
    @pytest.fixture
    def client(self, tmp_path, monkeypatch, datei_objekt_local):
        return _web_client(tmp_path, monkeypatch, datei_objekt_local)

    def test_dashboard_zeigt_sync_leiste(self, client):
        html = client.get("/").text
        assert "Modus: lokaler Ordner" in html
        assert "Jetzt synchronisieren" in html

    def test_einstellungen_zeigen_lokalen_modus(self, client):
        html = client.get("/einstellungen").text
        assert "Synchronisation" in html
        assert "lokaler Sync-Ordner" in html

    def test_verbindung_testen_lokal(self, client):
        r = client.post("/sync/test", headers={"referer": "/einstellungen"},
                        follow_redirects=False)
        assert r.status_code == 302
        ziel = urllib.parse.unquote(r.headers["location"])
        assert "Lokaler Ordner erreichbar" in ziel

    def test_synchronisieren_lokal_ist_leerlauf(self, client):
        r = client.post("/sync/now", headers={"referer": "/einstellungen"},
                        follow_redirects=False)
        assert r.status_code == 302
        ziel = urllib.parse.unquote(r.headers["location"])
        assert "Lokaler Modus" in ziel


class TestGraphEndpunkt:
    @pytest.fixture
    def client(self, tmp_path, monkeypatch, sim):
        graph_objekt = _baue(sim, tmp_path / "kopie" / "Personal_Bestandsaufnahme.xlsx")
        return _web_client(tmp_path, monkeypatch, graph_objekt)

    def test_dashboard_zeigt_sharepoint_modus(self, client):
        html = client.get("/").text
        assert "Modus: SharePoint" in html
        assert "verbunden" in html

    def test_einstellungen_zeigen_sharepoint_details(self, client):
        html = client.get("/einstellungen").text
        assert "Microsoft SharePoint (Graph)" in html
        assert "Lokale Arbeitskopie" in html

    def test_verbindung_testen_sharepoint(self, client):
        r = client.post("/sync/test", headers={"referer": "/einstellungen"},
                        follow_redirects=False)
        assert r.status_code == 302
        ziel = urllib.parse.unquote(r.headers["location"])
        assert "verbunden" in ziel

    def test_synchronisieren_sharepoint(self, client):
        r = client.post("/sync/now", headers={"referer": "/einstellungen"},
                        follow_redirects=False)
        assert r.status_code == 302
        ziel = urllib.parse.unquote(r.headers["location"])
        assert "übernommen" in ziel