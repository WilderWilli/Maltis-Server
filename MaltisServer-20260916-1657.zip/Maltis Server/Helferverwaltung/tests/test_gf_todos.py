"""Tests für die Gruppenführer-Übersicht (To-do), GF-Filter und schnelle Zuweisung.

Teil 1 prüft die reine Logik (``app.logic.gf_todos``) gegen erfundene
Personen - keine Datei, kein HTTP.

Teil 2 prüft die Endpunkte über einen TestClient gegen eine frische Wegwerf-
Datei. Die reale Arbeitskopie, die Datenbank und die Sicherungsordner werden
dabei nicht angefasst: ``hole_helferdatei`` wird auf die Testdatei umgelenkt,
``get_db`` auf eine In-Memory-Datenbank.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

import pytest

PROJEKT = Path(__file__).resolve().parent.parent
if str(PROJEKT) not in sys.path:
    sys.path.insert(0, str(PROJEKT))

import app.models  # noqa: F401 - muss vor Base.metadata.create_all importiert sein

from app.database import Base, get_db
from app.dateizugriff.schema import (
    SPALTE_CBRN_GROESSE,
    SPALTE_DIENSTKLEIDUNG_GROESSE,
    SPALTE_GF,
    SPALTE_JAHRESGESPRAECH,
    SPALTE_NAME,
    AmuEintrag,
    Person,
    Personenschluessel,
)
from app.logic.gf_todos import baue_gf_uebersicht
from app.logic.werte import ist_leer


# Bequeme Konstanten fuer Tests, die mit Groessen ausgeschlossen werden wollen.
_GROESSEN = {SPALTE_DIENSTKLEIDUNG_GROESSE: "M", SPALTE_CBRN_GROESSE: "L"}


# ---------------------------------------------------------------------------
# Helfer fuer die Logik-Tests
# ---------------------------------------------------------------------------

def _person(name: str, gf: str | None = None, **spalten) -> Person:
    werte = {SPALTE_NAME: name, **spalten}
    if gf is not None:
        werte[SPALTE_GF] = gf
    return Person(
        schluessel=Personenschluessel("Gruppe 1", 2, name),
        werte=werte,
    )


def _katalog() -> dict[str, AmuEintrag]:
    return {
        "G 26.2": AmuEintrag(
            abkuerzung="G 26.2", bezeichnung="Atemschutz 2",
            zielgruppe="alle", turnus="", freiwillig_roh="n",
        ),
    }


def _gruppen(personen: list[Person]) -> dict[str, list]:
    return {
        g.name: g
        for g in baue_gf_uebersicht(personen, _katalog(), heute=date(2026, 9, 16))
    }


# ===========================================================================
# Teil 1: Logik - Gruppierung
# ===========================================================================

class TestGfGruppierung:
    def test_teilt_nach_gf_auf(self):
        gruppen = _gruppen([
            _person("Anna", gf="Niklas"),
            _person("Ben", gf="Nino"),
            _person("Chris"),
        ])
        assert set(gruppen) == {"Niklas", "Nino", "Ohne Zuordnung"}
        assert [p.person.name for p in gruppen["Niklas"].personen] == ["Anna"]
        assert [p.person.name for p in gruppen["Nino"].personen] == ["Ben"]
        assert [p.person.name for p in gruppen["Ohne Zuordnung"].personen] == ["Chris"]

    def test_reihenfolge_gruppen_niklas_nino_ohne(self):
        gruppen = baue_gf_uebersicht([_person("Chris"), _person("Ben", gf="Nino"),
                                      _person("Anna", gf="Niklas")], _katalog())
        assert [g.name for g in gruppen] == ["Niklas", "Nino", "Ohne Zuordnung"]

    def test_unbekannter_gf_ist_ohne_zordnung(self):
        gruppen = _gruppen([_person("Anna", gf="Max")])
        eintrag = gruppen["Ohne Zuordnung"].personen[0]
        assert eintrag.gf_roh == "Max"

    def test_leerer_gf_ist_ohne_zordnung(self):
        gruppen = _gruppen([_person("Anna", gf="")])
        assert [p.person.name for p in gruppen["Ohne Zuordnung"].personen] == ["Anna"]

    def test_nur_bekannte_gfs_im_ueberschrift_filter(self):
        """Im Dashboard/Personal zaehlt nur, wer tatsaechlich Niklas/Nino ist."""
        gruppen = _gruppen([_person("Anna", gf="niklas"), _person("Ben", gf="Nino")])
        # Gross-/Kleinschreibung: "niklas" ist kein gueltiger Wert -> ohne Zuordnung.
        assert [p.person.name for p in gruppen["Niklas"].personen] == []
        assert [p.person.name for p in gruppen["Nino"].personen] == ["Ben"]
        assert [p.person.name for p in gruppen["Ohne Zuordnung"].personen] == ["Anna"]


# ===========================================================================
# Teil 1: Logik - offene Aufgaben je Person
# ===========================================================================

class TestGfPersonAufgaben:
    def test_faellige_jahrespflicht_zaehlt_als_ausstehend(self):
        gruppen = _gruppen([_person("Anna", gf="Niklas", Jahresgespräch="y", **_GROESSEN)])
        eintrag = gruppen["Niklas"].personen[0]
        assert len(eintrag.jahrespflichten) == 1
        assert eintrag.jahrespflichten[0].ausstehend
        assert eintrag.anzahl_offene_punkte == 1

    def test_leere_jahrespflicht_zaehlt(self):
        gruppen = _gruppen([
            _person("Anna", gf="Niklas", **{SPALTE_JAHRESGESPRAECH: None, **_GROESSEN}),
        ])
        eintrag = gruppen["Niklas"].personen[0]
        assert len(eintrag.jahrespflichten) == 1
        assert eintrag.anzahl_offene_punkte == 1

    def test_erledigte_jahrespflicht_zaehlt_nicht(self):
        gruppen = _gruppen([
            _person("Anna", gf="Niklas", Jahresgespräch=date(2026, 2, 2), **_GROESSEN),
        ])
        eintrag = gruppen["Niklas"].personen[0]
        assert eintrag.jahrespflichten == ()
        assert eintrag.anzahl_offene_punkte == 0

    def test_abgelaufene_amu_zaehlt(self):
        gruppen = _gruppen([
            _person("Anna", gf="Nino", **{"G 26.2": date(2020, 1, 1), **_GROESSEN}),
        ])
        eintrag = gruppen["Nino"].personen[0]
        assert len(eintrag.amu) == 1
        assert eintrag.amu[0].lage.value == "abgelaufen"

    def test_gueltige_amu_zaehlt_nicht(self):
        gruppen = _gruppen([
            _person("Anna", gf="Nino", **{"G 26.2": date(2027, 6, 1), **_GROESSEN}),
        ])
        eintrag = gruppen["Nino"].personen[0]
        assert eintrag.amu == ()
        assert eintrag.anzahl_offene_punkte == 0

    def test_fehlende_amu_zaehlt(self):
        gruppen = _gruppen([
            _person("Anna", gf="Nino", **{"G 26.2": None, **_GROESSEN}),
        ])
        eintrag = gruppen["Nino"].personen[0]
        assert len(eintrag.amu) == 1

    def test_hat_abgelaufene_amu_nur_bei_abgelaufen(self):
        gruppe1 = _gruppen([
            _person("Zoe", gf="Nino", **{"G 26.2": date(2020, 1, 1), **_GROESSEN}),
        ])["Nino"].personen[0]
        gruppe2 = _gruppen([
            _person("Ulf", gf="Nino", **{"G 26.2": date(2027, 6, 1), **_GROESSEN}),
        ])["Nino"].personen[0]
        assert gruppe1.hat_abgelaufene_amu
        assert not gruppe2.hat_abgelaufene_amu

    def test_fehlende_groessen_zaehlen(self):
        gruppen = _gruppen([_person("Anna", gf="Niklas")])
        eintrag = gruppen["Niklas"].personen[0]
        assert eintrag.dienstkleidung_groesse_fehlt
        assert eintrag.cbrn_groesse_fehlt
        assert eintrag.groessen_fehlen == 2
        assert eintrag.anzahl_offene_punkte == 2

    def test_vorhandene_groessen_zaehlen_nicht(self):
        gruppen = _gruppen([_person("Anna", gf="Niklas", **_GROESSEN)])
        eintrag = gruppen["Niklas"].personen[0]
        assert not eintrag.dienstkleidung_groesse_fehlt
        assert not eintrag.cbrn_groesse_fehlt
        assert eintrag.groessen_fehlen == 0

    def test_sortierung_meiste_aufgaben_oben(self):
        """Zoe (Jahrespflicht + 2 Groessen) steht vor Anna (nur 2 Groessen)."""
        gruppen = _gruppen([
            _person("Zoe", gf="Niklas", Jahresgespräch=None),
            _person("Anna", gf="Niklas"),
        ])
        namen = [p.person.name for p in gruppen["Niklas"].personen]
        assert namen == ["Zoe", "Anna"]


# ===========================================================================
# Teil 1: Logik - Gruppenzusammenfassung
# ===========================================================================

class TestGfGruppeZaehler:
    def test_gruppe_zahlt_personen(self):
        gruppen = _gruppen([_person("Anna", gf="Niklas"), _person("Ben", gf="Niklas")])
        assert gruppen["Niklas"].anzahl_personen == 2

    def test_gruppe_zahlt_offene_punkte(self):
        gruppen = _gruppen([
            _person("Anna", gf="Nino", Jahresgespräch="y"),   # 1 + 2 Groessen
            _person("Ben", gf="Nino", Jahresgespräch=date(2026, 1, 1)),  # 2 Groessen
        ])
        gruppe = gruppen["Nino"]
        assert gruppe.anzahl_jahrespflichten == 1
        assert gruppe.anzahl_groessen == 4
        assert gruppe.anzahl_offene_punkte == 5

    def test_gruppe_zahlt_amu(self):
        gruppen = _gruppen([_person("Anna", gf="Nino", **{"G 26.2": None})])
        assert gruppen["Nino"].anzahl_amu == 1

    def test_gruppe_alles_erledigt(self):
        gruppen = _gruppen([_person(
            "Anna", gf="Niklas", Jahresgespräch=date(2026, 1, 1),
            **{SPALTE_DIENSTKLEIDUNG_GROESSE: "M", SPALTE_CBRN_GROESSE: "L"},
        )])
        assert gruppen["Niklas"].alles_erledigt

    def test_personen_mit_aufgaben(self):
        gruppen = _gruppen([
            _person("Anna", gf="Niklas"),                     # hat Aufgaben
            _person("Ben", gf="Niklas",
                    **{SPALTE_DIENSTKLEIDUNG_GROESSE: "S", SPALTE_CBRN_GROESSE: "M"}),  # alles ok
        ])
        assert [p.person.name for p in gruppen["Niklas"].personen_mit_aufgaben] == ["Anna"]


# ===========================================================================
# Teil 2: Endpunkte
# ===========================================================================

_H = [  # Kopfzeile der Testdatei
    "Nr", "Name", "Status", "Telefon", "Medizinisch", "Jahresgespräch",
    "G 26.2", "GF", "Dienstkleidung Größe", "CBRN Kleidergröße",
]


def _baue_datei(tmp_path: Path, heute: date) -> Path:
    import openpyxl

    pfad = tmp_path / "Personal_Bestandsaufnahme.xlsx"
    mappe = openpyxl.Workbook()
    blatt = mappe.active
    blatt.title = "Gruppe 1"
    blatt.append(_H)
    blatt.append([
        1, "Anna Beispiel", None, "123", None, "y",              # Jahresgespräch ausstehend
        date(heute.year + 1, 6, 1),                              # G 26.2 gültig
        "Niklas", "M", "L",
    ])
    blatt.append([
        2, "Ben Muster", None, "", None, date(heute.year, 1, 1),  # Jahresgespräch erledigt
        None,                                                     # G 26.2 fehlt
        "Nino", None, None,
    ])
    blatt.append([
        3, "Chris Test", None, "", None, None,                    # Jahresgespräch fehlt
        date(heute.year - 3, 1, 1),                              # G 26.2 abgelaufen
        None, None, None,
    ])

    amu = mappe.create_sheet("AMU")
    amu["A1"], amu["B1"] = "Abkürzung", "G 26.2"
    amu["A2"], amu["B2"] = "Bezeichnung", "Atemschutz 2"
    amu["A3"], amu["B3"] = "Zielgruppe", "alle"
    amu["A4"], amu["B4"] = "Turnus", ""
    amu["A5"], amu["B5"] = "freiwillig?", "n"

    mappe.save(pfad)
    mappe.close()
    return pfad


@pytest.fixture
def datei(tmp_path: Path):
    from app.dateizugriff.sync_ordner import SyncOrdnerHelferdatei

    return SyncOrdnerHelferdatei(_baue_datei(tmp_path, date.today()))


@pytest.fixture
def client(datei, tmp_path: Path, monkeypatch):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    # Neue Datei statt der echten Arbeitskopie - auch fuer den Startkontext.
    for ziel in ("app.deps.hole_helferdatei",
                 "app.routes.helfer.hole_helferdatei",
                 "app.routes.todos.hole_helferdatei"):
        monkeypatch.setattr(ziel, lambda: datei)
    # Sicherungen der Testwrites landen nicht im echten Ordner.
    monkeypatch.setattr(
        "app.dateizugriff.sync_ordner.SICHERUNGS_ORDNER", tmp_path / "sicherungen"
    )

    # Datei statt reinem In-Memory: sqlite:// gibt jeder Verbindung eine frische
    # Datenbank, dann verschwinden die Tabellen zwischen create_all und Anfrage.
    motor = create_engine(
        f"sqlite:///{tmp_path / 'test.db'}", connect_args={"check_same_thread": False}
    )
    Base.metadata.create_all(motor)
    Sitzung = sessionmaker(bind=motor, autoflush=False, autocommit=False)

    def _get_db_ersatz():
        db = Sitzung()
        try:
            yield db
        finally:
            db.close()

    from app.routes import helfer as helfer_routes
    from app.routes import todos as todos_routes

    app = FastAPI(title="Test")
    app.include_router(helfer_routes.router)
    app.include_router(todos_routes.router)
    app.dependency_overrides[get_db] = _get_db_ersatz
    return TestClient(app)


def _person_nach_name(datei, name: str) -> Person:
    return next(p for p in datei.lade_personen() if p.name == name)


class TestGfEndpunkte:
    def test_gruppenfuehrer_seite_zeigt_gruppen_und_zahlen(self, client):
        r = client.get("/gruppenfuehrer")
        assert r.status_code == 200
        html = r.text
        assert "Gruppenführer" in html
        assert "Ohne Zuordnung" in html
        assert "Anna Beispiel" in html
        assert "Ben Muster" in html
        assert "Chris Test" in html
        # Anna: 1 Jahrespflicht ausstehend + 0 Groessen -> "1 Aufgabe offen".
        assert "1 Aufgabe offen" in html
        # Ben: 1 fehlende G 26.2 + 2 Groessen -> "3 Aufgaben offen".
        assert "3 Aufgaben offen" in html
        # Chris: 1 Jahrespflicht + 1 abgelaufene Untersuchung + 2 Groessen.
        assert "4 Aufgaben offen" in html
        # Die abgelaufene Untersuchung bekommt den roten Stempel "abgelaufen".
        assert 'pill abgelaufen">1 Untersuchung' in html

    def test_gruppenfuehrer_zeigt_groessen_hinweis(self, client):
        html = client.get("/gruppenfuehrer").text
        assert "Dienstkleidung-Größe fehlt" in html
        assert "CBRN-Größe fehlt" in html

    def test_helfer_liste_filtert_nach_gf(self, client):
        html = client.get("/helfer", params={"gf": "Niklas"}).text
        assert "Anna Beispiel" in html
        assert "Ben Muster" not in html
        assert "Chris Test" not in html

    def test_helfer_liste_filtert_ohne_zordnung(self, client):
        html = client.get("/helfer", params={"gf": "ohne"}).text
        assert "Chris Test" in html
        assert "Anna Beispiel" not in html

    def test_helfer_liste_ohne_filter_zeigt_alle(self, client):
        html = client.get("/helfer").text
        assert "Anna Beispiel" in html
        assert "Ben Muster" in html
        assert "Chris Test" in html

    def test_navigation_enthaelt_gruppenfuehrer(self, client):
        assert 'href="/gruppenfuehrer"' in client.get("/helfer").text

    def test_schnelle_zordnung_setzt_gf(self, client, datei):
        chris = _person_nach_name(datei, "Chris Test")
        r = client.post(
            "/gf-zuweisen",
            data={"kennung": chris.schluessel.kennung, "gf": "Niklas"},
            headers={"referer": "/helfer?gf=ohne"},
            follow_redirects=False,
        )
        assert r.status_code == 302
        assert "gf=ohne" in r.headers["location"]
        neu = _person_nach_name(datei, "Chris Test")
        assert neu.wert(SPALTE_GF) == "Niklas"

    def test_schnelle_zordnung_leert_gf(self, client, datei):
        anna = _person_nach_name(datei, "Anna Beispiel")
        r = client.post(
            "/gf-zuweisen",
            data={"kennung": anna.schluessel.kennung, "gf": ""},
            headers={"referer": "/helfer"},
            follow_redirects=False,
        )
        assert r.status_code == 302
        neu = _person_nach_name(datei, "Anna Beispiel")
        assert ist_leer(neu.wert(SPALTE_GF))

    def test_ungueltige_auswahl_wird_abgelehnt(self, client, datei):
        anna = _person_nach_name(datei, "Anna Beispiel")
        r = client.post(
            "/gf-zuweisen",
            data={"kennung": anna.schluessel.kennung, "gf": "Herbert"},
        )
        assert r.status_code == 400
        assert _person_nach_name(datei, "Anna Beispiel").wert(SPALTE_GF) == "Niklas"

    def test_unbekannte_person_wird_abgelehnt(self, client, datei):
        r = client.post(
            "/gf-zuweisen",
            data={"kennung": "Gruppe 1|99|Niemand", "gf": "Nino"},
        )
        assert r.status_code == 404