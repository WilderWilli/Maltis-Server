"""Tests fuer das Windows-Testpaket: Pfadaufloesung und Bereitschaft des Baus.

Ohne hier Windows und PyInstaller zu haben, wird geprueft, was lokal
entscheidbar ist:

* dass ``starter.py`` und ``config.py`` ihre Pfade je nach eingefrorenem
  Zustand richtig aufloesen (``sys._MEIPASS`` = Ablage ``_internal``),
* dass das Bau-Spec die Vorlagen, Statik und Testdaten einbettet und alle
  Laufzeit-Abhaengigkeiten auffuehrt,
* dass ``requirements-windows.txt`` vollstaendig ist und
* dass die GitHub-Actions-Pipeline auf ``windows-latest`` baut, die Tests vor
  dem Bauen ausfuehrt und das Ergebnis als ``windows`` hochlaedt.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest

PROJEKT = Path(__file__).resolve().parent.parent
PAKET = PROJEKT / "windows-paket"
WORKFLOW = PROJEKT.parent / ".github" / "workflows" / "build.yml"


def _lade(modulname: str, datei: Path):
    spec = importlib.util.spec_from_file_location(modulname, datei)
    modul = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modul)
    return modul


@pytest.fixture(scope="module")
def starter():
    return _lade("starter_paket_test", PAKET / "starter.py")


def _eingefroren(monkeypatch, tmp_path: Path) -> Path:
    """Simuliert ein PyInstaller-Paket (onedir mit der Ablage ``_internal``)."""
    internal = tmp_path / "_internal"
    (internal / "app" / "templates").mkdir(parents=True)
    (internal / "app" / "static").mkdir(parents=True)
    (internal / "testdaten").mkdir(parents=True)
    monkeypatch.setattr(sys, "frozen", True, raising=False)
    monkeypatch.setattr(sys, "_MEIPASS", str(internal), raising=False)
    monkeypatch.setattr(sys, "executable", str(tmp_path / "Helferverwaltung.exe"))
    return internal


class TestStarterPfade:
    def test_programm_ordner_nicht_eingefroren_ist_projekt(self, starter):
        assert starter.PROGRAMM_DIR == PROJEKT

    def test_testdaten_quelle_nicht_eingefroren(self, starter):
        assert starter._testdaten_quelle() == (
            PAKET / "testdaten" / "Personal_Bestandsaufnahme.xlsx"
        )

    def test_programm_ordner_eingefroren_ist_exe_ordner(self, starter, monkeypatch, tmp_path):
        _eingefroren(monkeypatch, tmp_path)
        assert starter._programm_ordner() == (tmp_path / "Helferverwaltung.exe").resolve().parent

    def test_testdaten_quelle_eingefroren_nutzt_meipass(self, starter, monkeypatch, tmp_path):
        internal = _eingefroren(monkeypatch, tmp_path)
        assert starter._testdaten_quelle() == (
            internal / "testdaten" / "Personal_Bestandsaufnahme.xlsx"
        )

    def test_import_umleitet_nicht_die_ausgabe(self, starter, capsys):
        # Der Import darf die Konsole im Test nicht in eine Logdatei umleiten.
        print("ausgabe-bleibt")
        assert capsys.readouterr().out == "ausgabe-bleibt\n"


class TestKonfigPfade:
    def test_basis_ordner_nicht_eingefroren(self):
        from app.config import BASE_DIR, _basis_ordner

        assert BASE_DIR == PROJEKT
        assert _basis_ordner() == PROJEKT
        assert (BASE_DIR / "app" / "templates").is_dir()
        assert (BASE_DIR / "app" / "static").is_dir()

    def test_basis_ordner_eingefroren_nutzt_meipass(self, monkeypatch, tmp_path):
        internal = _eingefroren(monkeypatch, tmp_path)

        from app.config import _basis_ordner

        assert _basis_ordner() == internal


class TestBauVorschrift:
    def test_spec_bettet_vorlagen_statik_und_testdaten_ein(self):
        text = (PAKET / "helferverwaltung.spec").read_text(encoding="utf-8")
        assert "hiddenimports" in text
        # Die Quell-Ordner, auf die das Spec zeigt, existieren und sind
        # befuellt - ein Build wuerde sonst sofort scheitern.
        assert (PROJEKT / "app" / "templates").is_dir()
        assert (PROJEKT / "app" / "static").is_dir()
        assert "templates" in text and "static" in text and "testdaten" in text

    def test_spec_fuehrt_laufzeit_abhaengigkeiten_auf(self):
        text = (PAKET / "helferverwaltung.spec").read_text(encoding="utf-8")
        for modul in (
            "app.main",
            "uvicorn",
            "httpx",
            "openpyxl",
            "jinja2",
            "multipart",
            "dotenv",
        ):
            assert f"'{modul}" in text, f"hiddenimport fuer {modul} fehlt im Spec"


class TestAbhaengigkeiten:
    def test_requirements_windows_vollstaendig(self):
        text = (PAKET / "requirements-windows.txt").read_text(encoding="utf-8")
        for paket in (
            "fastapi", "uvicorn", "h11", "sqlalchemy", "jinja2",
            "python-multipart", "python-dotenv", "openpyxl", "httpx",
            "pystray", "pillow", "pyinstaller",
        ):
            assert paket in text, f"fehlt in requirements-windows.txt: {paket}"

    def test_alle_laufzeit_importe_deklariert(self):
        text = (PAKET / "requirements-windows.txt").read_text(encoding="utf-8")
        for paket in (
            "fastapi", "uvicorn", "sqlalchemy", "jinja2",
            "python-multipart", "python-dotenv", "openpyxl", "httpx",
        ):
            assert paket in text, f"Laufzeit-Abhaengigkeit fehlt: {paket}"


class TestWorkflow:
    def test_workflow_baut_windows_auf_windows_latest(self):
        text = WORKFLOW.read_text(encoding="utf-8")
        assert "runs-on: windows-latest" in text
        assert "workflow_dispatch" in text
        assert "pyinstaller" in text
        assert "actions/upload-artifact@v4" in text
        assert "name: windows" in text

    def test_workflow_fuehrt_tests_vor_dem_bau_aus(self):
        text = WORKFLOW.read_text(encoding="utf-8")
        test_index = text.find("pytest")
        bau_index = text.find("pyinstaller")
        assert test_index != -1, "Test-Schritt fehlt im Workflow"
        assert bau_index != -1
        assert test_index < bau_index, "Tests laufen nach dem Bau - das ist falsch herum"

    def test_workflow_prueft_gebundelte_ressourcen(self):
        text = WORKFLOW.read_text(encoding="utf-8")
        assert "_internal/app/templates" in text
        assert "_internal/app/static" in text