"""Tests fuer die Excel-Sync-Faehigkeit der neuen Spalten.

Es wird gegen eine frisch gebaute Testmappe gearbeitet - nicht gegen die echte
Arbeitskopie. Geprueft wird, dass die Anwendung die neuen Spalten aus der Datei
liest, unveraendert laesst, wenn nichts geaendert wird, und gezielt beschreibt,
wenn sich etwas aendert.
"""

from __future__ import annotations

import shutil
import sys
from datetime import date
from pathlib import Path

import pytest

PROJEKT = Path(__file__).resolve().parent.parent
if str(PROJEKT) not in sys.path:
    sys.path.insert(0, str(PROJEKT))

from app.dateizugriff.schema import (
    ERWARTETE_SPALTEN,
    SPALTE_CBRN_GROESSE,
    SPALTE_DIENSTKLEIDUNG_GROESSE,
    SPALTE_GF,
    SPALTE_NAME,
    SPALTE_NR,
)
from app.dateizugriff.sync_ordner import SyncOrdnerHelferdatei

# Feste Testspalten: die drei erfwarteten plus ein paar aus dem echten Schema.
_TEST_SPALTEN = (
    SPALTE_NR,
    SPALTE_NAME,
    "Geburtsdatum",
    "Jahresgespräch",
    SPALTE_GF,
    SPALTE_DIENSTKLEIDUNG_GROESSE,
    SPALTE_CBRN_GROESSE,
)


@pytest.fixture
def datei(tmp_path: Path) -> SyncOrdnerHelferdatei:
    """Baut eine minimale Excel-Datei mit den neuen Spalten."""
    import openpyxl

    pfad = tmp_path / "test.xlsx"
    mappe = openpyxl.Workbook()
    blatt = mappe.active
    blatt.title = "Gruppe 1"
    blatt.append(list(_TEST_SPALTEN))
    blatt.append([1, "Anna Beispiel", date(1990, 1, 1), None, "Niklas", "M", "L"])
    blatt.append([2, "Ben Muster", date(1991, 2, 2), "y", None, None, None])
    mappe.save(pfad)
    mappe.close()
    return SyncOrdnerHelferdatei(pfad)


class TestNeueSpaltenImExcel:
    """Lese- und Schreibzugriff auf die neuen Spalten."""

    def test_liest_gf_aus_datei(self, datei: SyncOrdnerHelferdatei):
        personen = datei.lade_personen()
        assert personen[0].wert(SPALTE_GF) == "Niklas"
        assert personen[1].wert(SPALTE_GF) is None

    def test_liest_groessen_aus_datei(self, datei: SyncOrdnerHelferdatei):
        personen = datei.lade_personen()
        assert personen[0].wert(SPALTE_DIENSTKLEIDUNG_GROESSE) == "M"
        assert personen[0].wert(SPALTE_CBRN_GROESSE) == "L"

    def test_spalten_sind_erwartet(self, datei: SyncOrdnerHelferdatei):
        assert datei.spalten("Gruppe 1") == list(_TEST_SPALTEN)

    def test_schreibt_gf(self, datei: SyncOrdnerHelferdatei):
        personen = datei.lade_personen()
        person = personen[1]
        saetze = datei.speichere_person(
            person.schluessel, {SPALTE_GF: "Nino"}
        )
        assert len(saetze) == 1
        assert saetze[0].spalte == SPALTE_GF
        assert saetze[0].neuer_wert == "Nino"

        neu = datei.lade_personen()
        assert neu[1].wert(SPALTE_GF) == "Nino"

    def test_schreibt_kleidung_groesse(self, datei: SyncOrdnerHelferdatei):
        personen = datei.lade_personen()
        person = personen[0]
        saetze = datei.speichere_person(
            person.schluessel, {SPALTE_DIENSTKLEIDUNG_GROESSE: "XL"}
        )
        assert [s.spalte for s in saetze] == [SPALTE_DIENSTKLEIDUNG_GROESSE]
        neu = datei.lade_personen()
        assert neu[0].wert(SPALTE_DIENSTKLEIDUNG_GROESSE) == "XL"

    def test_schreibt_cbrn_groesse(self, datei: SyncOrdnerHelferdatei):
        personen = datei.lade_personen()
        person = personen[0]
        saetze = datei.speichere_person(person.schluessel, {SPALTE_CBRN_GROESSE: "XXL"})
        assert [s.spalte for s in saetze] == [SPALTE_CBRN_GROESSE]
        neu = datei.lade_personen()
        assert neu[0].wert(SPALTE_CBRN_GROESSE) == "XXL"

    def test_unveraenderte_felder_werden_nicht_angefasst(self, datei: SyncOrdnerHelferdatei):
        """Gleicher Wert -> keine Aenderung, keine Protokollsaeze."""
        personen = datei.lade_personen()
        person = personen[0]
        saetze = datei.speichere_person(
            person.schluessel, {SPALTE_GF: "Niklas", SPALTE_DIENSTKLEIDUNG_GROESSE: "M"}
        )
        assert saetze == []

    def test_mehrere_felder_in_einem_schritt(self, datei: SyncOrdnerHelferdatei):
        personen = datei.lade_personen()
        person = personen[1]
        saetze = datei.speichere_person(
            person.schluessel,
            {SPALTE_GF: "Nino", SPALTE_DIENSTKLEIDUNG_GROESSE: "S", SPALTE_CBRN_GROESSE: "M"},
        )
        assert {s.spalte for s in saetze} == {
            SPALTE_GF, SPALTE_DIENSTKLEIDUNG_GROESSE, SPALTE_CBRN_GROESSE,
        }
        neu = datei.lade_personen()
        assert neu[1].wert(SPALTE_GF) == "Nino"
        assert neu[1].wert(SPALTE_DIENSTKLEIDUNG_GROESSE) == "S"
        assert neu[1].wert(SPALTE_CBRN_GROESSE) == "M"


class TestExcelSchemaKompatibilitaet:
    """Die neue Spalte GF fuehrt eine Auswahl - die Datei muss das abbilden."""

    def test_vollstaendige_spalte_liste(self, datei: SyncOrdnerHelferdatei):
        """Alle neuen Spalten gehoeren zur ERWARTETE_SPALTEN."""
        ist = datei.spalten("Gruppe 1")
        for spalte in (SPALTE_GF, SPALTE_DIENSTKLEIDUNG_GROESSE, SPALTE_CBRN_GROESSE):
            assert spalte in ist

    def test_erwartete_spalten_sind_vollstaendig(self):
        """Jede neue Spalte steht in der kanonischen Liste."""
        for spalte in (SPALTE_GF, SPALTE_DIENSTKLEIDUNG_GROESSE, SPALTE_CBRN_GROESSE):
            assert spalte in ERWARTETE_SPALTEN

    def test_neue_person_mit_gf_anlegen(self, datei: SyncOrdnerHelferdatei):
        """lege_person_an uebernimmt GF aus den Werten."""
        schluessel = datei.lege_person_an(
            "Gruppe 1", {SPALTE_NAME: "Neu Helfer", SPALTE_GF: "Nino"}
        )
        personen = datei.lade_personen()
        neu = [p for p in personen if p.name == "Neu Helfer"]
        assert len(neu) == 1
        assert neu[0].wert(SPALTE_GF) == "Nino"