"""Ein Durchmarsch durch die ganze Anwendung - ein TestClient, eine frische Datei.

Jede Testmethode beginnt bei einer eigenen Wegwerf-Datei und einer eigenen
Wegwerf-Datenbank. Anfassen der echten Daten ist ausgeschlossen:

* ``hole_helferdatei`` wird auf allen Importstellen auf die Testdatei umgelenkt,
* die Sicherungs- und Exportordner liegen im Wegwerf-Verzeichnis,
* Microsoft Graph (SharePoint) ist ein Nachbau ohne Netz (``GraphSimulation``).

So werden die Endpunkte so zusammengeschaltet getestet, wie die Anwendung sie
wirklich anbietet - Dashboard, Personal, Gruppenführer, Namen, Export,
Protokoll, Einstellungen und die Synchronisation in beiden Modi.
"""

from __future__ import annotations

import io
import sys
import urllib.parse
from datetime import date
from pathlib import Path

import httpx
import pytest
from fastapi import Form, Request

PROJEKT = Path(__file__).resolve().parent.parent
if str(PROJEKT) not in sys.path:
    sys.path.insert(0, str(PROJEKT))

import app.models  # noqa: F401 - muss vor Base.metadata.create_all importiert sein

from app.config import BENUTZER_COOKIE
from app.database import Base, get_db
from app.dateizugriff.schema import (
    SPALTE_GF,
    ERWARTETE_SPALTEN,
    Person,
)
from app.logic.export import EXPORT_UEBERSCHRIFTEN


# ---------------------------------------------------------------------------
# Wegwerf-Datei im realen Aufbau der fuehrenden Excel-Datei
# ---------------------------------------------------------------------------

def _arbeitsmappe(heute: date, ziel):
    """Fuelle eine Arbeitsmappe (echter Spaltenaufbau) und speichere sie."""
    import openpyxl

    mappe = openpyxl.Workbook()
    blatt = mappe.active
    blatt.title = "Gruppe 1"
    blatt.append(list(ERWARTETE_SPALTEN))

    def zeile(nr: int, name: str, **werte) -> list:
        z = {s: None for s in ERWARTETE_SPALTEN}
        z["Nr"], z["Name"] = nr, name
        z.update(werte)
        return [z.get(s) for s in ERWARTETE_SPALTEN]

    blatt.append(zeile(
        1, "Anna Beispiel",
        Status="aktiv", Telefon="0170 123456", Medizinisch="n",
        **{"Jahresgespräch": "y",
           "G 26.2": date(heute.year + 1, 6, 1),
           "GF": "Niklas",
           "Dienstkleidung Größe": "M", "CBRN Kleidergröße": "L"},
    ))
    blatt.append(zeile(
        2, "Ben Muster",
        Status="aktiv",
        **{"Jahresgespräch": date(heute.year, 1, 1),
           "GF": "Nino"},
    ))
    blatt.append(zeile(
        3, "Chris Test",
        Status="aktiv",
        **{"G 26.2": date(heute.year - 3, 1, 1)},
    ))

    amu = mappe.create_sheet("AMU")
    amu["A1"], amu["B1"] = "Abkürzung", "G 26.2"
    amu["A2"], amu["B2"] = "Bezeichnung", "Atemschutz 2"
    amu["A3"], amu["B3"] = "Zielgruppe", "alle"
    amu["A4"], amu["B4"] = "Turnus", ""
    amu["A5"], amu["B5"] = "freiwillig?", "n"

    ausgeschieden = mappe.create_sheet("Ausgeschieden")
    ausgeschieden.append(["Nr", "Name", "Austrittsdatum"])

    mappe.save(ziel)
    mappe.close()
    return ziel


def _baue_datei(pfad: Path, heute: date) -> Path:
    return _arbeitsmappe(heute, pfad)


def _baue_datei_bytes(heute: date) -> bytes:
    puffer = io.BytesIO()
    _arbeitsmappe(heute, puffer)
    return puffer.getvalue()


# ---------------------------------------------------------------------------
# Nachbau von Microsoft Graph (nichts geht ins Netz)
# ---------------------------------------------------------------------------

class GraphSimulation:
    """Faengt die Graph-Aufrufe ab; die fuehrende Datei liegt im Speicher."""

    def __init__(self, inhalt: bytes) -> None:
        self.inhalt = inhalt
        self.etag = '"abc123"'
        self.online = True
        self.token_zaehler = 0

    def _token_antwort(self) -> httpx.Response:
        self.token_zaehler += 1
        return httpx.Response(
            200,
            json={"access_token": f"token-{self.token_zaehler}", "expires_in": 3600},
        )

    def __call__(self, request: httpx.Request) -> httpx.Response:
        if "login.microsoftonline.com" in request.url.host:
            return self._token_antwort()
        if not self.online:
            raise httpx.ConnectError("Netz nicht erreichbar", request=request)

        pfad = request.url.path
        if pfad.endswith(":/content") and request.method == "GET":
            return httpx.Response(
                200, headers={"etag": self.etag}, content=self.inhalt
            )
        if pfad.endswith(":/content") and request.method == "PUT":
            if request.headers.get("if-match") != self.etag:
                return httpx.Response(
                    412,
                    json={"error": {"message": "Datei wurde zwischenzeitlich geaendert"}},
                )
            self.inhalt = request.content
            self.etag = '"frisch-hochgeladen"'
            return httpx.Response(200, headers={"etag": self.etag})
        if request.method == "GET":
            return httpx.Response(
                200,
                json={
                    "id": "01",
                    "name": "Personal_Bestandsaufnahme.xlsx",
                    "eTag": self.etag,
                    "lastModifiedDateTime": "2026-09-16T10:00:00Z",
                    "size": len(self.inhalt),
                },
            )
        return httpx.Response(400)


# ---------------------------------------------------------------------------
# Testclient mit allen Routen, Wegwerf-Datenbank und Umleitung der Zugriffe
# ---------------------------------------------------------------------------

class _Umgebung:
    def __init__(self, *, client, datei, sitzung, sim=None) -> None:
        self.client = client
        self.datei = datei
        self.sitzung = sitzung
        self.sim = sim


def _baue_web_app(tmp_path: Path, monkeypatch, datei_objekt) -> tuple:
    from fastapi import FastAPI
    from fastapi.responses import RedirectResponse
    from fastapi.testclient import TestClient
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    motor = create_engine(
        f"sqlite:///{tmp_path / 'e2e.db'}",
        connect_args={"check_same_thread": False},
    )
    Base.metadata.create_all(motor)
    Sitzung = sessionmaker(bind=motor, autoflush=False, autocommit=False)

    def _get_db_ersatz():
        db = Sitzung()
        try:
            yield db
        finally:
            db.close()

    # Die echte Arbeitskopie wird nie angefasst: alle Importstellen umlegen.
    for ziel in ("app.deps.hole_helferdatei",
                 "app.routes.helfer.hole_helferdatei",
                 "app.routes.todos.hole_helferdatei",
                 "app.routes.dashboard.hole_helferdatei",
                 "app.routes.einstellungen.hole_helferdatei",
                 "app.routes.export.hole_helferdatei",
                 "app.routes.namen.hole_helferdatei"):
        monkeypatch.setattr(ziel, lambda: datei_objekt)
    # Sicherungen und Exports landen im Wegwerf-Verzeichnis.
    monkeypatch.setattr(
        "app.dateizugriff.sync_ordner.SICHERUNGS_ORDNER", tmp_path / "sicherungen"
    )
    monkeypatch.setattr(
        "app.routes.einstellungen.SICHERUNGS_ORDNER", tmp_path / "sicherungen"
    )
    monkeypatch.setattr("app.routes.export.EXPORT_ORDNER", tmp_path / "export")

    from app.routes import dashboard as dashboard_routen
    from app.routes import einstellungen as einstellungen_routen
    from app.routes import export as export_routen
    from app.routes import helfer as helfer_routen
    from app.routes import namen as namen_routen
    from app.routes import protokoll as protokoll_routen
    from app.routes import todos as todos_routen

    app = FastAPI(title="Ende-zu-Ende-Test")
    for router in (dashboard_routen.router, helfer_routen.router,
                   todos_routen.router, namen_routen.router,
                   export_routen.router, protokoll_routen.router,
                   einstellungen_routen.router):
        app.include_router(router)

    @app.post("/anmelden")
    def anmelden(request: Request, kuerzel: str = Form("")):
        ziel = request.headers.get("referer") or "/"
        antwort = RedirectResponse(ziel, status_code=302)
        antwort.set_cookie(
            BENUTZER_COOKIE, kuerzel.strip()[:40], max_age=60 * 60 * 24 * 365,
            samesite="lax",
        )
        return antwort

    app.dependency_overrides[get_db] = _get_db_ersatz
    return TestClient(app), Sitzung()


@pytest.fixture
def umgebung(tmp_path, monkeypatch):
    from app.dateizugriff.sync_ordner import SyncOrdnerHelferdatei

    datei_objekt = SyncOrdnerHelferdatei(_baue_datei(tmp_path / "datei.xlsx", date.today()))
    client, sitzung = _baue_web_app(tmp_path, monkeypatch, datei_objekt)
    umgebung = _Umgebung(client=client, datei=datei_objekt, sitzung=sitzung)
    yield umgebung
    sitzung.close()


@pytest.fixture
def umgebung_graph(tmp_path, monkeypatch):
    from app.dateizugriff.graph import GraphClient, GraphHelferdatei

    sim = GraphSimulation(_baue_datei_bytes(date.today()))
    graph_client = GraphClient(
        tenant="t", client_id="c", client_secret="s",
        transport=httpx.MockTransport(sim), token_vorbelegt="token-0",
    )
    datei_objekt = GraphHelferdatei(
        client=graph_client,
        site_id="maltesercloud.sharepoint.com,sites,Fhrung-Behandlungszug",
        pfad_in_bibliothek="Freigegebene Dokumente/Helfer - Bestand/Personal_Bestandsaufnahme.xlsx",
        lokal=tmp_path / "kopie" / "Personal_Bestandsaufnahme.xlsx",
    )
    client, sitzung = _baue_web_app(tmp_path, monkeypatch, datei_objekt)
    umgebung = _Umgebung(client=client, datei=datei_objekt, sitzung=sitzung, sim=sim)
    yield umgebung
    sitzung.close()
    graph_client.schliessen()


def _person_nach_name(datei, name: str) -> Person:
    return next(p for p in datei.lade_personen() if p.name == name)


def _person_in_ausgeschieden(datei, name: str) -> Person:
    return next(p for p in datei.lade_ausgeschiedene() if p.name == name)


def _aenderungen(sitzung):
    from sqlalchemy import select

    from app import models

    return list(sitzung.scalars(select(models.Aenderung).order_by(models.Aenderung.id)).all())


def _aenderungen_summe(sitzung) -> int:
    from sqlalchemy import func, select

    from app import models

    return sitzung.scalar(select(func.count(models.Aenderung.id))) or 0


# ===========================================================================
# Lokaler Modus: der Durchmarsch durch die Oberflaeche
# ===========================================================================

class TestDashboardUndSyncLeiste:
    def test_dashboard_laedt_mit_sync_leiste(self, umgebung):
        html = umgebung.client.get("/").text
        assert "3 Helferinnen und Helfer" in html
        assert "Modus: lokaler Ordner" in html
        assert "lokale Datei gefunden" in html
        assert "Jetzt synchronisieren" in html
        assert "Bitte tragen Sie oben rechts Ihr Kürzel ein" in html

    def test_dashboard_filter_zeigt_nur_handlungsbedarf(self, umgebung):
        html = umgebung.client.get("/", params={"filter": "abgelaufen"}).text
        # Nur Chris hat eine abgelaufene Untersuchung.
        assert "Chris Test" in html
        assert "Anna Beispiel" not in html
        assert "1 von 3 Personen angezeigt" in html


class TestHelferlisteUndProfil:
    def test_helferliste_zeigt_alle_mit_gf_filter(self, umgebung):
        html = umgebung.client.get("/helfer").text
        assert "3 aktive Personen" in html
        assert "Anna Beispiel" in html and "Ben Muster" in html and "Chris Test" in html

        html = umgebung.client.get("/helfer", params={"gf": "Niklas"}).text
        assert "Anna Beispiel" in html
        assert "Ben Muster" not in html and "Chris Test" not in html

        html = umgebung.client.get("/helfer", params={"gf": "ohne"}).text
        assert "Chris Test" in html
        assert "Anna Beispiel" not in html

        html = umgebung.client.get("/helfer", params={"suche": "ben"}).text
        assert "Ben Muster" in html
        assert "Anna Beispiel" not in html and "Chris Test" not in html

    def test_profil_oeffnet_person(self, umgebung):
        anna = _person_nach_name(umgebung.datei, "Anna Beispiel")
        html = umgebung.client.get(f"/helfer/{anna.schluessel.kennung}").text
        assert "Anna Beispiel" in html
        assert "GF: Niklas" in html
        assert "Speichern" in html
        assert "Aus der Ortsgruppe ausgliedern" in html

    def test_person_nicht_gefunden_liefert_404(self, umgebung):
        r = umgebung.client.get("/helfer/Gruppe 1|99|Niemand")
        assert r.status_code == 404
        assert "nicht gefunden" in r.text


class TestHelferSchreiben:
    def test_feld_und_bemerkung_wird_gespeichert(self, umgebung):
        anna = _person_nach_name(umgebung.datei, "Anna Beispiel")
        r = umgebung.client.post(
            f"/helfer/{anna.schluessel.kennung}",
            data={"feld:Telefon": "0150 9999", "bemerkung": "Nur intern"},
            follow_redirects=False,
        )
        assert r.status_code == 302
        neu = _person_nach_name(umgebung.datei, "Anna Beispiel")
        assert neu.wert("Telefon") == "0150 9999"

        from sqlalchemy import select

        from app import models

        zusatz = umgebung.sitzung.scalar(
            select(models.Helferzusatz).where(models.Helferzusatz.name == "Anna Beispiel")
        )
        assert zusatz is not None and zusatz.bemerkung == "Nur intern"
        eintraege = _aenderungen(umgebung.sitzung)
        assert any(e.spalte == "Telefon" and e.neuer_wert == "0150 9999" for e in eintraege)

    def test_name_aendern_verschiebt_zusatz(self, umgebung):
        anna = _person_nach_name(umgebung.datei, "Anna Beispiel")
        r = umgebung.client.post(
            f"/helfer/{anna.schluessel.kennung}",
            data={"feld:Name": "Anna Beispiel-Zwei", "bemerkung": "mitgezogen"},
            follow_redirects=False,
        )
        assert r.status_code == 302
        assert urllib.parse.unquote(r.headers["location"]).startswith(
            "/helfer/Gruppe 1|2|Anna Beispiel-Zwei"
        )
        namen = [p.name for p in umgebung.datei.lade_personen()]
        assert "Anna Beispiel-Zwei" in namen and "Anna Beispiel" not in namen

        from sqlalchemy import select

        from app import models

        zusatz = umgebung.sitzung.scalar(
            select(models.Helferzusatz).where(models.Helferzusatz.name == "Anna Beispiel-Zwei")
        )
        assert zusatz is not None and zusatz.bemerkung == "mitgezogen"

    def test_person_anlegen_erscheint_in_liste(self, umgebung):
        r = umgebung.client.post(
            "/neue-person",
            data={"blatt": "Gruppe 1", "feld:Name": "Dana Neu", "feld:GF": "Nino"},
            follow_redirects=False,
        )
        assert r.status_code == 302
        neu = _person_nach_name(umgebung.datei, "Dana Neu")
        assert neu.wert(SPALTE_GF) == "Nino"
        html = umgebung.client.get("/helfer", params={"gf": "Nino"}).text
        assert "Dana Neu" in html
        assert _aenderungen_summe(umgebung.sitzung) >= 1

    def test_ausgliedern_und_zurueckholen(self, umgebung):
        chris = _person_nach_name(umgebung.datei, "Chris Test")
        r = umgebung.client.post(
            "/ausgliedern",
            data={"kennung": chris.schluessel.kennung, "austrittsdatum": "15.09.2026"},
            follow_redirects=False,
        )
        assert r.status_code == 302
        assert urllib.parse.unquote(r.headers["location"]).startswith("/ausgeschieden")
        assert "Chris Test" not in [p.name for p in umgebung.datei.lade_personen()]
        aus = _person_in_ausgeschieden(umgebung.datei, "Chris Test")
        assert aus.wert("Austrittsdatum") == date(2026, 9, 15)
        assert "Chris Test" in umgebung.client.get("/ausgeschieden").text

        r = umgebung.client.post(
            "/zurueckholen", data={"kennung": aus.schluessel.kennung},
            follow_redirects=False,
        )
        assert r.status_code == 302
        assert "Chris Test" in [p.name for p in umgebung.datei.lade_personen()]


class TestGruppenfuehrerWorkflow:
    def test_seite_zeigt_gruppen_und_aufgaben(self, umgebung):
        html = umgebung.client.get("/gruppenfuehrer").text
        assert "Gruppenführer" in html
        assert "Ohne Zuordnung" in html
        assert "1 Aufgabe offen" in html      # Anna (1 Jahrespflicht, Groessen vorhanden)
        assert "3 Aufgaben offen" in html     # Ben (G 26.2 fehlt + 2 Groessen)
        assert "4 Aufgaben offen" in html     # Chris (1 Pflicht + 1 AMU + 2 Groessen)
        assert 'pill abgelaufen">1 Untersuchung' in html
        assert "Dienstkleidung-Größe fehlt" in html and "CBRN-Größe fehlt" in html

    def test_schnelle_zuweisung_und_filter(self, umgebung):
        chris = _person_nach_name(umgebung.datei, "Chris Test")
        r = umgebung.client.post(
            "/gf-zuweisen",
            data={"kennung": chris.schluessel.kennung, "gf": "Nino"},
            headers={"referer": "/helfer?gf=ohne"},
            follow_redirects=False,
        )
        assert r.status_code == 302
        assert _person_nach_name(umgebung.datei, "Chris Test").wert(SPALTE_GF) == "Nino"
        assert "Chris Test" in umgebung.client.get("/helfer", params={"gf": "Nino"}).text

    def test_ungueltiger_gf_wird_abgelehnt(self, umgebung):
        chris = _person_nach_name(umgebung.datei, "Chris Test")
        r = umgebung.client.post(
            "/gf-zuweisen", data={"kennung": chris.schluessel.kennung, "gf": "Herbert"}
        )
        assert r.status_code == 400
        assert _person_nach_name(umgebung.datei, "Chris Test").wert(SPALTE_GF) is None


class TestNamenUndProtokoll:
    def test_namen_kontrolle_bestaetigt_aufteilung(self, umgebung):
        anna = _person_nach_name(umgebung.datei, "Anna Beispiel")
        html = umgebung.client.get("/namen").text
        assert "Anna Beispiel" in html
        assert "3 Name(n) bestätigt" not in html  # noch ungeprueft

        r = umgebung.client.post(
            "/namen",
            data={
                f"vorname:{anna.schluessel.kennung}": "Anna",
                f"nachname:{anna.schluessel.kennung}": "Beispiel",
            },
            headers={"referer": "/namen"},
            follow_redirects=False,
        )
        assert r.status_code == 302
        assert urllib.parse.unquote(r.headers["location"]) == "/namen?meldung=1 Name(n) bestätigt."

        from sqlalchemy import select

        from app import models

        zusatz = umgebung.sitzung.scalar(
            select(models.Helferzusatz).where(models.Helferzusatz.name == "Anna Beispiel")
        )
        assert zusatz is not None and zusatz.name_geprueft is True

    def test_anmelden_setzt_kuerzel_und_protokolliert(self, umgebung):
        anna = _person_nach_name(umgebung.datei, "Anna Beispiel")
        umgebung.client.post("/anmelden", data={"kuerzel": "LS"}, headers={"referer": "/"})
        umgebung.client.post(
            f"/helfer/{anna.schluessel.kennung}",
            data={"feld:Telefon": "0177 1111"},
            follow_redirects=False,
        )
        eintraege = _aenderungen(umgebung.sitzung)
        assert any(e.kuerzel == "LS" and e.spalte == "Telefon" for e in eintraege)

        html = umgebung.client.get("/protokoll").text
        assert "Änderungsprotokoll" in html
        assert "LS" in html
        assert "0177 1111" in html


class TestExportRoundTrip:
    def test_export_seite_beschreibt_spalten(self, umgebung):
        html = umgebung.client.get("/export").text
        assert "Export für die PSA-Beauftragte" in html
        assert "Nachname" in html
        assert "3" in html  # anzahl_personen in der Unterzeile

    def test_export_erzeugt_wiederverwendbare_datei(self, umgebung):
        r = umgebung.client.post("/export", follow_redirects=False)
        assert r.status_code == 302
        meldung = urllib.parse.unquote(r.headers["location"])
        assert "Export mit 3 Personen erzeugt" in meldung

        # Die Datei liegt im umgelenkten Exportordner und ist wieder lesbar.
        dateien = sorted(_export_ordner(umgebung).glob("*.xlsx"))
        assert len(dateien) == 1

        import openpyxl

        mappe = openpyxl.load_workbook(dateien[0])
        blatt = mappe.active
        kopf = [zelle.value for zelle in next(blatt.iter_rows(max_row=1))]
        assert kopf == list(EXPORT_UEBERSCHRIFTEN)
        daten = list(blatt.iter_rows(min_row=2, values_only=True))
        assert len(daten) == 3
        # Namen werden auch ohne Bestätigung automatisch getrennt.
        inhalte = [str(zelle or "").strip() for zelle in daten[0][:2]]
        assert "Anna" in inhalte and "Beispiel" in inhalte
        mappe.close()


def _export_ordner(umgebung) -> Path:
    import app.routes.export as export_routen

    return export_routen.EXPORT_ORDNER


class TestEinstellungenUndSyncLokal:
    def test_einstellungen_zeigen_zustand(self, umgebung):
        html = umgebung.client.get("/einstellungen").text
        assert "Synchronisation" in html
        assert "lokaler Sync-Ordner" in html
        assert "unverändert" in html          # Spaltenaufbau der Datei passt
        assert "G 26.2" in html               # AMU-Katalog wird angezeigt

    def test_verbindung_testen_lokal(self, umgebung):
        r = umgebung.client.post(
            "/sync/test", headers={"referer": "/einstellungen"}, follow_redirects=False
        )
        assert r.status_code == 302
        assert "Lokaler Ordner erreichbar" in urllib.parse.unquote(r.headers["location"])

    def test_synchronisieren_lokal_ist_leerlauf(self, umgebung):
        r = umgebung.client.post(
            "/sync/now", headers={"referer": "/einstellungen"}, follow_redirects=False
        )
        assert r.status_code == 302
        assert "Lokaler Modus" in urllib.parse.unquote(r.headers["location"])


# ===========================================================================
# SharePoint-Modus (Graph nachgestellt): gleiche Oberflaeche, ferner Speicher
# ===========================================================================

class TestGraphEndToEnd:
    def test_dashboard_zeigt_sharepoint_modus(self, umgebung_graph):
        html = umgebung_graph.client.get("/").text
        assert "Modus: SharePoint" in html
        assert "verbunden" in html
        assert "Jetzt synchronisieren" in html

    def test_einstellungen_zeigen_sharepoint_details(self, umgebung_graph):
        html = umgebung_graph.client.get("/einstellungen").text
        assert "Microsoft SharePoint (Graph)" in html
        assert "Lokale Arbeitskopie" in html
        assert "Personal_Bestandsaufnahme.xlsx" in html

    def test_sync_testen_sharepoint(self, umgebung_graph):
        r = umgebung_graph.client.post(
            "/sync/test", headers={"referer": "/einstellungen"}, follow_redirects=False
        )
        assert r.status_code == 302
        assert "verbunden" in urllib.parse.unquote(r.headers["location"])

    def test_sync_jetzt_sharepoint(self, umgebung_graph):
        r = umgebung_graph.client.post(
            "/sync/now", headers={"referer": "/einstellungen"}, follow_redirects=False
        )
        assert r.status_code == 302
        assert "übernommen" in urllib.parse.unquote(r.headers["location"])

    def test_gf_zuweisen_laeuft_ueber_sharepoint(self, umgebung_graph):
        anna = _person_nach_name(umgebung_graph.datei, "Anna Beispiel")
        r = umgebung_graph.client.post(
            "/gf-zuweisen",
            data={"kennung": anna.schluessel.kennung, "gf": "Nino"},
            headers={"referer": "/helfer"},
            follow_redirects=False,
        )
        assert r.status_code == 302
        assert _person_nach_name(umgebung_graph.datei, "Anna Beispiel").wert(SPALTE_GF) == "Nino"
        assert umgebung_graph.datei._ausstehend is False

        # Im fernen Speicher (GraphSimulation) liegt die Aenderung.
        import openpyxl

        mappe = openpyxl.load_workbook(io.BytesIO(umgebung_graph.sim.inhalt))
        blatt = mappe["Gruppe 1"]
        kopf = [zelle.value for zelle in next(blatt.iter_rows(max_row=1))]
        gf_spalte = kopf.index("GF")
        namen = {
            str(zeile[kopf.index("Name")]).strip(): zeile[gf_spalte]
            for zeile in blatt.iter_rows(min_row=2, values_only=True)
            if zeile[kopf.index("Name")] not in (None, "")
        }
        assert namen["Anna Beispiel"] == "Nino"
        mappe.close()