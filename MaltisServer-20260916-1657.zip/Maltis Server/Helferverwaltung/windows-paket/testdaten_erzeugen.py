"""Erzeugt aus der echten Arbeitskopie eine anonyme Testdatei.

Das Windows-Testpaket geht an mehrere Tester. Echte Klarnamen, Geburtsdaten,
Mitgliedsnummern und vor allem die arbeitsmedizinischen Befunde (G20-G42,
Masern) duerfen dabei nicht mitgehen. Dieses Skript baut deshalb eine Datei,
die im Aufbau exakt der echten entspricht - gleiche Blaetter, gleiche Spalten,
gleiche Formate, gleiche Zellformatierung - in der aber jede Person erfunden
ist.

Bewusst *nicht* veraendert werden die fachlichen Auspraegungen (y/n, RS/NotSan,
GF/ZF, Lehrgangsvermerke). Nur so sehen die Tester dieselben Handlungsbedarfe
wie im Echtbetrieb: abgelaufene Fristen, fehlende Angaben, offene Freigaben.
Die Termine werden um wenige Wochen verschoben, damit sich aus einem Datum
keine reale Person zurueckrechnen laesst, die Verteilung "teils abgelaufen,
teils bald faellig" aber erhalten bleibt.

Fehlt die echte Arbeitskopie (etwa im CI-Build, wo sensible Daten bewusst
nicht im Repository liegen), wird eine vollstaendige, strukturgleiche Datei
mit erfundenen Personen erzeugt. Das Paket laesst sich so auch ohne die
Originaldatei bauen und testen.

Aufruf:  python windows-paket/testdaten_erzeugen.py
"""

from __future__ import annotations

import random
import shutil
import sys
from datetime import datetime, timedelta
from pathlib import Path

import openpyxl

BASIS = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASIS))

from app.dateizugriff import paket  # noqa: E402
from app.dateizugriff.schema import (  # noqa: E402
    AMU_SPALTEN,
    ERWARTETE_SPALTEN,
    FORTBILDUNGS_SPALTEN,
    GF_NIKLAS,
    GF_NINO,
    SPALTE_NAME,
)

VORLAGE = BASIS / "data" / "arbeitskopie" / "Personal_Bestandsaufnahme.xlsx"
ZIEL = Path(__file__).resolve().parent / "testdaten" / "Personal_Bestandsaufnahme.xlsx"

# Fester Startwert: zwei Laeufe erzeugen dieselbe Testdatei. Das hilft, wenn
# ein Tester einen Fehler meldet - alle reden dann ueber dieselben Personen.
ZUFALL = random.Random(20260911)

VORNAMEN = [
    "Almut", "Bastian", "Carla", "Davide", "Elif", "Fenna", "Gero", "Hanne",
    "Ilja", "Jorin", "Katja", "Lennart", "Mareike", "Nils", "Oona", "Piet",
    "Quirin", "Ronja", "Sören", "Thies", "Ulrike", "Vincent", "Wiebke",
    "Xenia", "Yannick", "Zeynep", "Anneke", "Bjarne", "Cosima", "Dennis",
    "Emma", "Finn", "Greta", "Hendrik", "Imke", "Jasper", "Kira", "Lasse",
    "Malin", "Nele", "Ole", "Paula", "Rike", "Tomke", "Uwe", "Birte",
]
# Bewusst nicht im Topf: Vornamen von Personen, die es in der Ortsgruppe
# wirklich gibt. Ein Tester, der einen bekannten Namen liest, glaubt sonst,
# hier staenden doch echte Daten - und genau das soll das Paket ausschliessen.
VORNAMEN = [v for v in VORNAMEN if v not in {"Lasse", "Sven", "Niklas"}]
NACHNAMEN = [
    "Ahlers", "Bohnsack", "Clausen", "Dettmer", "Eggers", "Frahm", "Gerdes",
    "Harms", "Ipsen", "Janssen", "Kruse", "Lorenzen", "Meinert", "Nissen",
    "Ohlsen", "Petersen", "Quast", "Rathje", "Schlüter", "Thomsen", "Uhl",
    "Voigt", "Wichmann", "Ziegler", "Boysen", "Carstens", "Dohrn", "Evers",
    "Fock", "Grotelüschen", "Hinrichs", "Jürgens", "Köster", "Lührs",
    "Matthiesen", "Nagel", "Oldenburg", "Prahl", "Reimers", "Stahmer",
    "Tiedemann", "Ulrichs", "Vollmer", "Westphal", "Zimmer",
]

# Spalten, deren Inhalt eine Person identifiziert und darum neu erfunden wird.
NAMENSSPALTE = "Name"
GEBURTSSPALTE = "Geburtsdatum"
MITGLIEDSSPALTE = "Mitglied?"
TELEFONSPALTE = "Telefon"

# Termine werden um hoechstens so viele Tage verschoben.
JITTER_TAGE = 21


def _namenstopf() -> list[str]:
    """Eindeutige Fantasienamen in zufaelliger, aber fester Reihenfolge."""
    paare = [f"{v} {n}" for v in VORNAMEN for n in NACHNAMEN]
    ZUFALL.shuffle(paare)
    return paare


def _verschiebe(wert, spalte: str):
    """Termine leicht verschieben, Geburtsdaten komplett neu wuerfeln."""
    if not isinstance(wert, datetime):
        return wert
    if spalte == GEBURTSSPALTE:
        # 18 bis 62 Jahre alt, damit die Altersfilter realistisch greifen.
        alter_tage = ZUFALL.randint(18 * 365, 62 * 365)
        return datetime(2026, 9, 11) - timedelta(days=alter_tage)
    return wert + timedelta(days=ZUFALL.randint(-JITTER_TAGE, JITTER_TAGE))


def _anonymisiere_personenblatt(blatt, namen: list[str], verbrauchte: dict) -> int:
    """Ersetzt Namen, Geburtsdatum, Mitgliedsnummer und Telefon eines Blattes."""
    kopf = [z.value for z in next(blatt.iter_rows(min_row=1, max_row=1))]
    spalte_von_index = {i: (k or "") for i, k in enumerate(kopf)}

    geaendert = 0
    for zeile in blatt.iter_rows(min_row=2):
        # Zeilen ohne Namen sind Leerzeilen der Vorlage - unangetastet lassen.
        namenszelle = next(
            (z for i, z in enumerate(zeile) if spalte_von_index.get(i) == NAMENSSPALTE),
            None,
        )
        if namenszelle is None or not str(namenszelle.value or "").strip():
            continue

        echt = str(namenszelle.value).strip()
        if echt not in verbrauchte:
            verbrauchte[echt] = namen.pop()
        ersatz = verbrauchte[echt]

        for i, zelle in enumerate(zeile):
            spalte = spalte_von_index.get(i, "")
            if spalte == NAMENSSPALTE:
                zelle.value = ersatz
            elif spalte == MITGLIEDSSPALTE and str(zelle.value or "").strip().isdigit():
                # Gleiche Laenge wie echte Mitgliedsnummern, aber frei erfunden.
                zelle.value = str(ZUFALL.randint(8000000000, 8999999999))
            elif spalte == TELEFONSPALTE and str(zelle.value or "").strip():
                zelle.value = f"0170 {ZUFALL.randint(1000000, 9999999)}"
            else:
                zelle.value = _verschiebe(zelle.value, spalte)
        geaendert += 1
    return geaendert


def _anonymisiere_divera(blatt, namen: list[str], verbrauchte: dict) -> None:
    """Das Divera-Blatt ist eine freie Notizliste mit Namen darin."""
    for zeile in blatt.iter_rows(min_row=2):
        for zelle in zeile:
            text = str(zelle.value or "").strip()
            if not text:
                continue
            if text in verbrauchte:
                zelle.value = verbrauchte[text]
            else:
                # Freitext wie "Nino spricht Alessandro an" - ganz ersetzen,
                # er kann beliebige Namen enthalten.
                zelle.value = f"Notiz {namen.pop().split()[0]}"


def _anonymisiere_amu(blatt) -> None:
    """In Zeile 3 ("Zielgruppe") steht vereinzelt ein Vorname."""
    for zelle in next(blatt.iter_rows(min_row=3, max_row=3)):
        text = str(zelle.value or "").strip()
        if text and text not in {"Zielgruppe", "alle"} and " " not in text:
            zelle.value = "Einzelfall"


def _erzeuge_ohne_vorlage() -> str:
    """Baut eine strukturgleiche Testdatei mit erfundenen Personen.

    Wird benutzt, wenn die echte Arbeitskopie nicht vorliegt (CI-Build).
    Das Blatt ``Gruppe 1`` traegt die kompletten erwarteten Spalten inklusive
    der neuen (GF, Dienstkleidung Groesse, CBRN Kleidergroesse); das Blatt
    ``AMU`` bekommt die Katalogstruktur (5 Zeilen), damit die Anwendung sie
    lesen kann.
    """
    from datetime import date as _date

    mappe = openpyxl.Workbook()
    blatt = mappe.active
    blatt.title = "Gruppe 1"

    kopf = list(ERWARTETE_SPALTEN)
    blatt.append(kopf)

    namen = _namenstopf()
    jahr = 2026
    for _ in range(6):
        nr = blatt.max_row
        vorname, nachname = namen.pop().split(" ", 1)
        geburt = _date(jahr, 1, 1) - timedelta(days=ZUFALL.randint(18 * 365, 55 * 365))
        eintritt = _date(jahr, 9, 11) - timedelta(days=ZUFALL.randint(365, 3000))
        gespraech = _date(jahr, ZUFALL.randint(1, 8), ZUFALL.randint(1, 28))
        gf = ZUFALL.choice([GF_NIKLAS, GF_NINO])
        groesse = ZUFALL.choice(["S", "M", "L", "XL"])

        zeile = [""] * len(kopf)
        zeile[0] = nr                       # Nr
        zeile[1] = f"{vorname} {nachname}"  # Name
        zeile[2] = geburt                    # Geburtsdatum
        zeile[3] = eintritt                  # Eintrittsdatum
        zeile[5] = gespraech                 # Jahresgespräch
        zeile[7] = "y"                       # Eigene Dienstkleidung
        zeile[8] = ZUFALL.choice(["RS", "NotSan", "RS, NFS Azubi"])   # Medizinisch
        zeile[11] = ZUFALL.choice(["B", "CE", "C1"])                  # Führerschein
        zeile[len(kopf) - 3] = gf
        zeile[len(kopf) - 2] = groesse
        zeile[len(kopf) - 1] = groesse
        blatt.append(zeile)

    # AMU-Katalog in der erwarteten Form (5 Zeilen, die horizontalen 12 Spalten).
    amu = mappe.create_sheet("AMU")
    eintraege = [
        ("G20", "Lichtschirmarbeit", "alle", "jaehrlich", "n"),
        ("G24", "Haut", "alle", "jaehrlich", "n"),
        ("G25", "Fahren", "KF C", "jaehrlich", "n"),
        ("G 26.2", "Atemschutz", "alle", "jaehrlich", "n"),
        ("G 37", "Buerotätigkeit", "alle", "jaehrlich", "n"),
        ("G 42", "Pflege", "alle", "jaehrlich", "n"),
    ]
    amu.cell(row=1, column=1).value = "Spalte"
    for i, (abk, bez, zielgruppe, turnus, freiwillig) in enumerate(eintraege, start=2):
        amu.cell(row=1, column=i).value = abk
        amu.cell(row=2, column=i).value = bez
        amu.cell(row=3, column=i).value = zielgruppe
        amu.cell(row=4, column=i).value = turnus
        amu.cell(row=5, column=i).value = freiwillig

    # Blatt der Ausgeschiedenen mit denselben Spalten.
    ausgeschieden = mappe.create_sheet("Ausgeschieden")
    ausgeschieden.append(kopf)

    ZIEL.parent.mkdir(parents=True, exist_ok=True)
    mappe.save(ZIEL)
    mappe.close()
    return "Ohne Vorlage erzeugt: strukturgleiche Datei mit erfundenen Personen."


def main() -> int:
    if not VORLAGE.exists():
        # Keine echte Arbeitskopie (CI): eine strukturgleiche Testdatei bauen.
        try:
            hinweis = _erzeuge_ohne_vorlage()
        except Exception as fehler:  # noqa: BLE001
            print(f"FEHLER: Testdatei konnte nicht ohne Vorlage erzeugt werden: {fehler}")
            return 1
        print(f"Testdatei geschrieben: {ZIEL}")
        print(f"  {hinweis}")
        return 0

    ZIEL.parent.mkdir(parents=True, exist_ok=True)
    mappe = openpyxl.load_workbook(VORLAGE)

    namen = _namenstopf()
    verbrauchte: dict[str, str] = {}

    anzahl = 0
    for blattname in ("Gruppe 1", "Gruppe 2", "Ausgeschieden"):
        if blattname in mappe.sheetnames:
            anzahl += _anonymisiere_personenblatt(mappe[blattname], namen, verbrauchte)
    if "Divera" in mappe.sheetnames:
        _anonymisiere_divera(mappe["Divera"], namen, verbrauchte)
    if "AMU" in mappe.sheetnames:
        _anonymisiere_amu(mappe["AMU"])

    mappe.save(ZIEL)

    # openpyxl verliert beim Speichern SharePoint-Metadaten und
    # Druckeinstellungen. Die Anwendung holt sie im Echtbetrieb zurueck - die
    # Testdatei soll denselben Aufbau haben, sonst testen wir eine Datei, die
    # es so nie gibt.
    zurueckgeholt = paket.stelle_paketteile_wieder_her(VORLAGE, ZIEL)

    print(f"Testdatei geschrieben: {ZIEL}")
    print(f"  anonymisierte Personen: {anzahl}")
    print(f"  zurueckgeholte Paketteile: {len(zurueckgeholt)}")

    # Gegenprobe: taucht noch ein echter Name in der fertigen Datei auf?
    roh = ZIEL.read_bytes().decode("latin-1", errors="ignore")
    treffer = [echt for echt in verbrauchte if echt and echt in roh]
    if treffer:
        print(f"  ACHTUNG: {len(treffer)} echte Namen noch enthalten: {treffer[:5]}")
        return 1
    print("  Gegenprobe: kein echter Name mehr in der Datei enthalten.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
