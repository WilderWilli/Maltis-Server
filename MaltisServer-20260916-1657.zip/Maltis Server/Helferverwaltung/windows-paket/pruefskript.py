"""Bedient die laufende Anwendung wie ein Browser und prueft das Ergebnis.

Wird von pruefen.sh im Wine-Container gegen die gebaute EXE gestartet.
Beendet sich mit Rueckgabewert 1, sobald etwas nicht stimmt.
"""

from __future__ import annotations

import html
import re
import sys
import urllib.parse
import urllib.request
from html.parser import HTMLParser

BASIS = "http://127.0.0.1:8001"
NEUE_NUMMER = "0151 99887766"

# Namen aus der echten Arbeitskopie. Taucht einer davon auf, ist versehentlich
# echtes Personal ins Paket geraten.
ECHTE_NAMEN = ("Priesmeyer", "Jargstorff", "Holtkamp", "Volquardsen",
               "Marquardt", "Griebenow", "Schakat")

fehler = 0


def melde(text: str, gut: bool = True) -> None:
    global fehler
    print(f"  {'' if gut else 'FEHLER: '}{text}")
    if not gut:
        fehler += 1


def hole(pfad: str) -> tuple[int, str]:
    with urllib.request.urlopen(BASIS + pfad, timeout=30) as a:
        return a.status, a.read().decode("utf-8", "ignore")


class Formular(HTMLParser):
    """Sammelt die Felder des Personenformulars so ein, wie ein Browser sie sendet."""

    def __init__(self):
        super().__init__()
        self.drin = False
        self.felder: list[tuple[str, str]] = []
        self.auswahl = None
        self.gewaehlt = None
        self.erster = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "form" and a.get("action", "").startswith("/helfer/"):
            self.drin = True
        elif not self.drin:
            return
        elif tag == "input" and a.get("name") and a.get("type") in (None, "text", "hidden", "date"):
            self.felder.append((a["name"], a.get("value", "")))
        elif tag == "select" and a.get("name"):
            self.auswahl, self.gewaehlt, self.erster = a["name"], None, None
        elif tag == "option" and self.auswahl:
            wert = a.get("value", "")
            if self.erster is None:
                self.erster = wert
            if "selected" in a:
                self.gewaehlt = wert

    def handle_endtag(self, tag):
        if tag == "select" and self.auswahl:
            wert = self.gewaehlt if self.gewaehlt is not None else (self.erster or "")
            self.felder.append((self.auswahl, wert))
            self.auswahl = None
        elif tag == "form" and self.drin:
            self.drin = False


print("\n-- Erreichbarkeit --")
for pfad in ("/", "/helfer", "/ausgeschieden", "/namen", "/export",
             "/protokoll", "/einstellungen", "/static/style.css"):
    try:
        status, inhalt = hole(pfad)
        melde(f"{status}  {pfad:<20} {len(inhalt):>7} Bytes", status == 200)
    except Exception as e:  # noqa: BLE001
        melde(f"{pfad} nicht erreichbar: {e}", False)

print("\n-- Testdaten statt echter Daten --")
_, liste = hole("/helfer")
gefunden = [n for n in ECHTE_NAMEN if n in liste]
melde(f"echte Namen in der Ausgabe: {gefunden}" if gefunden
      else "keine echten Namen in der Personalliste", not gefunden)

print("\n-- Aendern und Zurueckschreiben --")
verweise = re.findall(r'href="(/helfer/[^"]+)"', liste)
if not verweise:
    melde("keine Person in der Liste gefunden", False)
    sys.exit(1)

ziel = urllib.parse.quote(html.unescape(verweise[0]), safe="/")
_, seite = hole(ziel)
formular = Formular()
formular.feed(seite)

feldname = next((n for n, _ in formular.felder if n.lower().endswith("telefon")), None)
if feldname is None:
    melde(f"kein Telefonfeld im Formular. Felder: {[n for n, _ in formular.felder][:10]}", False)
else:
    daten = [(n, NEUE_NUMMER if n == feldname else w) for n, w in formular.felder]
    anfrage = urllib.request.Request(
        BASIS + ziel,
        data=urllib.parse.urlencode(daten, encoding="utf-8").encode(),
        method="POST",
    )
    anfrage.add_header("Content-Type", "application/x-www-form-urlencoded")
    with urllib.request.urlopen(anfrage, timeout=60) as a:
        melde(f"gespeichert: HTTP {a.status} ({len(formular.felder)} Felder)", a.status == 200)

    _, nachher = hole(ziel)
    melde("Wert steht wieder im Profil", NEUE_NUMMER in nachher)

    _, protokoll = hole("/protokoll")
    melde("Aenderung steht im Protokoll", NEUE_NUMMER in protokoll)

print("\n-- Excel-Datei auf der Platte --")
try:
    import openpyxl

    mappe = openpyxl.load_workbook(r"data\arbeitskopie\Personal_Bestandsaufnahme.xlsx")
    blatt = mappe["Gruppe 1"]
    kopf = [z.value for z in next(blatt.iter_rows(min_row=1, max_row=1))]
    spalte = kopf.index("Telefon")
    werte = [r[spalte] for r in blatt.iter_rows(min_row=2, values_only=True) if r[spalte]]
    melde(f"Telefonwerte in der Datei: {werte}", NEUE_NUMMER in werte)
except Exception as e:  # noqa: BLE001
    melde(f"Excel-Datei nicht lesbar: {e}", False)

print(f"\n-- {'Alles in Ordnung' if not fehler else str(fehler) + ' Fehler'} --")
sys.exit(1 if fehler else 0)
