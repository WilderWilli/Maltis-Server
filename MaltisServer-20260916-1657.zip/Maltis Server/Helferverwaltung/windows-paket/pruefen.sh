#!/usr/bin/env bash
# Prueft das gebaute Windows-Paket, indem es die EXE unter Wine wirklich
# startet und die Anwendung bedient (siehe pruefskript.py).
#
# Der Grund fuer diesen Aufwand: gebaut wird unter Linux, benutzt wird das
# Paket auf fremden Windows-Rechnern, auf die wir keinen Blick haben. Ohne
# diesen Durchlauf ginge ein Paket heraus, das noch nie gelaufen ist - beim
# ersten Versuch scheiterte genau daran der Start (ein fehlendes Untermodul),
# ohne dass es beim Bauen aufgefallen waere.
#
# Was Wine nicht abdecken kann: das Symbol im Infobereich braucht eine
# Bildschirmsitzung und schlaegt hier immer fehl. Geprueft wird deshalb, dass
# stattdessen das Ersatzfenster einspringt.
set -euo pipefail

PAKET="$(cd "$(dirname "$0")" && pwd)"
IMAGE="helferverwaltung-bau:latest"

if [ ! -f "$PAKET/dist/Helferverwaltung/Helferverwaltung.exe" ]; then
  echo "FEHLER: Kein gebautes Paket gefunden. Erst ./bauen.sh ausfuehren."
  exit 1
fi

docker run --rm -v "$PAKET":/paket "$IMAGE" bash -euo pipefail -c '
  cp -r /paket/dist/Helferverwaltung /test
  cp /paket/pruefskript.py /test/
  cd /test

  wine Helferverwaltung.exe >/dev/null 2>&1 &

  bereit=0
  for i in $(seq 1 120); do
    if (echo > /dev/tcp/127.0.0.1/8001) >/dev/null 2>&1; then
      echo "Server erreichbar nach ${i}s"; bereit=1; break
    fi
    sleep 1
  done
  if [ "$bereit" -eq 0 ]; then
    echo "FEHLER: Server kam nicht hoch. Protokoll:"
    sed "s/^/  /" /test/helferverwaltung-protokoll.txt 2>/dev/null || echo "  (keins)"
    exit 1
  fi

  wine python -m pip install --quiet --disable-pip-version-check openpyxl==3.1.5 2>/dev/null
  set +e
  wine python pruefskript.py 2>&1 | grep -vE "fixme:|^wine:|^[0-9a-f]{4}:"
  ergebnis=${PIPESTATUS[0]}
  set -e

  echo ""
  echo "-- Sicherungskopie --"
  if ls /test/data/sicherungen/*.xlsx >/dev/null 2>&1; then
    echo "  angelegt: $(ls /test/data/sicherungen/ | head -1)"
  else
    echo "  FEHLER: keine Sicherungskopie angelegt"; ergebnis=1
  fi

  echo ""
  echo "-- Bedienelement --"
  if grep -q "Ersatzfenster wird angezeigt" /test/helferverwaltung-protokoll.txt; then
    echo "  Infobereich-Symbol ohne Bildschirm nicht moeglich (hier erwartet),"
    echo "  das Ersatzfenster ist eingesprungen - der Rueckfallweg greift."
  else
    echo "  HINWEIS: weder Symbol noch Ersatzfenster im Protokoll vermerkt"
  fi

  pkill -f Helferverwaltung.exe 2>/dev/null || true
  exit $ergebnis
'
echo ""
echo "== Paket geprueft: in Ordnung =="
