"""Erzeugt die EXE-Symboldatei, falls sie fehlt.

Die ICO-Datei (Malteser-Kreuz) ist bewusst aus dem Repository ausgenommen -
das Layout der Ortsgruppe ist geschuetzt. Im CI-Build, wo eine frische
Arbeitskopie ohne die Datei liegt, wird sie hier anhand derselben
Zeichenlogik erzeugt, die auch das Paket selbst fuer das Infobereich-Symbol
nutzt (siehe ``starter.symbol_bild``).

Aufruf:  python windows-paket/ico_erzeugen.py
"""

from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image

PAKET = Path(__file__).resolve().parent
ZIEL = PAKET / "helferverwaltung.ico"


def symbol_bild() -> Image.Image:
    """Das Malteser-rote Kreuz als Bild - identisch zu starter.symbol_bild."""
    from PIL import ImageDraw

    bild = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
    stift = ImageDraw.Draw(bild)
    rot = (200, 16, 46, 255)
    stift.rectangle([96, 24, 160, 232], fill=rot)
    stift.rectangle([24, 96, 232, 160], fill=rot)
    return bild


def main() -> int:
    if ZIEL.exists() and ZIEL.stat().st_size > 0:
        print(f"Symbol existiert bereits: {ZIEL}")
        return 0
    ZIEL.parent.mkdir(parents=True, exist_ok=True)
    symbol_bild().save(ZIEL, sizes=[(256, 256), (64, 64), (48, 48), (32, 32), (16, 16)])
    print(f"Symbol erzeugt: {ZIEL}")
    return 0


if __name__ == "__main__":
    sys.exit(main())