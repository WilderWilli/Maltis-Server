#!/usr/bin/env bash
# Baut das Windows-Testpaket der Helferverwaltung.
#
# Gebaut wird in einem Container mit Wine und Windows-Python, weil PyInstaller
# nicht ueber Plattformgrenzen hinweg bauen kann. Ergebnis ist ein ZIP, das
# entpackt und per Doppelklick gestartet wird - ohne Installation, ohne
# Administratorrechte, ohne Python auf dem Zielrechner.
set -euo pipefail

PAKET="$(cd "$(dirname "$0")" && pwd)"
PROJEKT="$(dirname "$PAKET")"
IMAGE="helferverwaltung-bau:latest"
AUSGABE="$PAKET/dist/Helferverwaltung"

echo "==> 1/7  Testdaten pruefen"
if [ ! -f "$PAKET/testdaten/Personal_Bestandsaufnahme.xlsx" ]; then
  echo "    Testdaten fehlen - werden erzeugt."
  "$PROJEKT/.venv/bin/python" "$PAKET/testdaten_erzeugen.py"
else
  echo "    vorhanden."
fi

echo "==> 2/7  Zertifikat pruefen"
if [ ! -f "$PAKET/zertifikat/helferverwaltung.pfx" ]; then
  "$PAKET/zertifikat_erzeugen.sh"
else
  echo "    vorhanden."
fi

echo "==> 3/7  Bauumgebung vorbereiten"
docker build -q -f "$PAKET/Dockerfile.bauen" -t "$IMAGE" "$PAKET" >/dev/null
echo "    $IMAGE bereit."

echo "==> 4/7  Windows-Programm bauen (dauert einige Minuten)"
rm -rf "$PAKET/build" "$PAKET/dist"

docker run --rm \
  -v "$PROJEKT":/projekt \
  -e HOST_UID="$(id -u)" -e HOST_GID="$(id -g)" \
  "$IMAGE" bash -eu -c '
    cd /projekt/windows-paket

    echo "    Abhaengigkeiten installieren ..."
    wine python -m pip install --quiet --disable-pip-version-check \
      -r requirements-windows.txt

    echo "    Symbol erzeugen ..."
    wine python - <<PY
from PIL import Image, ImageDraw
bilder = []
for g in (16, 24, 32, 48, 64, 128, 256):
    b = Image.new("RGBA", (g, g), (0, 0, 0, 0))
    d = ImageDraw.Draw(b)
    rot, e = (200, 16, 46, 255), g / 64.0
    d.rectangle([24*e, 6*e, 40*e, 58*e], fill=rot)
    d.rectangle([6*e, 24*e, 58*e, 40*e], fill=rot)
    bilder.append(b)
bilder[-1].save("helferverwaltung.ico", format="ICO",
                sizes=[(b.width, b.height) for b in bilder])
print("    Symbol geschrieben.")
PY

    echo "    PyInstaller laeuft ..."
    wine python -m PyInstaller --noconfirm --clean --log-level WARN \
      helferverwaltung.spec

    chown -R "$HOST_UID:$HOST_GID" build dist helferverwaltung.ico
  ' 2>&1 | grep -vE "^0[0-9a-f]{3}:|^wine:|winemenubuilder|^\s*$" || true

if [ ! -f "$AUSGABE/Helferverwaltung.exe" ]; then
  echo "FEHLER: Es wurde keine EXE erzeugt."
  exit 1
fi
echo "    EXE erzeugt: $(du -h "$AUSGABE/Helferverwaltung.exe" | cut -f1)"

echo "==> 5/7  Signieren"
docker run --rm -v "$PAKET":/paket -e HOST_UID="$(id -u)" -e HOST_GID="$(id -g)" \
  "$IMAGE" bash -eu -c '
    cd /paket/dist/Helferverwaltung
    osslsigncode sign \
      -pkcs12 /paket/zertifikat/helferverwaltung.pfx -pass testpaket \
      -n "Helferverwaltung der Ortsgruppe (Testversion)" \
      -i "https://www.malteser.de" \
      -t http://timestamp.digicert.com \
      -h sha256 \
      -in Helferverwaltung.exe -out Helferverwaltung-signiert.exe >/dev/null 2>&1 \
    || osslsigncode sign \
      -pkcs12 /paket/zertifikat/helferverwaltung.pfx -pass testpaket \
      -n "Helferverwaltung der Ortsgruppe (Testversion)" \
      -h sha256 \
      -in Helferverwaltung.exe -out Helferverwaltung-signiert.exe >/dev/null 2>&1
    mv Helferverwaltung-signiert.exe Helferverwaltung.exe
    chown "$HOST_UID:$HOST_GID" Helferverwaltung.exe
  '
echo "    signiert."

echo "==> 6/7  Paket pruefen (startet die EXE unter Wine)"
# Bewusst vor dem Schnueren: ein Paket, das nie gelaufen ist, soll gar nicht
# erst als ZIP entstehen und versehentlich weitergegeben werden.
if ! "$PAKET/pruefen.sh" > "$PAKET/dist/pruefbericht.txt" 2>&1; then
  echo "    FEHLGESCHLAGEN. Bericht:"
  sed "s/^/    /" "$PAKET/dist/pruefbericht.txt" | grep -vE "^\s*[0-9a-f]{4}:|fixme:|^\s*wine:" | tail -30
  echo ""
  echo "    Es wurde KEIN ZIP erzeugt."
  exit 1
fi
grep -E "^  (200|angelegt|keine echten|gespeichert|Wert steht|Aenderung steht|Telefonwerte)" \
  "$PAKET/dist/pruefbericht.txt" | sed "s/^/  /" || true
echo "    bestanden (voller Bericht: dist/pruefbericht.txt)"

echo "==> 7/7  Paket schnueren"
cp "$PAKET/LIESMICH.txt" "$AUSGABE/LIESMICH.txt"
cp "$PAKET/zertifikat/helferverwaltung.crt" "$AUSGABE/Zertifikat-fuer-die-IT.crt"

cd "$PAKET/dist"
ZIPNAME="Helferverwaltung-Testversion-$(date +%Y-%m-%d).zip"
rm -f "$ZIPNAME"
zip -rq "$ZIPNAME" Helferverwaltung
echo ""
echo "Fertig:  $PAKET/dist/$ZIPNAME  ($(du -h "$ZIPNAME" | cut -f1))"
