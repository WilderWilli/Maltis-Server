# -*- mode: python ; coding: utf-8 -*-
"""Bauvorschrift fuer das Windows-Testpaket.

Bewusste Entscheidungen gegen das Anschlagen von Virenscannern:

* **Ordner statt Einzeldatei** (``onedir``). Eine Einzeldatei-EXE entpackt sich
  beim Start selbst in den Temp-Ordner und fuehrt sich von dort aus - genau das
  Verhalten, auf das Verhaltenserkennung anspringt. Das ist der groesste
  einzelne Hebel.
* **Kein UPX.** Gepackte Programmdateien sind eines der staerksten
  Heuristikmerkmale ueberhaupt, weil Schadsoftware sich so dem Auslesen
  entzieht.
* **Versionsressource und Symbol.** Siehe version_info.txt.
* **Kein Konsolenfenster**, aber auch keine erhoehten Rechte - das Manifest
  bleibt auf "asInvoker".
"""

import sys
from pathlib import Path

PROJEKT = Path(SPECPATH).parent
PAKET = Path(SPECPATH)

a = Analysis(
    [str(PAKET / 'starter.py')],
    pathex=[str(PROJEKT)],
    binaries=[],
    datas=[
        # Vorlagen und Gestaltung liest die Anwendung zur Laufzeit von der
        # Platte - sie muessen als Dateien vorliegen, nicht im Code-Archiv.
        (str(PROJEKT / 'app' / 'templates'), 'app/templates'),
        (str(PROJEKT / 'app' / 'static'), 'app/static'),
        # Die erfundenen Testdaten. Werden beim ersten Start neben die EXE
        # kopiert (siehe starter.richte_testumgebung_ein).
        (str(PAKET / 'testdaten'), 'testdaten'),
    ],
    hiddenimports=[
        # uvicorn und starlette laden diese Teile erst zur Laufzeit ueber
        # Zeichenketten; die statische Analyse von PyInstaller sieht sie nicht.
        'uvicorn.logging',
        'uvicorn.loops.auto',
        'uvicorn.loops.asyncio',
        'uvicorn.protocols.http.auto',
        'uvicorn.protocols.http.h11_impl',
        'uvicorn.protocols.websockets.auto',
        'uvicorn.protocols.websockets.wsproto_impl',
        'uvicorn.lifespan.on',
        'uvicorn.lifespan.off',
        'anyio._backends._asyncio',
        # Die Anwendung selbst - main zieht den Rest nach.
        'app.main',
        # Laufzeit-Abhaengigkeiten aus requirements-windows.txt. Im Graphen
        # sind sie ueber direkte Importe ohnehin enthalten; die Auflistung
        # schuetzt die Baureihenfolge gegen Veraenderungen der Importketten.
        # starlette importiert "multipart" etwa erst beim Bearbeiten eines
        # Formulars - zur Analysezeit ist das nicht sichtbar.
        'httpx', 'httpcore', 'h11',
        'openpyxl', 'jinja2', 'jinja2.ext',
        'fastapi', 'starlette', 'sqlalchemy', 'pydantic',
        'multipart', 'dotenv',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Wird nicht gebraucht und blaeht das Paket nur auf. Weniger Inhalt
        # heisst auch weniger Angriffsflaeche fuer Fehlalarme.
        'pytest', 'setuptools', 'pip', 'numpy', 'pandas', 'matplotlib',
        'PyQt5', 'PySide2', 'PySide6', 'notebook', 'IPython',
        # pkg_resources muss mit setuptools zusammen verschwinden. Bleibt es
        # im Graphen, bindet PyInstaller einen Starthaken dafuer ein, der
        # jaraco.text aus setuptools nachlaedt - das aber gerade entfernt
        # wurde. Das Programm bricht dann beim Start ab, noch bevor es die
        # Protokolldatei anlegen kann. Keines unserer Pakete importiert
        # pkg_resources; es kam nur ueber die Metadaten mit herein.
        'pkg_resources',
    ],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='Helferverwaltung',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,                       # siehe Modulkommentar
    console=False,                   # kein schwarzes Fenster
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    uac_admin=False,                 # keine Administratorrechte anfordern
    icon=str(PAKET / 'helferverwaltung.ico'),
    version=str(PAKET / 'version_info.txt'),
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='Helferverwaltung',
)
