#!/usr/bin/env bash
# Erzeugt ein selbstsigniertes Zertifikat zum Signieren der EXE.
#
# Was das bringt - und was nicht:
#
#   * Es macht SmartScreen oder Smart App Control NICHT zufrieden. Die
#     entscheiden nach Reputation bei Microsoft, und die hat ein selbst
#     ausgestelltes Zertifikat per Definition nicht.
#   * Es gibt der Datei eine ueberpruefbare Herkunft. Die Malteser-IT kann
#     damit eine AppLocker/WDAC-Regel auf den Herausgeber schreiben, statt
#     jede einzelne Datei per Pruefsumme freizugeben - das ist der eigentliche
#     Grund, warum wir das tun.
#   * Manche Virenscanner werten eine gueltige Signatur leicht positiv.
#
# Der private Schluessel bleibt hier und gehoert nicht weitergegeben.
set -euo pipefail
cd "$(dirname "$0")"

mkdir -p zertifikat
cd zertifikat

if [ -f helferverwaltung.pfx ]; then
  echo "Zertifikat besteht bereits - nichts zu tun."
  echo "Neu erzeugen? Dann vorher den Ordner 'zertifikat' loeschen."
  exit 0
fi

PASSWORT="testpaket"

openssl req -x509 -newkey rsa:4096 -sha256 -days 1095 -nodes \
  -keyout helferverwaltung.key -out helferverwaltung.crt \
  -subj "/C=DE/ST=Hamburg/L=Hamburg/O=Malteser Hilfsdienst Ortsgruppe/CN=Helferverwaltung Testversion" \
  -addext "keyUsage=critical,digitalSignature" \
  -addext "extendedKeyUsage=critical,codeSigning" \
  -addext "basicConstraints=critical,CA:FALSE" \
  2>/dev/null

openssl pkcs12 -export \
  -out helferverwaltung.pfx \
  -inkey helferverwaltung.key \
  -in helferverwaltung.crt \
  -passout "pass:${PASSWORT}"

chmod 600 helferverwaltung.key helferverwaltung.pfx

echo "Zertifikat erzeugt:"
echo "  zertifikat/helferverwaltung.crt   <- darf weitergegeben werden (fuer die IT)"
echo "  zertifikat/helferverwaltung.key   <- geheim, bleibt hier"
echo "  zertifikat/helferverwaltung.pfx   <- geheim, zum Signieren (Passwort: ${PASSWORT})"
