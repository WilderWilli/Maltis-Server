# Windows-Testpaket der Helferverwaltung

Baut aus der Helferverwaltung ein Windows-Programm, das ohne Installation,
ohne Administratorrechte und ohne Python auf dem Zielrechner läuft – mit
**erfundenen Daten**, zum Verteilen an Testerinnen und Tester.

```bash
./bauen.sh      # baut, signiert, prüft und schnürt das ZIP
./pruefen.sh    # prüft ein bereits gebautes Paket erneut
```

Ergebnis: `dist/Helferverwaltung-Testversion-JJJJ-MM-TT.zip` (rund 24 MB).

## Zum Thema „wird geflaggt“

Die Ausgangslage war, dass `start.bat` auf den Zielrechnern blockiert wird,
ohne die Möglichkeit, es trotzdem auszuführen. **Das ist mit einer EXE nicht
zuverlässig gelöst.** Wer so blockiert, tut das nach Signatur und Reputation,
nicht nach Dateityp – und die Reputation einer frisch gebauten, selbst
signierten Datei ist null. Das Paket ist so gebaut, dass es möglichst wenig
Angriffsfläche bietet, aber die ehrliche Erwartung ist, dass ein Teil der
Tester weiterhin blockiert wird.

Was hier gegen Fehlalarme getan wurde:

| Maßnahme | Grund |
|---|---|
| Ordner statt Einzeldatei (`onedir`) | Eine Einzeldatei-EXE entpackt sich beim Start selbst in den Temp-Ordner und startet von dort – genau das Verhalten, auf das Verhaltenserkennung anspringt. Größter einzelner Hebel. |
| Kein UPX | Gepackte Programmdateien sind eines der stärksten Heuristikmerkmale überhaupt. |
| Versionsressource (`version_info.txt`) | Eine Datei ganz ohne Herstellerangaben ist ein Warnsignal; praktisch jede legitime Software trägt diese Felder. |
| Eigenes Symbol, Manifest auf `asInvoker` | Keine Administratorrechte anfordern, echte Ressourcen mitbringen. |
| `uvicorn` statt `uvicorn[standard]` | Spart uvloop, httptools und watchfiles – kompilierte Zusatz-DLLs, die jede für sich Anstoß erregen können und hier nichts bringen. |
| Signatur mit Zeitstempel | Macht SmartScreen **nicht** zufrieden, gibt der Datei aber eine prüfbare Herkunft. |

### Der eigentliche Weg bei einer Sperre durch die IT

Der mitgelieferte `Zertifikat-fuer-die-IT.crt` erlaubt der Malteser-IT, eine
AppLocker- oder WDAC-Regel auf den **Herausgeber** zu schreiben, statt jede
Datei einzeln per Prüfsumme freizugeben. Das ist der realistische Weg in
einer verwalteten Umgebung – und billiger als ein EV-Zertifikat
(mehrere hundert Euro pro Jahr, Ausstellung nur auf Hardware-Token).

## Testdaten

`testdaten_erzeugen.py` baut aus der echten Arbeitskopie eine strukturgleiche
Datei, in der jede Person erfunden ist: Namen, Geburtsdaten, Mitgliedsnummern
und Telefonnummern werden ersetzt, Termine um bis zu drei Wochen verschoben.

Die fachlichen Ausprägungen (y/n, RS/NotSan, GF/ZF, Lehrgangsvermerke) bleiben
**unverändert** – nur so sehen die Tester dieselben Handlungsbedarfe wie im
Echtbetrieb: abgelaufene Fristen, fehlende Angaben, offene Freigaben. Das
Skript prüft am Ende selbst nach, dass kein echter Name mehr in der fertigen
Datei steht.

Der Startwert des Zufallsgenerators ist fest: zwei Läufe erzeugen dieselben
Personen. Meldet ein Tester einen Fehler, reden alle über dieselbe Person.

## Warum unter Wine geprüft wird

Gebaut wird unter Linux, benutzt wird das Paket auf fremden Windows-Rechnern.
`pruefen.sh` startet deshalb die fertige EXE unter Wine, ruft alle Seiten auf,
speichert über das Personenformular eine Änderung und liest anschließend die
Excel-Datei von der Platte zurück. `bauen.sh` ruft das vor dem Schnüren auf –
schlägt es fehl, entsteht gar kein ZIP.

Das ist kein Luxus: Der allererste Build startete überhaupt nicht
(`ModuleNotFoundError: jaraco.text`, ausgelöst vom Ausschluss von
`setuptools`), und beim Bauen selbst war davon nichts zu sehen.

**Was Wine nicht abdeckt** und auf echtem Windows noch offen ist:

* das Symbol im Infobereich (`pystray`) – braucht eine Bildschirmsitzung und
  scheitert unter Wine immer; geprüft wird nur, dass das Ersatzfenster
  einspringt
* SmartScreen, Smart App Control, Defender und Gruppenrichtlinien
* der Standardbrowser, der sich öffnen soll

## Dateien

| Datei | Zweck |
|---|---|
| `bauen.sh` | Gesamtlauf: Testdaten, Zertifikat, Build, Signatur, Prüfung, ZIP |
| `pruefen.sh` / `pruefskript.py` | Startet die EXE unter Wine und bedient sie |
| `starter.py` | Einstiegspunkt der EXE: Server, Browser, Infobereich-Symbol |
| `helferverwaltung.spec` | PyInstaller-Bauvorschrift samt Begründungen |
| `requirements-windows.txt` | Abhängigkeiten des Pakets (bewusst schlanker als die des Projekts) |
| `testdaten_erzeugen.py` | Erzeugt die anonyme Excel-Datei |
| `zertifikat_erzeugen.sh` | Selbstsigniertes Code-Signing-Zertifikat |
| `Dockerfile.bauen` | Bauumgebung: Wine + Windows-Python + osslsigncode |
| `LIESMICH.txt` | Anleitung, die im ZIP mitgeht |

`zertifikat/`, `testdaten/`, `build/` und `dist/` sind aus dem Repository
ausgenommen – im Zertifikatsordner liegt der private Schlüssel.

## Die Anwendung im eingefrorenen Zustand

`app/config.py` unterscheidet seit diesem Paket zwei Fälle: normal liegt alles
im Projektordner, als EXE liegt der Programmcode schreibgeschützt in
`_internal`, während `data/`, `.env` und die Protokolldatei **neben die EXE**
gehören. Dadurch sieht ein Tester seine Daten und wird alles durch Löschen des
entpackten Ordners wieder los. Unter Linux ändert sich nichts.
