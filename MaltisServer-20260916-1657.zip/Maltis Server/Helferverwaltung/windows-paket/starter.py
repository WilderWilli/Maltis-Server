"""Einstiegspunkt des Windows-Testpakets.

Startet die Helferverwaltung ohne schwarzes Konsolenfenster, oeffnet den
Standardbrowser und legt ein Symbol in den Infobereich (neben die Uhr), ueber
das sich die Anwendung wieder beenden laesst.

Zwei Dinge sind hier anders als beim Start ueber start.bat:

* **Kein stdout.** Ein fensterloses Programm hat unter Windows weder
  Standardausgabe noch Standardfehler; ``sys.stdout`` ist ``None``. uvicorn
  richtet beim Start ein Logging auf genau diese Kanaele ein und stuerzt
  andernfalls ab, bevor irgendetwas sichtbar wird. Deshalb wird ganz am
  Anfang von ``main()`` - vor dem ersten uvicorn-Import - auf eine Logdatei
  umgeleitet (siehe ``protokoll_umleiten``).
* **Alles wird protokolliert.** Das Paket geht an Tester, deren Bildschirm
  wir nicht sehen. Geht etwas schief, erscheint ein Windows-Hinweisfenster
  mit dem Pfad zur Logdatei, die sie uns schicken koennen.

Beim Importieren (etwa in den Tests) passiert keine Umleitung - die
Pfadaufloesung laesst sich so pruefen, ohne die Konsole des Testlaufs zu
ueberschreiben.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _programm_ordner() -> Path:
    """Ordner neben der EXE: dorthin gehoeren .env, Log und ``data/``.

    Nicht eingefroren (Entwicklung und Tests) ist es der Projektordner.
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


PROGRAMM_DIR = _programm_ordner()
LOG_DATEI = PROGRAMM_DIR / "helferverwaltung-protokoll.txt"


class _Doppelausgabe:
    """Schreibt in die Logdatei und - falls vorhanden - auf die Konsole."""

    def __init__(self, datei, konsole):
        self._datei = datei
        self._konsole = konsole

    def write(self, text):
        self._datei.write(text)
        self._datei.flush()
        if self._konsole is not None:
            try:
                self._konsole.write(text)
            except Exception:
                pass

    def flush(self):
        self._datei.flush()
        if self._konsole is not None:
            try:
                self._konsole.flush()
            except Exception:
                pass

    def isatty(self):
        return False


def protokoll_umleiten() -> None:
    """lenkt stdout/stderr in die Logdatei um.

    Steht am Anfang von ``main()`` und damit vor dem ersten uvicorn-Import.
    In Tests und beim Entwickeln (nicht eingefroren) bleibt der Aufruf aus,
    damit die Ausgabe auf der Konsole sichtbar bleibt.
    """
    log = open(LOG_DATEI, "a", encoding="utf-8", buffering=1)
    sys.stdout = _Doppelausgabe(log, sys.__stdout__)
    sys.stderr = _Doppelausgabe(log, sys.__stderr__)

import logging  # noqa: E402
import shutil  # noqa: E402
import socket  # noqa: E402
import threading  # noqa: E402
import time  # noqa: E402
import traceback  # noqa: E402
import webbrowser  # noqa: E402
from datetime import datetime  # noqa: E402

PORT = 8001
ADRESSE = f"http://127.0.0.1:{PORT}"
TITEL = "Helferverwaltung (Testversion)"


def protokoll(text: str) -> None:
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {text}")


def hinweisfenster(titel: str, text: str) -> None:
    """Windows-Meldungsfenster - das einzige Sprachrohr ohne Konsole."""
    try:
        import ctypes

        ctypes.windll.user32.MessageBoxW(None, text, titel, 0x10)
    except Exception:
        protokoll(f"Hinweisfenster nicht moeglich: {titel} - {text}")


def port_belegt() -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", PORT)) == 0


def warte_auf_server(sekunden: float = 30.0) -> bool:
    ende = time.time() + sekunden
    while time.time() < ende:
        if port_belegt():
            return True
        time.sleep(0.25)
    return False


def _testdaten_quelle() -> Path:
    """Wo die mitgelieferte Testdatei liegt.

    Eingefroren ist sie in der ``_internal``-Ablage (``sys._MEIPASS``)
    eingebettet, andernfalls im Projekt unter ``windows-paket/testdaten``.
    """
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS) / "testdaten" / "Personal_Bestandsaufnahme.xlsx"
    return PROGRAMM_DIR / "windows-paket" / "testdaten" / "Personal_Bestandsaufnahme.xlsx"


def richte_testumgebung_ein() -> None:
    """Beim allerersten Start die mitgelieferten Testdaten bereitlegen.

    Die Anwendung arbeitet ohne Eintrag in der .env gegen
    ``data/arbeitskopie`` - genau dorthin wird die Testdatei kopiert. Ein
    zweiter Start ueberschreibt nichts, sonst waeren die Eingaben des Testers
    nach jedem Neustart weg.
    """
    ziel_ordner = PROGRAMM_DIR / "data" / "arbeitskopie"
    ziel = ziel_ordner / "Personal_Bestandsaufnahme.xlsx"
    if ziel.exists():
        protokoll(f"Testdatei vorhanden: {ziel}")
        return

    quelle = _testdaten_quelle()

    ziel_ordner.mkdir(parents=True, exist_ok=True)
    shutil.copy2(quelle, ziel)
    protokoll(f"Testdatei angelegt: {ziel}")


class Serverfaden:
    """uvicorn in einem Nebenfaden, damit das Infobereich-Symbol reagiert."""

    def __init__(self):
        self.server = None
        self.faden = None
        self.fehler: BaseException | None = None

    def starten(self) -> None:
        import uvicorn

        from app.main import app

        # Kein farbiges Log, keine Zugriffszeilen mit Personendaten in der
        # Datei - das Protokoll geht im Fehlerfall an uns zurueck.
        konfiguration = uvicorn.Config(
            app,
            host="127.0.0.1",
            port=PORT,
            log_level="info",
            access_log=False,
            use_colors=False,
            # Ausdruecklich festgelegt statt automatisch erkannt: die
            # Automatik importiert ueber Zeichenketten und faellt im
            # eingefrorenen Zustand gern auf die Nase. h11 und asyncio
            # sind reines Python und brauchen keine Zusatzmodule.
            loop="asyncio",
            http="h11",
            ws="none",
        )
        self.server = uvicorn.Server(konfiguration)

        def lauf():
            try:
                self.server.run()
            except BaseException as f:  # noqa: BLE001
                self.fehler = f
                protokoll("Server abgebrochen:\n" + traceback.format_exc())

        self.faden = threading.Thread(target=lauf, name="uvicorn", daemon=True)
        self.faden.start()

    def beenden(self) -> None:
        if self.server is not None:
            self.server.should_exit = True
        if self.faden is not None:
            self.faden.join(timeout=8)


def symbol_bild():
    """Das Malteser-rote Kreuz als Bild fuer den Infobereich."""
    from PIL import Image, ImageDraw

    bild = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    stift = ImageDraw.Draw(bild)
    rot = (200, 16, 46, 255)
    stift.rectangle([24, 6, 40, 58], fill=rot)
    stift.rectangle([6, 24, 58, 40], fill=rot)
    return bild


def infobereich_symbol(beim_beenden) -> bool:
    """Symbol neben die Uhr legen. Gibt False zurueck, wenn das nicht geht."""
    try:
        import pystray
    except Exception:
        protokoll("pystray nicht verfuegbar:\n" + traceback.format_exc())
        return False

    try:
        symbol = None

        def oeffnen(*_):
            webbrowser.open(ADRESSE)

        def beenden(*_):
            protokoll("Beenden ueber das Infobereich-Symbol.")
            beim_beenden()
            if symbol is not None:
                symbol.stop()

        symbol = pystray.Icon(
            "helferverwaltung",
            symbol_bild(),
            TITEL,
            menu=pystray.Menu(
                pystray.MenuItem("Helferverwaltung öffnen", oeffnen, default=True),
                pystray.MenuItem("Beenden", beenden),
            ),
        )
        protokoll("Infobereich-Symbol wird angezeigt.")
        symbol.run()
        return True
    except Exception:
        protokoll("Infobereich-Symbol fehlgeschlagen:\n" + traceback.format_exc())
        return False


def ersatzfenster(beim_beenden) -> None:
    """Kleines Fenster, falls der Infobereich nicht zur Verfuegung steht."""
    try:
        import tkinter as tk
    except Exception:
        protokoll("Auch tkinter fehlt - laufe ohne Bedienelement weiter.")
        while True:
            time.sleep(3600)

    fenster = tk.Tk()
    fenster.title(TITEL)
    fenster.geometry("380x150")
    fenster.resizable(False, False)

    tk.Label(
        fenster,
        text="Die Helferverwaltung läuft.",
        font=("Segoe UI", 11, "bold"),
    ).pack(pady=(18, 4))
    tk.Label(fenster, text=ADRESSE, font=("Segoe UI", 9), fg="#555").pack()

    leiste = tk.Frame(fenster)
    leiste.pack(pady=14)
    tk.Button(
        leiste, text="Im Browser öffnen", width=18,
        command=lambda: webbrowser.open(ADRESSE),
    ).pack(side="left", padx=5)

    def schliessen():
        beim_beenden()
        fenster.destroy()

    tk.Button(leiste, text="Beenden", width=12, command=schliessen).pack(side="left", padx=5)
    fenster.protocol("WM_DELETE_WINDOW", schliessen)
    protokoll("Ersatzfenster wird angezeigt.")
    fenster.mainloop()


def main() -> int:
    protokoll_umleiten()
    protokoll("=" * 60)
    protokoll(f"Start. Programmordner: {PROGRAMM_DIR}")
    protokoll(f"Eingefroren: {getattr(sys, 'frozen', False)}  Python: {sys.version}")

    if port_belegt():
        protokoll("Port 8001 ist belegt - vermutlich laeuft die Anwendung schon.")
        webbrowser.open(ADRESSE)
        return 0

    richte_testumgebung_ein()

    logging.basicConfig(level=logging.INFO, stream=sys.stdout, force=True)

    server = Serverfaden()
    server.starten()

    if not warte_auf_server():
        grund = ""
        if server.fehler is not None:
            grund = f"\n\nGrund: {server.fehler}"
        hinweisfenster(
            TITEL,
            "Die Helferverwaltung konnte nicht gestartet werden."
            f"{grund}\n\nEinzelheiten stehen in:\n{LOG_DATEI}\n\n"
            "Bitte diese Datei an Lasse weitergeben.",
        )
        return 1

    protokoll(f"Server erreichbar unter {ADRESSE} - oeffne Browser.")
    webbrowser.open(ADRESSE)

    if not infobereich_symbol(server.beenden):
        ersatzfenster(server.beenden)

    server.beenden()
    protokoll("Beendet.")
    return 0


if __name__ == "__main__":
    # Ohne diese Zeile startet ein eingefrorenes Programm sich bei jedem
    # Unterprozess selbst neu - Windows kennt kein fork().
    import multiprocessing

    multiprocessing.freeze_support()

    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except BaseException:
        protokoll("Unerwarteter Abbruch:\n" + traceback.format_exc())
        hinweisfenster(
            TITEL,
            "Die Helferverwaltung ist unerwartet abgebrochen.\n\n"
            f"Einzelheiten stehen in:\n{LOG_DATEI}\n\n"
            "Bitte diese Datei an Lasse weitergeben.",
        )
        raise SystemExit(1)
