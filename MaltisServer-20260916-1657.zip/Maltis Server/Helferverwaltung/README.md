# Helferverwaltung der Ortsgruppe

Eine Bedienoberfläche für die Datei `Personal_Bestandsaufnahme.xlsx`. Die Excel-Datei bleibt
die führende Datenquelle – die Anwendung liest sie und schreibt zellgenau in sie zurück. Wer
lieber direkt in Excel arbeitet, kann das weiterhin tun.

## Starten

### Windows

Doppelklick auf `start.bat`.

### Linux

**Einmalig** im Terminal einrichten – das legt ein Symbol zum Doppelklicken an:

```bash
cd "/home/lasse/Code/Maltis Server/Helferverwaltung"
./schreibtisch_verknuepfung_anlegen.sh
```

Danach reicht ein **Doppelklick auf „Helferverwaltung“ auf dem Schreibtisch**, oder im
Anwendungsmenü nach „Helferverwaltung“ suchen.

Ein Doppelklick auf `start.sh` selbst funktioniert nicht – Dateimanager unter Linux (COSMIC,
GNOME, KDE) führen Skripte aus Sicherheitsgründen nicht per Doppelklick aus. Deshalb der Umweg
über die Verknüpfung. Wer lieber tippt, kann jederzeit `./start.sh` im Terminal aufrufen.

### In beiden Fällen

Beim ersten Mal dauert es ein paar Minuten, weil die Anwendung sich selbst einrichtet. Danach
öffnet sich der Browser mit der Übersicht. **Das schwarze Fenster bitte offen lassen** – solange
es läuft, läuft die Anwendung. Zum Beenden `Strg + C` drücken oder das Fenster schließen.

Ein zweiter Start bei schon laufender Anwendung öffnet nur noch das Browserfenster, es läuft
also nie versehentlich doppelt.

## Vor dem ersten Einsatz einstellen

Beim ersten Start wird die Datei `.env` angelegt. Dort trägt man ein, wo die Excel-Datei liegt:

```
HELFERDATEI_PFAD=/Pfad/zum/Sync-Ordner/Personal_Bestandsaufnahme.xlsx
```

Solange dort nichts steht, arbeitet die Anwendung mit der Übungskopie unter
`data/arbeitskopie/` – dort kann nichts kaputtgehen. Unter **Einstellungen** sieht man
jederzeit, mit welcher Datei gerade gearbeitet wird.

Läuft die Datei über SharePoint, entfällt die lokale Pfadangabe – siehe
„SharePoint synchronisieren“.

## SharePoint synchronisieren (optional)

Standardmäßig arbeitet die Anwendung direkt mit einer lokalen Excel-Datei (`HELFERDATEI_PFAD`).
Sie kann die Datei stattdessen **in Microsoft SharePoint** führen und über eine lokale
Arbeitskopie bearbeiten – das Excel bleibt die führende Datenquelle, aber alle Rechner teilen
sich denselben Stand.

### Einmalig einrichten (nur der Administrator)

Damit die Anwendung über Microsoft Graph auf die Datei zugreifen darf, wird im
Microsoft-Tenant der Malteser eine App-Registrierung angelegt:

1. **Azure-Portal → Microsoft Entra ID → App-Registrierungen → Neue Registrierung.**
   Name z. B. `Helferverwaltung`, Kontotyp „Nur in diesem Organisationsverzeichnis“,
   Umleitungs-URI kann leer bleiben (die Anwendung braucht nur die
   Client-Credentials, keine Benutzeranmeldung).
2. **Client-ID und Mandanten-ID notieren** – beides steht auf der Übersichtsseite
   der App-Registrierung (`GRAPH_CLIENT_ID`, `GRAPH_TENANT_ID`).
3. **Zertifikate & Geheimnisse → Neues Client-Geheimnis.** Das Secret wird genau
   einmal angezeigt. Ablaufdatum notieren – das Secret ist die einzige Angabe, die
   **zeitlich begrenzt** ist und erneuert werden muss.
4. **API-Berechtigungen → Berechtigung hinzufügen → Microsoft Graph →
   Anwendungsberechtigungen.** Gewünscht ist `Sites.Selected` (schmalster
   Umfang: nur die ausdrücklich freigegebenen Standorte). Anschließend „Admin
   Zustimmung erteilen“ klicken, sonst greift die Berechtigung nicht. Alternativ
   geht auch das breitere `Sites.ReadWrite.All`, das ist aber mehr, als die
   Anwendung braucht.
5. Beim freigegebenen Standort die **Site-ID** notieren: Das ist
   `Hostname,sites,Name` – zu finden über die Adresse der SharePoint-Seite
   (z. B. `https://maltesercloud.sharepoint.com/sites/Fhrung-Behandlungszug` →
   `GRAPH_SITE_ID=maltesercloud.sharepoint.com,sites,Fhrung-Behandlungszug`).
6. Mit `Sites.Selected` muss die App-Registrierung noch **ausdrücklich auf den
   freigegebenen Standort** gelenkt werden (die Datei liegt unter „Freigegebene
   Dokumente/Helfer - Bestand“) – z. B. über einen Graph-Aufruf an
   `/sites/{site-id}/permissions`. Ist das nicht eingerichtet, meldet
   „Verbindung testen“ einen Zugriffsfehler, obwohl alle Angaben stimmen.

### Einschalten

In der `.env`:

```
SHAREPOINT_AKTIV=ja
GRAPH_TENANT_ID=<Mandanten-ID>
GRAPH_CLIENT_ID=<App-ID>
GRAPH_CLIENT_SECRET=<geheimer Schlüssel>
GRAPH_SITE_ID=<Hostname>,sites,<Site-Name>
GRAPH_ORDNER=Freigegebene Dokumente/Helfer - Bestand
GRAPH_DATEI=Personal_Bestandsaufnahme.xlsx
GRAPH_LOKAL_ORDNER=data/graph_kopie
```

Solange `SHAREPOINT_AKTIV` nicht auf `1`/`ja` steht oder eine der
Graph-Angaben fehlt, gilt der lokale Modus. Unter **Einstellungen** steht
jederzeit, welcher Modus aktiv ist („lokaler Sync-Ordner“ oder „Microsoft
SharePoint (Graph)“) und ob die Datei im fernen Stand gefunden wird –
außerdem der geprüfte Pfad und die lokale Arbeitskopie. Nach dem Eintragen
muss die Anwendung neu gestartet werden.

**Fehlerbilder, die „Verbindung testen“ erklärt:**

| Meldung | typische Ursache |
|---|---|
| Anmeldung fehlgeschlagen (`invalid_client`) | Client-Secret falsch oder abgelaufen |
| Zugriff verweigert / HTTP 403 | `Sites.Selected` fehlt oder Standort nicht freigegeben |
| Netz nicht erreichbar | Rechner hat keinen Zugriff auf Microsoft 365 |
| Datei nicht gefunden (404) | `GRAPH_ORDNER`, `GRAPH_DATEI` oder `GRAPH_SITE_ID` falsch |

### Wie der Abgleich funktioniert

- Beim ersten Zugriff holt die Anwendung den neuesten Stand aus SharePoint in die lokale
  Arbeitskopie und arbeitet danach darauf weiter – ohne für jeden Klick das Netz zu brauchen.
- **Sichern** lädt die frische Datei wieder herunter, prüft per eTag, dass seit dem letzten
  Stand niemand anderes geschrieben hat, und lädt hoch. Hat jemand anderes zwischenzeitlich
  geändert (`412 Precondition Failed`), wird **nichts überschrieben** – die Anwendung holt die
  frische Fassung und meldet den Konflikt, die eigene Änderung muss erneut gespeichert werden.
- **Verbindung testen** in der Kopfzeile oder unter Einstellungen fragt den Stand direkt in
  SharePoint ab; **Jetzt synchronisieren** erzwingt den Abgleich.
- **Kein Netz oder falsche Anmeldedaten:** Die Anwendung bleibt auf der letzten lokalen Kopie
  bedienbar. Änderungen in dieser Zeit werden gespeichert und als „nicht hochgeladen“ markiert –
  in der Kopfzeile sichtbar (`offline`, `ausstehend`). Beim nächsten erfolgreichen
  „Jetzt synchronisieren“ werden sie hochgeladen.

## Was die Anwendung tut

- **Übersicht** – eine aufklappbare Zeile **je Person**: ihr Status, ihre Qualifizierungen
  (MGA 1–4, Prävention, AV 15, AV 21, Funk …), ihre Fristen, die RS-Fortbildung des laufenden
  Jahres und alles, wo bei ihr eine Angabe fehlt. Oben lässt sich nach Handlungsbedarf filtern.
- **Gruppenführer** – Aufgabenliste je Gruppenführer: Jahrespflichten, die fällig sind,
  abgelaufene oder fehlende Untersuchungen und fehlende Kleidergrößen. Jeder Gruppenführer
  sieht auf einen Blick, was bei seinen Helferinnen und Helfern ansteht. Noch nicht
  zugeordnete Personen werden separat angezeigt.
- **Personal** – eine Seite pro Person, alle Felder direkt bearbeitbar – inklusive der
  Zuordnung zum Gruppenführer (`GF`, per Schnellzuweisung direkt in der Liste),
  Kleidergrößen (`Dienstkleidung Größe`, `CBRN Kleidergröße`)
  und einer internen Bemerkung (nur in der Anwendung sichtbar).
- **Ausgeschiedene** – wer die Ortsgruppe verlassen hat. Ausgliedern geht unten auf der
  Profilseite, Zurückholen auf dieser Seite.
- **Namen** – die Aufteilung des Namensfeldes in Vor- und Nachname prüfen und bestätigen.
- **Export** – die Datei für die PSA-Beauftragte erzeugen (nur aktives Personal).
- **Protokoll** – jede Zelle, die die Anwendung geschrieben hat, mit altem und neuem Wert.

## Gruppenführer-Workflow

Wer eine Helferin oder einen Helfer zu einem Gruppenführer zuordnen will, schreibt
in der Spalte `GF` der Excel-Datei oder schneller direkt in der **Personalliste**:
im Auswahlfeld der jeweiligen Zeile steht `Niklas`, `Nino` oder `—` (ohne
Zuordnung). Die Änderung wird sofort gespeichert (und im SharePoint-Modus
hochgeladen), alles Weitere passiert in der führenden Datei.

- Die Listenansicht **„Personal“** lässt sich über das Auswahlfeld oben nach
  Gruppenführer filtern (`Niklas`, `Nino`, `ohne Zuordnung`).
- Die Seite **„Gruppenführer“** zeigt je Gruppenführer eine Aufgabenliste:
  Jahrespflichten, die anstehen, abgelaufene oder fehlende Untersuchungen und
  fehlende Kleidergrößen – auf einen Blick, was bei den zugeordneten Personen
  offen ist. Oben zählt eine Kennzahlenleiste: offene Aufgaben, Personen je
  Gruppenführer, Personen ohne Zuordnung.
- **Gültig sind nur `Niklas` und `Nino`.** Ein anderer Wert wird bei der
  Zuordnung abgelehnt; ein Fremdwert, der schon in der Datei steht, wird auf der
  Gruppenführer-Seite als „Wert …“ daneben angezeigt und wie „ohne Zuordnung“
  gezählt.
- Personen ohne Gruppenführer will die Anwendung nicht aus dem Blick verlieren –
  sie stehen auf der Gruppenführer-Seite unter „Ohne Zuordnung“.

## Der wichtigste Grundsatz: leer heißt unbekannt

Eine leere Zelle bedeutet **„wir wissen es nicht“** – niemals „nein“. Deshalb gibt es überall
drei Zustände statt zwei:

| | Bedeutung | Folge |
|---|---|---|
| **ja** | trifft nachweislich zu | zählt als erfüllt |
| **nein** | trifft nachweislich nicht zu | zählt als nicht erfüllt |
| **keine Angabe** | leer oder unklar (`HA`, `angemeldet`, `C?`, `Wohl mind. C1`) | erscheint unter „Angabe fehlt, bitte prüfen“ |

## Aktiv und passiv

In der Spalte `Status` steht `aktiv` oder `passiv`, in `Passiv seit` das Datum. Ist jemand
passiv gemeldet, erscheint das in der Übersicht und in der Personalliste als Hinweis samt
Datum. Bleibt `Status` leer, wird nichts behauptet – die Person gilt weder als aktiv noch als
passiv.

## Was jedes Jahr neu fällig ist

Drei Nachweise führen ein **Datum** statt eines Häkchens, weil sie jährlich wiederholt werden:

| Nachweis | gilt für |
|---|---|
| `RS Fortbildung` | Personen mit der Qualifikation `RS` |
| `Jahresgespräch` | alle |
| `Unterweisung S/W-Rechte` | Personen mit eingetragenem Führerschein |

Erledigt ist, was im laufenden Jahr eingetragen ist – 2026 also ein Datum aus 2026, 2027 eines
aus 2027. Was fehlt, steht als **„steht an"** oben in der Übersicht und rot auf der
Profildatei. Steht in der Spalte noch ein `y`, `HA` oder `angemeldet` aus der Zeit vor der
Umstellung, meldet die Anwendung **„ausstehend"** – ein Datum für das aktuelle Jahr fehlt, aber
die Pflicht selbst ist bekannt. Aus einem Text ein Datum zu machen wäre geraten.

## Fortbildungen

Es gibt keinen Fortbildungskatalog mehr und keine automatischen Vorschläge. Stattdessen steht
bei jeder Person direkt im Profil, ob sie an einer Fortbildung **Interesse** hat oder bereits
**angemeldet** ist (`Fortbildungsstatus`) und um welche es geht (`Welche Fortbildung`). Die
Übersicht zeigt beides und lässt sich danach filtern.

## Wie die Anwendung mit der Excel-Datei umgeht

- **Vor jeder Änderung wird neu eingelesen.** Es wird nie auf einem alten Stand gearbeitet.
- **Ist die Datei in Excel geöffnet**, wird nicht geschrieben, sondern gemeldet. Erkannt wird
  das an der Sperrdatei `~$Personal_Bestandsaufnahme.xlsx`.
- **Vor jedem Schreiben wird eine Sicherungskopie angelegt** (die letzten 20 bleiben liegen,
  standardmäßig unter `data/sicherungen/`).
- **Es werden nur die Zellen angefasst, die sich wirklich ändern.** Formeln, Farben,
  Zahlenformate und die Excel-Tabellen bleiben, wie sie sind.
- **Vor dem Schreiben wird geprüft, ob in der Zielzeile noch dieselbe Person steht.** Wurde in
  Excel zwischenzeitlich eine Zeile eingefügt oder gelöscht, bricht die Anwendung ab, statt die
  falsche Person zu überschreiben.
- **Freitext wird nicht vereinheitlicht.** Steht in einer Untersuchungsspalte
  `30.11.2027 (bg)`, dann erkennt die Anwendung das Datum für die Fristenprüfung, lässt den
  Eintrag selbst aber wörtlich stehen.

## Datenschutz

Die Datei enthält Geburtsdaten, Mitgliedsnummern und arbeitsmedizinische Untersuchungen, also
Gesundheitsdaten. Deshalb:

- Die Anwendung ist nur auf dem eigenen Rechner erreichbar (`127.0.0.1`), nicht im Netzwerk.
- Es gibt keine Telemetrie und keine Verbindung zu Dritten.
- Die Personendaten werden **nicht** in eine zweite Datenbank kopiert. In der Datenbank der
  Anwendung stehen nur der Fortbildungskatalog, das Protokoll, die Namensaufteilung, die
  Zugzuteilung, die interne Bemerkung und die Einstellungen. Die Zugzuteilung steht bei allen
  auf `Behandlung` – die Ortsgruppe gehört geschlossen zur Behandlungsgruppe. Die Bemerkung
  (internes Notizfeld) steht nur in der Anwendung und wird nicht in die Excel-Datei geschrieben.
- Die Sicherungskopien liegen bewusst **nicht** im Sync-Ordner, damit nicht 20 Kopien mit
  Gesundheitsdaten in SharePoint landen.

Das Kürzel oben rechts ist keine Anmeldung und schützt nichts – es wird nur ins Protokoll
geschrieben, damit später nachvollziehbar ist, wer was geändert hat.

## Als Windows-Programm verteilen

Aus derselben Codebasis wird über **GitHub Actions** ein Windows-Programm gebaut
(Workflow `.github/workflows/build.yml` im Repository-Stamm):

1. Auf den Branch pushen – der Workflow läuft auf `windows-latest`, führt
   zuerst die **Tests** und eine **Kontrolle der gebündelten Ressourcen**
   (Vorlagen, Statik, Testdaten) aus und baut danach das Paket (PyInstaller).
2. Der fertige Ordner liegt als **Artifact `windows`** auf der Summary-Seite
   des Workflow-Laufs (unten abholbar) – außerhalb des Repos, also keine
   Bootstrapper-Dateien, keine EXE im Versionsverlauf.
3. Zum Verteilen den Ordner archivieren und kopieren – die `Helferverwaltung.exe`
   im Hauptordner startet die Anwendung, der Tag **Datum/Git-Hash** des Artifacts
   zeigt den erzeugten Stand.

**So sieht das Paket aus und so verhält es sich:**

- Programme und Ressourcen liegen in `_internal/` und sind für die Bedienung
  Tabu. **Neben die EXE** kommen die Dinge, die angefasst werden dürfen:
  `.env`, `data/` (Arbeitskopie, Sicherungen, Exports, Datenbank) und die
  Protokolldatei.
- **Keine Signatur** ohne konfiguriertes Zertifikat – baut der Workflow ohne
  eingerichtete Geheimnisse, bleibt das Programm unsigniert und Windows meldet
  anfangs „Unbekannter Herausgeber“. Für den benutzerinternen Einsatz ist das
  akzeptabel; mit Zertifikat in den GitHub-Secrets (z. B. `WINDOWS_ZERTIFIKAT`
  samt Passwort) wird signiert gebaut.
- **Testdaten getrennt:** Workflows und Einzel-EXE nutzen die Übungskopie unter
  `data/arbeitskopie/` – niemals den echten Sync-Ordner. Daran ist nichts zu
  konfigurieren.
- **Aktualisieren** heißt: alten Ordner löschen, neuen entpacken, `.env` und
  gewünschte `data/`-Inhalte zurücklegen. Wo nichts eingetragen ist, gilt der
  Standard wie beschrieben.

---

## Für technisch Interessierte

### Aufbau

```
app/dateizugriff/   der gesamte Zugriff auf die Excel-Datei (die einzige Stelle mit openpyxl)
    schema.py       Spaltendefinitionen und die Datentypen der Schnittstelle
    sync_ordner.py  Implementierung für den lokalen Sync-Ordner
    paket.py        stellt die Paketteile wieder her, die openpyxl beim Speichern verliert
    graph.py        Anbindung über Microsoft Graph (SharePoint), eTag-Konflikte, Offline
app/logic/          Fachlogik ohne Framework-Abhängigkeit
    werte.py        die dreiwertige Auswertung (ja / nein / unbekannt)
    amu.py          Fristen und fehlende Untersuchungen
    jahrespflicht.py  RS-Fortbildung, Jahresgespräch, Unterweisung S/W-Rechte
    gf_todos.py       Gruppenführer-Übersicht: Zuordnung und offene Aufgaben je GF
    uebersicht.py   was je Person in der Übersicht zusammenkommt
    namen.py        Vor- und Nachname trennen
    export.py       die 40 Spalten der Exportvorlage
app/routes/         HTTP-Schicht, dünn
    todos.py         GF-Übersicht und schnelle Zuordnung
scripts/
    pruefe_rundlauf.py        bleibt die Datei beim Speichern heil?
    pruefe_abnahme.py         die Abnahmekriterien, auf einer Wegwerfkopie
    umstellen_eine_gruppe.py   erste Umstellung (ein Personalblatt, Ausgeschiedene)
    umstellen_neue_felder.py   zweite Umstellung (Telefon, Fortbildung, Zugzuteilung)
    umstellen_gf_groessen.py   dritte Umstellung (GF, Dienstkleidung/CBRN Größe)
```

Der Dateizugriff liegt vollständig hinter der abstrakten Klasse `Helferdatei`
(`app/dateizugriff/__init__.py`). Nach außen gehen nur Dataclasses – keine Arbeitsmappen, keine
Zellbezüge. Ist die App-Registrierung im Malteser-Tenant gesetzt, arbeitet dieselbe Schnittstelle
über Microsoft Graph (`graph.py`) mit einer lokalen Arbeitskopie als Puffer; der Rest der
Anwendung ändert sich nicht. Details siehe Abschnitt „SharePoint synchronisieren“.

### Prüfskripte

```bash
.venv/bin/python scripts/pruefe_rundlauf.py   # bleibt die Datei beim Speichern heil?
.venv/bin/python scripts/pruefe_abnahme.py    # die Abnahmekriterien, auf einer Wegwerfkopie
```

`pruefe_rundlauf.py` ist der wichtigere von beiden. openpyxl verliert beim Speichern die
`customXml`-Teile (SharePoint-Inhaltstyp) und die Druckeinstellungen; `paket.py` holt sie
zurück. Was **nicht** wiederhergestellt wird, weil Excel es selbst neu aufbaut:

- `xl/calcChain.xml` (Berechnungsreihenfolge),
- `xl/sharedStrings.xml` (openpyxl legt Texte direkt in den Blättern ab),
- die zwischengespeicherten Ergebnisse der Formeln in der `Fehlsumme`-Zeile,
- Sammelformeln werden ausgeschrieben (aus einer Formel mit 40 Verweisen werden 40 Formeln –
  rechnerisch identisch).

Das Vertraulichkeitskennzeichen der Datei („Intern“) bleibt erhalten.

### Tests

```bash
.venv/bin/python -m pytest tests/ -q
```

Die Suite läuft ohne Netz und ohne die echten Daten anzufassen: jede Datei und
Datenbank wird frisch im Wegwerf-Verzeichnis angelegt, Microsoft Graph ist ein
Nachbau (`httpx.MockTransport`). Neben den Einzelmodulen gibt es einen
Ende-zu-Ende-Test (`test_end_to_end_integration.py`), der die Anwendung so
zusammenschaltet, wie sie wirklich läuft – das Dashboard, die Personal- und
Profilseiten inklusive Schreiben in die Datei, die Gruppenführer-Zuweisung und
-Aufgaben, die Namenskontrolle, das Protokoll, den Export-Round-Trip und die
Synchronisierung in beiden Modi (lokaler Sync-Ordner und SharePoint).

### Umstellung im September 2026

Einmalig mit `scripts/umstellen_eine_gruppe.py` ausgeführt (Probelauf mit `--probelauf`):

- `Gruppe 2` wurde nach `Gruppe 1` überführt – 41 statt vorher 42 Personen, weil
  `Sven Marquardt` in beiden Blättern stand. Die vollständigere Zeile aus Gruppe 1 blieb, die
  Notiz „Arno nicht gepflegt“ wurde nach `Sonstige` übernommen. Die Spalte `Schicht` entfiel;
  sie war bei allen 13 Personen leer.
- `Eigene Kleidung / Dienstausweis` heißt jetzt `Eigene Dienstkleidung`; `Dienstausweis` kam als
  eigene Spalte dazu und hat den bisherigen Wert übernommen.
- `RS Fortbildung 2025` heißt jetzt `RS Fortbildung` und führt ein Datum.
- Neu: `Status`, `Passiv seit` und das Blatt `Ausgeschieden`.

Danach mit `scripts/umstellen_neue_felder.py` ergänzt:

- `Telefon` – telefonische Erreichbarkeit.
- `Fortbildungsstatus` (Interesse / angemeldet) und `Welche Fortbildung`.
- Die Zugzuteilung aller Personen auf `Behandlung` gesetzt.

Danach mit `scripts/umstellen_gf_groessen.py` ergänzt:

- `GF` – Zuordnung zum Gruppenführer (Niklas | Nino), Auswahl-Spalte.
- `Dienstkleidung Größe` – Konfektionsgröße für die eigene Dienstkleidung.
- `CBRN Kleidergröße` – Konfektionsgröße für die CBRN-Schutzausrüstung.

Alle neuen Spalten hängen **hinten** an. Ein Einfügen mitten in der Tabelle hätte die
bedingten Formatierungen und die Tabellenbereiche der Datei verschoben.

### Bekannte Grenzen

- Die Sperrdatei-Prüfung erkennt nur das Excel-Desktopprogramm. Wird die Datei in Excel im
  Browser bearbeitet, greift sie nicht – deshalb wird zusätzlich der Änderungszeitstempel vor
  und nach dem Schreiben verglichen.
- Die `COUNTIF`-Formeln der `Fehlsumme`-Zeile werden beim Anlegen einer Person nicht
  mitgezogen; sie zählen weiterhin ihren alten Bereich. Sie sind laut Auftrag ohne Bedeutung.
- Zeile 30 in `Gruppe 1` lag schon vor dieser Anwendung außerhalb der Excel-Tabelle
  `Tabelle1` (A1:AV29) und wird von den Summenformeln nicht erfasst.

### Nicht gebaut

Dienstplanung, Materialverwaltung, Fahrzeuge, Finanzen, Kontakte, Benutzerkonten, Rollen und
Rechte, mobile App, E-Mail-Benachrichtigungen. Ebenfalls bewusst nicht gebaut: ein Abgleich mit
der bestehenden Liste der PSA-Beauftragten (dort stehen 99 Personen der gesamten Gliederung,
unsere 42 überschneiden sich mit 33 davon) – der Export erzeugt stattdessen eine eigene Datei.
