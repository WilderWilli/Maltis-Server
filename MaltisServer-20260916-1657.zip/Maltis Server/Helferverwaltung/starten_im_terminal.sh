#!/usr/bin/env bash
# Oeffnet ein Terminalfenster und startet darin die Helferverwaltung.
#
# Diese Datei wird von der Schreibtisch-Verknuepfung aufgerufen. Sie sucht sich
# selbst ein passendes Terminalprogramm - je nachdem, was auf dem Rechner da ist.
ORDNER="$(cd "$(dirname "$0")" && pwd)"
START="$ORDNER/start.sh"
TITEL="Helferverwaltung"

# Jeder Eintrag: Programm + die Art, wie es einen Befehl entgegennimmt.
starte() {
  case "$1" in
    cosmic-term)     cosmic-term -- "$START" ;;
    gnome-terminal)  gnome-terminal --title="$TITEL" -- "$START" ;;
    kgx)             kgx -- "$START" ;;
    konsole)         konsole --title "$TITEL" -e "$START" ;;
    xfce4-terminal)  xfce4-terminal --title="$TITEL" --command="$START" ;;
    alacritty)       alacritty --title "$TITEL" -e "$START" ;;
    kitty)           kitty --title "$TITEL" "$START" ;;
    foot)            foot --title="$TITEL" "$START" ;;
    xterm)           xterm -title "$TITEL" -geometry 90x28 -e "$START" ;;
    *) return 1 ;;
  esac
}

for terminal in cosmic-term gnome-terminal kgx konsole xfce4-terminal alacritty kitty foot xterm; do
  if command -v "$terminal" >/dev/null 2>&1 && starte "$terminal"; then
    exit 0
  fi
done

# Kein Terminal gefunden - dann eben ohne Fenster starten.
notify-send "Helferverwaltung" "Kein Terminalfenster gefunden. Die Anwendung wird im Hintergrund gestartet." 2>/dev/null || true
"$START" >/dev/null 2>&1 &
