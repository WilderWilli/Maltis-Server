"""Einmalige Umstellung der führenden Datei.

Führt die Änderungen aus, die im September 2026 beschlossen wurden:

  1. `Eigene Kleidung / Dienstausweis`  ->  `Eigene Dienstkleidung`
     und neue Spalte `Dienstausweis`; der bisherige Wert kommt in beide.
  2. `RS Fortbildung 2025`  ->  `RS Fortbildung` (künftig ein Datum).
     Der bisherige Inhalt bleibt wörtlich stehen.
  3. Neue Spalten `Status` (aktiv/passiv) und `Passiv seit`.
  4. Alle Personen aus `Gruppe 2` wandern nach `Gruppe 1`.
     `Sven Marquardt` steht in beiden Blättern - die Gruppe-1-Zeile bleibt,
     die Notiz aus Gruppe 2 wird nach `Sonstige` übernommen.
  5. Neues Blatt `Ausgeschieden` für Personal, das die Ortsgruppe verlässt.

Neue Spalten werden hinten angehängt und nicht in der Mitte eingefügt: ein
Einfügen mitten in der Tabelle würde die bedingten Formatierungen und die
Tabellenbereiche der Datei verschieben.

Vor dem Schreiben wird eine Sicherungskopie angelegt. Das Skript erkennt, wenn
die Umstellung schon gelaufen ist, und tut dann nichts.

Aufruf:  .venv/bin/python scripts/umstellen_eine_gruppe.py
         .venv/bin/python scripts/umstellen_eine_gruppe.py --probelauf
"""

from __future__ import annotations

import shutil
import sys
from datetime import datetime
from pathlib import Path

import openpyxl
from openpyxl.utils import get_column_letter

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from app.config import (  # noqa: E402
    BLATT_AUSGESCHIEDEN,
    BLATT_GRUPPE_1,
    HELFERDATEI_PFAD,
    SICHERUNGS_ORDNER,
)
from app.dateizugriff.paket import stelle_paketteile_wieder_her  # noqa: E402
from app.dateizugriff.schema import (  # noqa: E402
    SPALTE_AUSTRITT,
    SPALTE_DIENSTAUSWEIS,
    SPALTE_DIENSTKLEIDUNG,
    SPALTE_NAME,
    SPALTE_NR,
    SPALTE_PASSIV_SEIT,
    SPALTE_RS_FORTBILDUNG,
    SPALTE_STATUS,
)

ALT_BLATT_GRUPPE_2 = "Gruppe 2"
ALT_KLEIDUNG = "Eigene Kleidung / Dienstausweis"
ALT_RS = "RS Fortbildung 2025"
ENDE_MARKE = "fehlsumme"

# Reihenfolge, in der die neuen Spalten angehängt werden.
NEUE_SPALTEN = (SPALTE_DIENSTAUSWEIS, SPALTE_STATUS, SPALTE_PASSIV_SEIT)


def ueberschriften(blatt) -> list[str]:
    werte = [zelle.value for zelle in next(blatt.iter_rows(min_row=1, max_row=1))]
    texte = [str(w) if w is not None else "" for w in werte]
    while texte and not texte[-1]:
        texte.pop()
    return texte


def personenzeilen(blatt, name_spalte: int) -> tuple[list[int], int | None]:
    """(Zeilennummern mit Personen, Zeile der Fehlsumme)."""
    zeilen: list[int] = []
    for nr in range(2, blatt.max_row + 1):
        wert = blatt.cell(row=nr, column=name_spalte).value
        name = str(wert).strip() if wert is not None else ""
        if name.lower() == ENDE_MARKE:
            return zeilen, nr
        if name:
            zeilen.append(nr)
    return zeilen, None


def main() -> int:
    probelauf = "--probelauf" in sys.argv
    pfad = HELFERDATEI_PFAD
    if not pfad.is_file():
        print(f"FEHLER: Datei nicht gefunden: {pfad}")
        return 2

    print(f"Datei: {pfad}")
    print("Probelauf – es wird nichts geschrieben.\n" if probelauf else "")

    mappe = openpyxl.load_workbook(pfad, data_only=False)
    g1 = mappe[BLATT_GRUPPE_1]
    kopf = ueberschriften(g1)

    if SPALTE_STATUS in kopf and ALT_KLEIDUNG not in kopf:
        print("Die Umstellung ist bereits gelaufen. Es gibt nichts zu tun.")
        return 0

    schritte: list[str] = []

    # ------------------------------------------------------------------
    # 1. + 2. Spalten umbenennen
    # ------------------------------------------------------------------
    for alt, neu in ((ALT_KLEIDUNG, SPALTE_DIENSTKLEIDUNG), (ALT_RS, SPALTE_RS_FORTBILDUNG)):
        if alt in kopf:
            g1.cell(row=1, column=kopf.index(alt) + 1).value = neu
            kopf[kopf.index(alt)] = neu
            schritte.append(f"Spalte umbenannt: „{alt}“ -> „{neu}“")

    # ------------------------------------------------------------------
    # 3. Neue Spalten hinten anhängen
    # ------------------------------------------------------------------
    for spalte in NEUE_SPALTEN:
        if spalte in kopf:
            continue
        index = len(kopf) + 1
        g1.cell(row=1, column=index).value = spalte
        # Kopfzeile im selben Format wie die Nachbarspalte
        g1.cell(row=1, column=index)._style = g1.cell(row=1, column=index - 1)._style
        kopf.append(spalte)
        schritte.append(f"Neue Spalte angehängt: „{spalte}“ (Spalte {get_column_letter(index)})")

    name_spalte = kopf.index(SPALTE_NAME) + 1
    kleidung_spalte = kopf.index(SPALTE_DIENSTKLEIDUNG) + 1
    ausweis_spalte = kopf.index(SPALTE_DIENSTAUSWEIS) + 1

    zeilen_g1, fehlsumme_g1 = personenzeilen(g1, name_spalte)

    # ------------------------------------------------------------------
    # 1b. Bisherigen Kleidungswert auch in den Dienstausweis übernehmen
    # ------------------------------------------------------------------
    uebernommen = 0
    for zeile in zeilen_g1:
        wert = g1.cell(row=zeile, column=kleidung_spalte).value
        if wert not in (None, "") and g1.cell(row=zeile, column=ausweis_spalte).value in (None, ""):
            g1.cell(row=zeile, column=ausweis_spalte).value = wert
            uebernommen += 1
    if uebernommen:
        schritte.append(f"Bisherigen Kleidungswert in „{SPALTE_DIENSTAUSWEIS}“ übernommen: "
                        f"{uebernommen} Person(en)")

    # ------------------------------------------------------------------
    # 4. Gruppe 2 nach Gruppe 1 überführen
    # ------------------------------------------------------------------
    verschoben = 0
    zusammengefuehrt: list[str] = []
    if ALT_BLATT_GRUPPE_2 in mappe.sheetnames:
        g2 = mappe[ALT_BLATT_GRUPPE_2]
        kopf_g2 = ueberschriften(g2)
        name_spalte_g2 = kopf_g2.index(SPALTE_NAME) + 1
        zeilen_g2, fehlsumme_g2 = personenzeilen(g2, name_spalte_g2)

        vorhandene_namen = {
            str(g1.cell(row=z, column=name_spalte).value or "").strip(): z for z in zeilen_g1
        }
        groesste_nr = max(
            (int(g1.cell(row=z, column=kopf.index(SPALTE_NR) + 1).value or 0)
             for z in zeilen_g1),
            default=0,
        )

        zu_verschieben = []
        for zeile in zeilen_g2:
            name = str(g2.cell(row=zeile, column=name_spalte_g2).value or "").strip()
            if name in vorhandene_namen:
                # Entscheidung E5: die Gruppe-1-Zeile bleibt. Nur eine Notiz,
                # die dort noch fehlt, wird übernommen.
                ziel = vorhandene_namen[name]
                sonstige_g1 = kopf.index("Sonstige") + 1
                sonstige_g2 = kopf_g2.index("Sonstige") + 1
                notiz = g2.cell(row=zeile, column=sonstige_g2).value
                vorhanden = g1.cell(row=ziel, column=sonstige_g1).value
                if notiz and not vorhanden:
                    g1.cell(row=ziel, column=sonstige_g1).value = notiz
                    zusammengefuehrt.append(f"{name} (Notiz „{notiz}“ übernommen)")
                else:
                    zusammengefuehrt.append(name)
                continue
            zu_verschieben.append(zeile)

        # Platz schaffen: die neuen Zeilen kommen unter die letzte Person.
        erste_neue = (max(zeilen_g1) if zeilen_g1 else 1) + 1
        if fehlsumme_g1 is not None and zu_verschieben:
            fehlend = len(zu_verschieben) - (fehlsumme_g1 - erste_neue)
            if fehlend > 0:
                g1.insert_rows(erste_neue, fehlend)
                schritte.append(f"{fehlend} Zeile(n) vor der Summenzeile eingefügt")

        for versatz, quelle in enumerate(zu_verschieben):
            ziel = erste_neue + versatz
            groesste_nr += 1
            for spalte_name in kopf:
                if spalte_name not in kopf_g2:
                    continue
                wert = g2.cell(row=quelle, column=kopf_g2.index(spalte_name) + 1).value
                if wert in (None, ""):
                    continue
                zielzelle = g1.cell(row=ziel, column=kopf.index(spalte_name) + 1)
                zielzelle.value = wert
                if spalte_name in ("Geburtsdatum", "Eintrittsdatum Gliederung") or (
                    isinstance(wert, datetime)
                ):
                    zielzelle.number_format = "TT.MM.JJJJ"
            g1.cell(row=ziel, column=kopf.index(SPALTE_NR) + 1).value = groesste_nr
            # Kleidungswert auch hier in den Dienstausweis
            wert = g1.cell(row=ziel, column=kleidung_spalte).value
            if wert not in (None, ""):
                g1.cell(row=ziel, column=ausweis_spalte).value = wert
            verschoben += 1

        # Die verschobenen Zeilen in Gruppe 2 leeren
        if not probelauf:
            for zeile in zeilen_g2:
                for spalte in range(1, len(kopf_g2) + 1):
                    g2.cell(row=zeile, column=spalte).value = None
        schritte.append(f"{verschoben} Person(en) von „Gruppe 2“ nach „{BLATT_GRUPPE_1}“ verschoben")
        if zusammengefuehrt:
            schritte.append("In Gruppe 1 bereits vorhanden, Zeile dort behalten: "
                            + ", ".join(zusammengefuehrt))

    # ------------------------------------------------------------------
    # 5. Blatt „Ausgeschieden“ anlegen
    # ------------------------------------------------------------------
    if BLATT_AUSGESCHIEDEN not in mappe.sheetnames:
        blatt = mappe.create_sheet(BLATT_AUSGESCHIEDEN)
        for index, spalte in enumerate(kopf + [SPALTE_AUSTRITT], start=1):
            blatt.cell(row=1, column=index).value = spalte
        blatt.freeze_panes = "A2"
        schritte.append(f"Blatt „{BLATT_AUSGESCHIEDEN}“ angelegt "
                        f"({len(kopf) + 1} Spalten)")

    # ------------------------------------------------------------------
    # Tabellenbereich nachziehen
    # ------------------------------------------------------------------
    zeilen_neu, _ = personenzeilen(g1, name_spalte)
    letzte = max(zeilen_neu) if zeilen_neu else 1
    for tabelle in getattr(g1, "tables", {}).values():
        tabelle.ref = f"A1:{get_column_letter(len(kopf))}{letzte}"
        schritte.append(f"Tabellenbereich auf {tabelle.ref} erweitert")

    print("Geplante Änderungen:")
    for schritt in schritte:
        print(f"  - {schritt}")
    print(f"\n  Personen in „{BLATT_GRUPPE_1}“ danach: {len(zeilen_neu)}")
    print(f"  Spalten danach: {len(kopf)}")

    if probelauf:
        print("\nProbelauf – die Datei wurde nicht verändert.")
        return 0

    SICHERUNGS_ORDNER.mkdir(parents=True, exist_ok=True)
    stempel = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    sicherung = SICHERUNGS_ORDNER / f"{pfad.stem}_vor_umstellung_{stempel}{pfad.suffix}"
    shutil.copy2(pfad, sicherung)

    vorlaeufig = pfad.with_name(f".{pfad.name}.umstellung")
    mappe.save(vorlaeufig)
    stelle_paketteile_wieder_her(pfad, vorlaeufig)
    vorlaeufig.replace(pfad)

    print(f"\nUmstellung abgeschlossen.\nSicherungskopie: {sicherung}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
