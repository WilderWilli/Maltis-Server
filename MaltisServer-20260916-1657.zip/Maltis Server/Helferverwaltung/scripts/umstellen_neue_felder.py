"""Zweite Umstellung der führenden Datei (September 2026).

Ergänzt die Spalten, die nach der ersten Umstellung dazugekommen sind:

  * `Telefon`              - telefonische Erreichbarkeit
  * `Fortbildungsstatus`   - Interesse | angemeldet | leer
  * `Welche Fortbildung`   - Freitext dazu, welche Fortbildung gemeint ist

Ausserdem wird die Zugzuteilung aller vorhandenen Personen auf `Behandlung`
gesetzt - die Ortsgruppe ist geschlossen der Behandlungsgruppe zugeordnet. Die
Zugzuteilung steht in der Datenbank der Anwendung, nicht in der Excel-Datei.

Die neuen Spalten haengen wie beim ersten Mal hinten an, damit die bedingten
Formatierungen und die Tabellenbereiche der Datei unberuehrt bleiben.

Das Skript ist wiederholbar: was schon da ist, wird nicht noch einmal angelegt.

Aufruf:  .venv/bin/python scripts/umstellen_neue_felder.py
         .venv/bin/python scripts/umstellen_neue_felder.py --probelauf
"""

from __future__ import annotations

import shutil
import sys
from datetime import datetime
from pathlib import Path

import openpyxl
from openpyxl.utils import get_column_letter

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from app.config import (  # noqa: E402
    BLATT_AUSGESCHIEDEN,
    BLATT_GRUPPE_1,
    HELFERDATEI_PFAD,
    SICHERUNGS_ORDNER,
)
from app.dateizugriff.paket import stelle_paketteile_wieder_her  # noqa: E402
from app.dateizugriff.schema import (  # noqa: E402
    SPALTE_FORTBILDUNG_STATUS,
    SPALTE_FORTBILDUNG_WELCHE,
    SPALTE_TELEFON,
)

NEUE_SPALTEN = (SPALTE_TELEFON, SPALTE_FORTBILDUNG_STATUS, SPALTE_FORTBILDUNG_WELCHE)
STANDARD_ZUGZUTEILUNG = "Behandlung"


def ueberschriften(blatt) -> list[str]:
    werte = [zelle.value for zelle in next(blatt.iter_rows(min_row=1, max_row=1))]
    texte = [str(w) if w is not None else "" for w in werte]
    while texte and not texte[-1]:
        texte.pop()
    return texte


def ergaenze(blatt, schritte: list[str]) -> int:
    kopf = ueberschriften(blatt)
    ergaenzt = 0
    for spalte in NEUE_SPALTEN:
        if spalte in kopf:
            continue
        index = len(kopf) + 1
        zelle = blatt.cell(row=1, column=index)
        zelle.value = spalte
        zelle._style = blatt.cell(row=1, column=index - 1)._style
        kopf.append(spalte)
        ergaenzt += 1
        schritte.append(
            f"{blatt.title}: Spalte „{spalte}“ angehängt ({get_column_letter(index)})"
        )
    return ergaenzt


def zugzuteilung_setzen(probelauf: bool, schritte: list[str]) -> None:
    from sqlalchemy import select

    from app import models
    from app.database import Base, SessionLocal, engine
    from app.dateizugriff import hole_helferdatei

    Base.metadata.create_all(engine)
    datei = hole_helferdatei()
    if not datei.ist_erreichbar():
        return

    db = SessionLocal()
    try:
        vorhanden = {
            (z.blatt, z.name): z for z in db.scalars(select(models.Helferzusatz)).all()
        }
        gesetzt = 0
        for person in datei.lade_personen():
            eintrag = vorhanden.get((person.blatt, person.name))
            if eintrag is None:
                eintrag = models.Helferzusatz(blatt=person.blatt, name=person.name)
                db.add(eintrag)
            if not eintrag.zugzuteilung:
                eintrag.zugzuteilung = STANDARD_ZUGZUTEILUNG
                gesetzt += 1
        if probelauf:
            db.rollback()
        else:
            db.commit()
        if gesetzt:
            schritte.append(
                f"Zugzuteilung bei {gesetzt} Person(en) auf „{STANDARD_ZUGZUTEILUNG}“ gesetzt"
            )
    finally:
        db.close()


def main() -> int:
    probelauf = "--probelauf" in sys.argv
    pfad = HELFERDATEI_PFAD
    if not pfad.is_file():
        print(f"FEHLER: Datei nicht gefunden: {pfad}")
        return 2

    print(f"Datei: {pfad}")
    if probelauf:
        print("Probelauf – es wird nichts geschrieben.\n")

    mappe = openpyxl.load_workbook(pfad, data_only=False)
    schritte: list[str] = []
    ergaenzt = 0
    for blattname in (BLATT_GRUPPE_1, BLATT_AUSGESCHIEDEN):
        if blattname in mappe.sheetnames:
            ergaenzt += ergaenze(mappe[blattname], schritte)

    # Der Tabellenbereich muss die neuen Spalten mit abdecken.
    if ergaenzt:
        blatt = mappe[BLATT_GRUPPE_1]
        breite = len(ueberschriften(blatt))
        for tabelle in getattr(blatt, "tables", {}).values():
            import re

            treffer = re.fullmatch(r"([A-Z]+)(\d+):([A-Z]+)(\d+)", str(tabelle.ref).upper())
            if treffer:
                _, von_zeile, _, bis_zeile = treffer.groups()
                tabelle.ref = f"A{von_zeile}:{get_column_letter(breite)}{bis_zeile}"
                schritte.append(f"Tabellenbereich auf {tabelle.ref} erweitert")

    zugzuteilung_setzen(probelauf, schritte)

    if not schritte:
        print("Es gibt nichts zu tun – alles schon vorhanden.")
        return 0

    print("Änderungen:")
    for schritt in schritte:
        print(f"  - {schritt}")

    if probelauf:
        print("\nProbelauf – die Datei wurde nicht verändert.")
        return 0

    if ergaenzt:
        SICHERUNGS_ORDNER.mkdir(parents=True, exist_ok=True)
        stempel = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        sicherung = SICHERUNGS_ORDNER / f"{pfad.stem}_vor_neuen_feldern_{stempel}{pfad.suffix}"
        shutil.copy2(pfad, sicherung)

        vorlaeufig = pfad.with_name(f".{pfad.name}.umstellung")
        mappe.save(vorlaeufig)
        stelle_paketteile_wieder_her(pfad, vorlaeufig)
        vorlaeufig.replace(pfad)
        print(f"\nFertig.\nSicherungskopie: {sicherung}")
    else:
        print("\nFertig (nur die Zugzuteilung war zu setzen).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
