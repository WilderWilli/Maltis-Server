"""Abnahmetest: schreibt in eine Wegwerfkopie und prüft, was sich verändert hat.

Geprüft werden die Punkte aus dem Auftrag:

  1. Ein Feld ändern  -> genau eine Zelle hat sich geändert, sonst nichts.
  2. Person anlegen    -> neue Zeile da, alle alten Zeilen zeichengenau unverändert.
  3. Datei in Excel offen -> verständliche Meldung, keine halb geschriebene Datei.
  4. Gemischte Werte   -> "30.11.2027 (bg)" überlebt das Speichern wörtlich.
  5. Ausgliedern       -> Person verschwindet aus der Übersicht, Daten bleiben.

Aufruf:  .venv/bin/python scripts/pruefe_abnahme.py
"""

from __future__ import annotations

import os
import re
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile
from datetime import date
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

ARBEITSKOPIE = BASE_DIR / "data" / "arbeitskopie" / "Personal_Bestandsaufnahme.xlsx"
_TMP = Path(tempfile.mkdtemp(prefix="abnahme_"))
PRUEFDATEI = _TMP / "Personal_Bestandsaufnahme.xlsx"
shutil.copy2(ARBEITSKOPIE, PRUEFDATEI)

# Muss vor dem Import von app.config gesetzt sein.
os.environ["HELFERDATEI_PFAD"] = str(PRUEFDATEI)
os.environ["SICHERUNGS_ORDNER"] = str(_TMP / "sicherungen")

from app.dateizugriff import hole_helferdatei  # noqa: E402
from app.dateizugriff.sync_ordner import _vergleichbar  # noqa: E402
from app.dateizugriff.schema import DateiGesperrt, ZeileVeraendert  # noqa: E402

NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def _spalte(bezug: str) -> int:
    n = 0
    for zeichen in re.match(r"([A-Z]+)", bezug).group(1):
        n = n * 26 + ord(zeichen) - 64
    return n


def alle_zellen(pfad: Path) -> dict[tuple[str, int, int], str]:
    """Jede Zelle jedes Blattes als Text - Grundlage für den Vorher/Nachher-Vergleich."""
    ergebnis: dict[tuple[str, int, int], str] = {}
    with zipfile.ZipFile(pfad) as z:
        namen = z.namelist()
        texte = (
            [
                "".join(t.text or "" for t in si.iter(NS + "t"))
                for si in ET.fromstring(z.read("xl/sharedStrings.xml"))
            ]
            if "xl/sharedStrings.xml" in namen
            else []
        )
        mappe = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        ziele = {
            r.get("Id"): r.get("Target")
            for r in rels
            if r.get("Type", "").endswith("/worksheet")
        }
        rid = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"

        for blatt_el in mappe.iter(NS + "sheet"):
            name = blatt_el.get("name")
            ziel = ziele[blatt_el.get(rid)].lstrip("/")
            pfad_im_paket = ziel if ziel.startswith("xl/") else f"xl/{ziel}"
            blatt = ET.fromstring(z.read(pfad_im_paket))
            for zeile in blatt.iter(NS + "row"):
                nr = int(zeile.get("r"))
                for zelle in zeile.iter(NS + "c"):
                    typ = zelle.get("t")
                    wert_el = zelle.find(NS + "v")
                    formel_el = zelle.find(NS + "f")
                    inline = zelle.find(NS + "is")
                    if typ == "s" and wert_el is not None:
                        wert = texte[int(wert_el.text)]
                    elif typ == "inlineStr" and inline is not None:
                        wert = "".join(t.text or "" for t in inline.iter(NS + "t"))
                    elif wert_el is not None:
                        wert = wert_el.text
                    else:
                        wert = None
                    # Formelzellen: nur die Formel zählt, das zwischengespeicherte
                    # Ergebnis rechnet Excel neu.
                    if formel_el is not None:
                        wert = "=" + (formel_el.text or "")
                    if wert is not None:
                        ergebnis[(name, nr, _spalte(zelle.get("r")))] = str(wert)
    return ergebnis


def _ist_ausgeschriebene_sammelformel(alt: str | None, neu: str | None) -> bool:
    """Excel speichert gleichartige Formeln einer Zeile als Sammelformel: nur die
    erste Zelle traegt den Text, die uebrigen verweisen darauf. openpyxl schreibt
    beim Speichern jede Formel aus. Das Ergebnis ist dasselbe - Excel selbst
    expandiert genauso -, es ist also keine inhaltliche Aenderung.
    """
    return alt == "=" and (neu or "").startswith("=") and len(neu or "") > 1


def unterschiede(vorher: dict, nachher: dict) -> tuple[list[tuple], int]:
    """(inhaltliche Unterschiede, Anzahl ausgeschriebener Sammelformeln)."""
    echte: list[tuple] = []
    sammelformeln = 0
    for schluessel in sorted(set(vorher) | set(nachher)):
        alt, neu = vorher.get(schluessel), nachher.get(schluessel)
        if alt == neu:
            continue
        if _ist_ausgeschriebene_sammelformel(alt, neu):
            sammelformeln += 1
        else:
            echte.append((schluessel, alt, neu))
    return echte, sammelformeln


def _block_unter_den_personen(pfad: Path) -> list[str]:
    """Inhalt der Summen- und Notizzeilen unterhalb der Personen.

    Beim Einfuegen einer Zeile rutscht dieser Block nach unten. Sein *Inhalt*
    darf sich dabei nicht aendern - genau das wird hier vergleichbar gemacht.
    """
    zellen = alle_zellen(pfad)
    zeilen: dict[int, list[str]] = {}
    for (blatt, zeile, spalte), wert in zellen.items():
        if blatt != "Gruppe 1":
            continue
        zeilen.setdefault(zeile, []).append(f"{spalte}={wert}")
    # Alles ab der Fehlsumme-Zeile, in Reihenfolge, ohne die Zeilennummern.
    start = min(
        (z for z, inhalt in zeilen.items() if any(w.endswith("=Fehlsumme") for w in inhalt)),
        default=None,
    )
    if start is None:
        return []
    return [
        "|".join(sorted(zeilen[z])) for z in sorted(zeilen) if z >= start
    ]


def melde(nummer: int, titel: str, bestanden: bool, zusatz: str = "") -> bool:
    marke = "BESTANDEN" if bestanden else "FEHLGESCHLAGEN"
    print(f"\n{nummer}. {titel}\n   -> {marke}")
    if zusatz:
        for zeile in zusatz.splitlines():
            print(f"      {zeile}")
    return bestanden


def main() -> int:
    datei = hole_helferdatei()
    ergebnisse: list[bool] = []
    print(f"Prüfdatei: {PRUEFDATEI}")

    # ------------------------------------------------------------------
    # 1. Ein Feld ändern
    # ------------------------------------------------------------------
    vorher = alle_zellen(PRUEFDATEI)
    person = next(p for p in datei.lade_personen() if p.name == "Eva Kapels")
    saetze = datei.speichere_person(person.schluessel, {"PSNV": "y"})
    nachher = alle_zellen(PRUEFDATEI)
    diff, sammelformeln = unterschiede(vorher, nachher)
    ergebnisse.append(
        melde(
            1, "Ein Feld ändern – nur diese Zelle ändert sich",
            len(diff) == 1 and len(saetze) == 1,
            "\n".join(f"{k}: {a!r} -> {b!r}" for k, a, b in diff)
            + f"\nProtokollsätze: {[(s.zelle, s.alter_wert, s.neuer_wert) for s in saetze]}"
            + f"\nzusätzlich ausgeschriebene Sammelformeln (ohne Wirkung): {sammelformeln}",
        )
    )

    # ------------------------------------------------------------------
    # 2. Unveränderte Felder werden nicht angefasst
    # ------------------------------------------------------------------
    vorher = alle_zellen(PRUEFDATEI)
    person = next(p for p in datei.lade_personen() if p.name == "Eva Kapels")
    saetze = datei.speichere_person(
        person.schluessel, {"PSNV": "y", "Medizinisch": person.wert("Medizinisch")}
    )
    diff, _ = unterschiede(vorher, alle_zellen(PRUEFDATEI))
    ergebnisse.append(
        melde(
            2, "Gleicher Wert erneut gespeichert – die Datei bleibt unangetastet",
            not diff and not saetze,
            f"Änderungen: {len(diff)}, Protokollsätze: {len(saetze)}",
        )
    )

    # ------------------------------------------------------------------
    # 3. Gemischter Wert überlebt wörtlich
    # ------------------------------------------------------------------
    zaubitzer = next(p for p in datei.lade_personen() if p.name == "Anna Zaubitzer")
    vorher_g25 = zaubitzer.wert("G25")
    datei.speichere_person(zaubitzer.schluessel, {"PSNV": "y"})
    nachher_g25 = next(
        p for p in datei.lade_personen() if p.name == "Anna Zaubitzer"
    ).wert("G25")
    ergebnisse.append(
        melde(
            3, "Gemischter Wert bleibt wörtlich erhalten",
            vorher_g25 == nachher_g25 == "30.11.2027 (bg)",
            f"vorher: {vorher_g25!r}\nnachher: {nachher_g25!r}",
        )
    )

    # ------------------------------------------------------------------
    # 4. Ausgliedern und zurückholen
    # ------------------------------------------------------------------
    vorher_aktiv = datei.lade_personen()
    vorher_ausgeschieden = len(datei.lade_ausgeschiedene())
    kandidat = next(p for p in vorher_aktiv if p.name == "Max Mackart")
    werte_vorher = {k: v for k, v in kandidat.werte.items() if v not in (None, "")}
    ziel = datei.gliedere_aus(kandidat.schluessel, date(2026, 6, 30))

    nach_aktiv = datei.lade_personen()
    ausgeschieden = datei.lade_ausgeschiedene()
    verschoben = next((p for p in ausgeschieden if p.name == "Max Mackart"), None)
    # Es koennen schon frueher Ausgeschiedene im Blatt stehen - geprueft wird die
    # Veraenderung, nicht ein leeres Blatt.
    daten_erhalten = verschoben is not None and all(
        _vergleichbar(verschoben.wert(k)) == _vergleichbar(v)
        for k, v in werte_vorher.items()
        if k != "Nr"
    )
    austritt_gesetzt = verschoben is not None and verschoben.wert("Austrittsdatum") == date(2026, 6, 30)

    ergebnisse.append(
        melde(
            4, "Person ausgliedern – verschwindet aus dem aktiven Personal, Daten bleiben",
            len(nach_aktiv) == len(vorher_aktiv) - 1
            and len(ausgeschieden) == vorher_ausgeschieden + 1
            and not any(p.name == "Max Mackart" for p in nach_aktiv)
            and daten_erhalten and austritt_gesetzt,
            f"aktiv: {len(vorher_aktiv)} -> {len(nach_aktiv)}\n"
            f"ausgeschieden: {vorher_ausgeschieden} -> {len(ausgeschieden)} "
            f"({ziel.blatt} Zeile {ziel.zeile})\n"
            f"alle {len(werte_vorher)} gefüllten Felder erhalten: {daten_erhalten}\n"
            f"Austrittsdatum gesetzt: {austritt_gesetzt}",
        )
    )

    # ... und wieder zurück
    zurueck = datei.hole_zurueck(verschoben.schluessel)
    wieder_aktiv = datei.lade_personen()
    wieder_da = next((p for p in wieder_aktiv if p.name == "Max Mackart"), None)
    ergebnisse.append(
        melde(
            5, "Person zurückholen – steht wieder im aktiven Personal",
            wieder_da is not None
            and len(wieder_aktiv) == len(vorher_aktiv)
            and len(datei.lade_ausgeschiedene()) == vorher_ausgeschieden
            and all(
                _vergleichbar(wieder_da.wert(k)) == _vergleichbar(v)
                for k, v in werte_vorher.items() if k != "Nr"
            ),
            f"aktiv wieder: {len(wieder_aktiv)} (Zeile {zurueck.zeile})\n"
            f"ausgeschieden wieder: {len(datei.lade_ausgeschiedene())} "
            f"(Ausgangsstand: {vorher_ausgeschieden})",
        )
    )

    # ------------------------------------------------------------------
    # 5. Datei in Excel geöffnet
    # ------------------------------------------------------------------
    sperrdatei = PRUEFDATEI.parent / f"~${PRUEFDATEI.name}"
    sperrdatei.write_bytes(b"gesperrt")
    vorher = alle_zellen(PRUEFDATEI)
    meldung = ""
    try:
        person = next(p for p in datei.lade_personen() if p.name == "Nina Junker")
        datei.speichere_person(person.schluessel, {"PSNV": "y"})
        geblockt = False
    except DateiGesperrt as fehler:
        geblockt, meldung = True, str(fehler)
    diff, _ = unterschiede(vorher, alle_zellen(PRUEFDATEI))
    halbe_datei = list(PRUEFDATEI.parent.glob(".*.neu"))
    sperrdatei.unlink()
    ergebnisse.append(
        melde(
            6, "Datei in Excel geöffnet – Meldung statt Schreiben",
            geblockt and not diff and not halbe_datei,
            f"Meldung: {meldung}\nÄnderungen an der Datei: {len(diff)}\n"
            f"halb geschriebene Dateien: {len(halbe_datei)}",
        )
    )

    # ------------------------------------------------------------------
    # 6. Zeile verschoben – falsche Person wird nicht überschrieben
    # ------------------------------------------------------------------
    person = next(p for p in datei.lade_personen() if p.name == "Nina Junker")
    falsch = type(person.schluessel)(person.blatt, person.schluessel.zeile, "Jemand Anderes")
    vorher = alle_zellen(PRUEFDATEI)
    try:
        datei.speichere_person(falsch, {"PSNV": "y"})
        erkannt, meldung = False, ""
    except ZeileVeraendert as fehler:
        erkannt, meldung = True, str(fehler)
    diff, _ = unterschiede(vorher, alle_zellen(PRUEFDATEI))
    ergebnisse.append(
        melde(
            7, "Zielzeile enthält eine andere Person – Abbruch statt Überschreiben",
            erkannt and not diff, f"Meldung: {meldung}",
        )
    )

    # ------------------------------------------------------------------
    # 7. Person anlegen
    # ------------------------------------------------------------------
    # Vor der Summenzeile ist keine freie Zeile mehr, also wird eine eingefuegt.
    # Der Summen- und Notizblock darunter rutscht dabei zwangslaeufig eine Zeile
    # nach unten - geprueft wird deshalb, dass keine PERSON sich veraendert und
    # dass der Block vollstaendig erhalten bleibt.
    vorher_personen = {p.name: dict(p.werte) for p in datei.lade_personen()}
    vorher_block = _block_unter_den_personen(PRUEFDATEI)

    schluessel = datei.lege_person_an(
        "Gruppe 1",
        {"Name": "Testperson Eins", "Medizinisch": "RS", "Führerschein": "C1",
         "Geburtsdatum": date(1990, 5, 17)},
    )

    nachher_personen = {p.name: dict(p.werte) for p in datei.lade_personen()}
    veraendert = [
        name for name, werte in vorher_personen.items()
        if name not in nachher_personen
        or any(
            _vergleichbar(werte[s]) != _vergleichbar(nachher_personen[name].get(s))
            for s in werte
        )
    ]
    nachher_block = _block_unter_den_personen(PRUEFDATEI)

    ergebnisse.append(
        melde(
            8, "Person anlegen – keine bestehende Person ändert sich",
            not veraendert
            and len(nachher_personen) == len(vorher_personen) + 1
            and vorher_block == nachher_block,
            f"neue Zeile: {schluessel.blatt} Zeile {schluessel.zeile}\n"
            f"Personen: {len(vorher_personen)} -> {len(nachher_personen)}\n"
            f"veränderte bestehende Personen: {len(veraendert)} {veraendert[:3]}\n"
            f"Summen- und Notizblock unverändert (nur verschoben): "
            f"{vorher_block == nachher_block} {nachher_block}",
        )
    )

    # ------------------------------------------------------------------
    # 8. Zweite Person anlegen (Platz vor der Fehlsumme wird geschaffen)
    # ------------------------------------------------------------------
    vorher_personen = datei.lade_personen()
    zweite = datei.lege_person_an("Gruppe 1", {"Name": "Testperson Zwei"})
    nachher_personen = datei.lade_personen()
    namen = [p.name for p in nachher_personen]
    with zipfile.ZipFile(PRUEFDATEI) as z:
        tabellen = {
            ET.fromstring(z.read(n)).get("displayName"): ET.fromstring(z.read(n)).get("ref")
            for n in z.namelist() if n.startswith("xl/tables/")
        }
    ergebnisse.append(
        melde(
            9, "Zweite Person anlegen – Summenzeile weicht aus, Tabelle wächst mit",
            len(nachher_personen) == len(vorher_personen) + 1
            and "Testperson Eins" in namen and "Testperson Zwei" in namen,
            f"neue Zeile: {zweite.zeile}\nPersonen: {len(nachher_personen)}\n"
            f"Tabellenbereiche: {tabellen}",
        )
    )

    # ------------------------------------------------------------------
    # 9. Datei ist danach immer noch heil
    # ------------------------------------------------------------------
    with zipfile.ZipFile(PRUEFDATEI) as z:
        teile = set(z.namelist())
        kaputt = z.testzip()
    custom_da = sum(1 for t in teile if t.startswith("customXml/"))
    with zipfile.ZipFile(ARBEITSKOPIE) as z:
        custom_original = sum(1 for t in z.namelist() if t.startswith("customXml/"))
    ergebnisse.append(
        melde(
            10, "Datei ist unbeschädigt und die SharePoint-Metadaten sind noch da",
            kaputt is None and custom_da == custom_original,
            f"ZIP-Prüfung: {'in Ordnung' if kaputt is None else kaputt}\n"
            f"customXml-Teile: {custom_da} (Original: {custom_original})\n"
            f"Paketteile gesamt: {len(teile)}",
        )
    )

    # ------------------------------------------------------------------
    # 10. Formular-Rundlauf: anzeigen -> zurücksenden -> nichts ändert sich
    # ------------------------------------------------------------------
    # Der schärfste Test: jeder Wert jeder Person wird so, wie ihn das Formular
    # anzeigt, wieder eingelesen und gespeichert. Dabei darf sich keine einzige
    # Zelle ändern - sonst würde die Anwendung beim bloßen Öffnen und Speichern
    # einer Seite Werte vereinheitlichen.
    from app.logic.werte import roh  # noqa: E402
    from app.routes.helfer import wert_aus_eingabe  # noqa: E402

    vorher = alle_zellen(PRUEFDATEI)
    veraendert: list[str] = []
    for person in datei.lade_personen():
        zurueck = {
            spalte: wert_aus_eingabe(spalte, roh(wert))
            for spalte, wert in person.werte.items()
            if spalte != "Nr"
        }
        saetze = datei.speichere_person(person.schluessel, zurueck)
        for satz in saetze:
            veraendert.append(
                f"{satz.name} / {satz.spalte}: {satz.alter_wert!r} -> {satz.neuer_wert!r}"
            )
    diff, _ = unterschiede(vorher, alle_zellen(PRUEFDATEI))
    ergebnisse.append(
        melde(
            11, "Formular anzeigen und unverändert zurücksenden – nichts ändert sich",
            not veraendert and not diff,
            f"geprüft: alle Personen, jedes Feld\n"
            f"ungewollte Änderungen: {len(veraendert)}\n"
            + "\n".join(veraendert[:8]),
        )
    )

    print("\n" + "=" * 66)
    print(f"ERGEBNIS: {sum(ergebnisse)} von {len(ergebnisse)} Prüfungen bestanden")
    print("=" * 66)
    print(f"Die geänderte Prüfdatei liegt hier: {PRUEFDATEI}")
    return 0 if all(ergebnisse) else 1


if __name__ == "__main__":
    sys.exit(main())
