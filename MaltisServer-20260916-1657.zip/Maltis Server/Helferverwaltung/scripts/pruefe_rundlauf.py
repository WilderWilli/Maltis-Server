"""Round-Trip-Test fuer die fuehrende Excel-Datei.

Laedt die Arbeitskopie mit openpyxl, speichert sie unveraendert wieder ab und
vergleicht Original und Ergebnis - einmal ohne und einmal mit der Reparatur aus
``app/dateizugriff/paket.py``. Geprueft werden:

  * die Bestandteile des XLSX-Pakets (SharePoint-Metadaten, Vertraulichkeits-
    kennzeichen, Druckeinstellungen)
  * alle Zellwerte, Formeln und Zahlenformate
  * die Excel-Tabellen (ListObjects)
  * die bedingten Formatierungen

Dieser Test ist das Tor zu allem Weiteren: solange er nicht sauber ist, darf die
Anwendung nicht in die echte Datei schreiben.

Aufruf:  .venv/bin/python scripts/pruefe_rundlauf.py
"""

from __future__ import annotations

import re
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

import openpyxl

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from app.dateizugriff.paket import (  # noqa: E402
    SELBSTHEILEND,
    stelle_paketteile_wieder_her,
)

QUELLE = BASE_DIR / "data" / "arbeitskopie" / "Personal_Bestandsaufnahme.xlsx"
NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def _spaltennummer(zellbezug: str) -> int:
    n = 0
    for zeichen in re.match(r"([A-Z]+)", zellbezug).group(1):
        n = n * 26 + ord(zeichen) - 64
    return n


def paketteile(pfad: Path) -> set[str]:
    with zipfile.ZipFile(pfad) as z:
        return set(z.namelist())


def zellen(pfad: Path, blattdatei: str) -> dict[tuple[int, int], tuple]:
    """Liest ein Blatt roh aus dem XML: Wert, Formel und Zahlenformat je Zelle.

    Bewusst ohne openpyxl, damit der Vergleich nicht durch dieselbe Bibliothek
    laeuft, die er pruefen soll.
    """
    with zipfile.ZipFile(pfad) as z:
        namen = z.namelist()
        # openpyxl legt Texte inline ab statt in sharedStrings.xml.
        texte = (
            [
                "".join(t.text or "" for t in si.iter(NS + "t"))
                for si in ET.fromstring(z.read("xl/sharedStrings.xml"))
            ]
            if "xl/sharedStrings.xml" in namen
            else []
        )
        stile = ET.fromstring(z.read("xl/styles.xml"))
        eigene_formate = {
            int(nf.get("numFmtId")): nf.get("formatCode") for nf in stile.iter(NS + "numFmt")
        }
        format_je_stil = [int(xf.get("numFmtId", "0")) for xf in stile.find(NS + "cellXfs")]
        blatt = ET.fromstring(z.read(blattdatei))

    ergebnis: dict[tuple[int, int], tuple] = {}
    for zeile in blatt.iter(NS + "row"):
        nr = int(zeile.get("r"))
        for zelle in zeile.iter(NS + "c"):
            typ, stil = zelle.get("t"), zelle.get("s")
            wert_el = zelle.find(NS + "v")
            formel_el = zelle.find(NS + "f")
            inline_el = zelle.find(NS + "is")

            if typ == "s" and wert_el is not None:
                wert = texte[int(wert_el.text)]
            elif typ == "inlineStr" and inline_el is not None:
                wert = "".join(t.text or "" for t in inline_el.iter(NS + "t"))
            elif wert_el is not None:
                wert = wert_el.text
            else:
                wert = None

            formel = formel_el.text if formel_el is not None else None
            format_id = format_je_stil[int(stil)] if stil and int(stil) < len(format_je_stil) else 0
            format_code = eigene_formate.get(format_id, f"builtin-{format_id}")

            if wert is not None or formel is not None:
                ergebnis[(nr, _spaltennummer(zelle.get("r")))] = (wert, formel, format_code)
    return ergebnis


def tabellen(pfad: Path) -> dict[str, str]:
    ergebnis = {}
    with zipfile.ZipFile(pfad) as z:
        for name in z.namelist():
            if name.startswith("xl/tables/"):
                t = ET.fromstring(z.read(name))
                ergebnis[t.get("displayName")] = t.get("ref")
    return ergebnis


def bedingte_formatierungen(pfad: Path, blattdatei: str) -> list[frozenset[str]]:
    """Bedingte Formatierungen als Mengen von Bereichen.

    openpyxl sortiert die Bereiche innerhalb eines ``sqref`` um. Das ist
    bedeutungslos, deshalb wird hier als Menge verglichen, nicht als Text.
    """
    with zipfile.ZipFile(pfad) as z:
        blatt = ET.fromstring(z.read(blattdatei))
    return [
        frozenset((cf.get("sqref") or "").split())
        for cf in blatt.findall(NS + "conditionalFormatting")
    ]


def blattdateien(pfad: Path) -> dict[str, str]:
    """Blattname -> Pfad der Blatt-XML im Paket."""
    with zipfile.ZipFile(pfad) as z:
        mappe = ET.fromstring(z.read("xl/workbook.xml"))
        beziehungen = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        ziel_je_id = {
            r.get("Id"): r.get("Target")
            for r in beziehungen
            if r.get("Type", "").endswith("/worksheet")
        }
        rid = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
        ergebnis = {}
        for blatt in mappe.iter(NS + "sheet"):
            ziel = ziel_je_id[blatt.get(rid)].lstrip("/")
            ergebnis[blatt.get("name")] = ziel if ziel.startswith("xl/") else f"xl/{ziel}"
        return ergebnis


def kennzeichen(pfad: Path) -> int:
    """Anzahl der MSIP-Eigenschaften (Vertraulichkeitskennzeichen)."""
    with zipfile.ZipFile(pfad) as z:
        if "docProps/custom.xml" not in z.namelist():
            return 0
        inhalt = z.read("docProps/custom.xml").decode("utf-8", errors="replace")
    return sum("MSIP" in name for name in re.findall(r'name="([^"]+)"', inhalt))


def vergleiche(vorher: Path, nachher: Path, titel: str) -> list[str]:
    befunde: list[str] = []
    print("=" * 72)
    print(titel)
    print("=" * 72)

    fehlend = sorted(paketteile(vorher) - paketteile(nachher))
    kritisch = [t for t in fehlend if t not in SELBSTHEILEND]
    print(f"  Paketteile: {len(fehlend)} fehlen "
          f"({len(kritisch)} davon kritisch, {len(fehlend) - len(kritisch)} selbstheilend)")
    for teil in kritisch:
        print(f"      KRITISCH: {teil}")
    if kritisch:
        befunde.append(f"{len(kritisch)} Paketteil(e) gehen verloren")

    k_vorher, k_nachher = kennzeichen(vorher), kennzeichen(nachher)
    print(f"  Vertraulichkeitskennzeichen: {k_vorher} vorher, {k_nachher} nachher"
          f" [{'ok' if k_vorher == k_nachher else 'VERLOREN'}]")
    if k_vorher != k_nachher:
        befunde.append("Vertraulichkeitskennzeichen geht verloren")

    blaetter_v, blaetter_n = blattdateien(vorher), blattdateien(nachher)
    if set(blaetter_v) != set(blaetter_n):
        befunde.append(f"Blaetter weichen ab: {set(blaetter_v)} vs. {set(blaetter_n)}")

    for name in blaetter_v:
        if name not in blaetter_n:
            continue
        zv, zn = zellen(vorher, blaetter_v[name]), zellen(nachher, blaetter_n[name])
        echte, zwischenwerte = [], 0
        for schluessel in sorted(set(zv) | set(zn)):
            a, b = zv.get(schluessel), zn.get(schluessel)
            if a == b:
                continue
            # Zwischengespeicherte Formelergebnisse: Excel rechnet sie beim
            # Oeffnen neu, ihr Wegfall ist unbedenklich.
            ist_formel = (a and a[1]) or (b and b[1])
            gleiche_formel = a and b and a[1] == b[1] and a[2] == b[2]
            if ist_formel and (gleiche_formel or (a and b and b[1] and not a[1])):
                zwischenwerte += 1
            else:
                echte.append((schluessel, a, b))
        print(f"  Blatt {name!r}: {len(zv)} Zellen, {len(echte)} echte Abweichung(en), "
              f"{zwischenwerte} Formel-Zwischenergebnis(se) neu zu berechnen")
        for (zeile, spalte), a, b in echte[:10]:
            print(f"      Zeile {zeile}, Spalte {spalte}: {a!r}  ->  {b!r}")
        if echte:
            befunde.append(f"Blatt {name!r}: {len(echte)} Zellabweichung(en)")

    tv, tn = tabellen(vorher), tabellen(nachher)
    abweichend = [n for n in set(tv) | set(tn) if tv.get(n) != tn.get(n)]
    print(f"  Excel-Tabellen: {len(tv)} vorher, {len(tn)} nachher, "
          f"{len(abweichend)} abweichend [{'ok' if not abweichend else 'ABWEICHUNG'}]")
    for name in sorted(abweichend):
        print(f"      {name}: {tv.get(name)} -> {tn.get(name)}")
        befunde.append(f"Tabelle {name}: {tv.get(name)} -> {tn.get(name)}")

    for name in blaetter_v:
        if name not in blaetter_n:
            continue
        bv = bedingte_formatierungen(vorher, blaetter_v[name])
        bn = bedingte_formatierungen(nachher, blaetter_n[name])
        if sorted(map(sorted, bv)) != sorted(map(sorted, bn)):
            print(f"  Bedingte Formatierung {name!r}: {len(bv)} -> {len(bn)} [ABWEICHUNG]")
            befunde.append(f"Blatt {name!r}: bedingte Formatierungen weichen ab")
    print("  Bedingte Formatierungen: alle Bereiche erhalten"
          if not any("bedingte" in b for b in befunde) else "")
    return befunde


def main() -> int:
    if not QUELLE.exists():
        print(f"FEHLER: Arbeitskopie fehlt: {QUELLE}")
        return 2

    with tempfile.TemporaryDirectory() as tmp:
        vorher = Path(tmp) / "vorher.xlsx"
        roh = Path(tmp) / "roh.xlsx"
        repariert = Path(tmp) / "repariert.xlsx"
        shutil.copy2(QUELLE, vorher)

        openpyxl.load_workbook(vorher).save(roh)
        shutil.copy2(roh, repariert)
        zurueckgeholt = stelle_paketteile_wieder_her(vorher, repariert)

        vergleiche(vorher, roh, "A. openpyxl ohne Reparatur")
        print()
        print(f"  Wiederhergestellt: {len(zurueckgeholt)} Teil(e)")
        for teil in zurueckgeholt:
            print(f"      {teil}")
        print()
        befunde = vergleiche(vorher, repariert, "B. openpyxl mit Reparatur")

        print()
        print("=" * 72)
        print("ERGEBNIS")
        print("=" * 72)
        if not befunde:
            print("  Sauber. Die Datei kommt mit Reparatur unveraendert zurueck.")
            print("  Nicht identisch, aber unbedenklich: Formel-Zwischenergebnisse")
            print("  (Excel rechnet neu) und die Reihenfolge der Bereiche in")
            print("  bedingten Formatierungen.")
            return 0
        for befund in befunde:
            print(f"  - {befund}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
