#!/usr/bin/env bash
# Legt eine Startdatei zum Doppelklicken an - auf dem Schreibtisch und im
# Anwendungsmenue. Muss nur einmal ausgefuehrt werden.
#
# Aufruf im Terminal:   ./schreibtisch_verknuepfung_anlegen.sh
set -e
ORDNER="$(cd "$(dirname "$0")" && pwd)"

chmod +x "$ORDNER/start.sh" "$ORDNER/starten_im_terminal.sh"

# Wo liegt der Schreibtisch? Je nach Spracheinstellung anders benannt.
SCHREIBTISCH="$(xdg-user-dir DESKTOP 2>/dev/null || true)"
if [ -z "$SCHREIBTISCH" ] || [ ! -d "$SCHREIBTISCH" ]; then
  for kandidat in "$HOME/Schreibtisch" "$HOME/Desktop"; do
    [ -d "$kandidat" ] && SCHREIBTISCH="$kandidat" && break
  done
fi

ANWENDUNGEN="$HOME/.local/share/applications"
mkdir -p "$ANWENDUNGEN"

erzeuge_verknuepfung() {
  cat > "$1" <<EOF
[Desktop Entry]
Type=Application
Version=1.0
Name=Helferverwaltung
GenericName=Helferverwaltung der Ortsgruppe
Comment=Bedienoberfläche für die Helferliste der Ortsgruppe
Exec="$ORDNER/starten_im_terminal.sh"
Path=$ORDNER
Icon=$ORDNER/app/static/icon.svg
Terminal=false
Categories=Office;Database;
Keywords=Helfer;Malteser;Ortsgruppe;AMU;Fortbildung;
StartupNotify=true
EOF
  chmod +x "$1"
}

erzeuge_verknuepfung "$ANWENDUNGEN/helferverwaltung.desktop"
echo "Im Anwendungsmenü angelegt."

if [ -n "$SCHREIBTISCH" ] && [ -d "$SCHREIBTISCH" ]; then
  erzeuge_verknuepfung "$SCHREIBTISCH/Helferverwaltung.desktop"
  # COSMIC und GNOME wollen die Datei ausdruecklich als vertrauenswuerdig markiert
  gio set "$SCHREIBTISCH/Helferverwaltung.desktop" metadata::trusted true 2>/dev/null || true
  echo "Auf dem Schreibtisch angelegt: $SCHREIBTISCH/Helferverwaltung.desktop"
else
  echo "Kein Schreibtisch-Ordner gefunden - die Verknüpfung steht nur im Anwendungsmenü."
fi

update-desktop-database "$ANWENDUNGEN" 2>/dev/null || true

echo ""
echo "Fertig. Die Helferverwaltung lässt sich jetzt starten über:"
echo "  * das Anwendungsmenü (nach \"Helferverwaltung\" suchen)"
echo "  * einen Doppelklick auf das Symbol auf dem Schreibtisch"
echo ""
echo "Beim ersten Doppelklick fragt der Schreibtisch unter Umständen noch einmal"
echo "nach, ob die Datei ausgeführt werden darf - das bitte bestätigen."
