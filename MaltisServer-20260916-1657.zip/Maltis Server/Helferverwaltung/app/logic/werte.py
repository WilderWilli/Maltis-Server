"""Dreiwertige Auswertung der Zellinhalte.

Der wichtigste Grundsatz der ganzen Anwendung steht hier: **leer bedeutet
unbekannt, nicht "nein"**. Es gibt bewusst keinen Weg, auf dem aus einer leeren
Zelle ein NEIN wird. Alles, was nicht sicher erkannt wird, ist UNBEKANNT und
landet in der Liste "Angabe fehlt, bitte prüfen".

Die erkannten Werte stammen aus der tatsaechlichen Datei, nicht aus einer
Annahme darueber, was dort stehen koennte.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime
from enum import Enum


class Zustand(str, Enum):
    JA = "ja"
    NEIN = "nein"
    UNBEKANNT = "unbekannt"

    @property
    def beschriftung(self) -> str:
        return {"ja": "ja", "nein": "nein", "unbekannt": "keine Angabe"}[self.value]


@dataclass(frozen=True)
class Feldzustand:
    """Auswertung plus Rohwert - der Rohwert wird nie verschwiegen."""

    zustand: Zustand
    rohwert: str

    @property
    def ist_ja(self) -> bool:
        return self.zustand is Zustand.JA

    @property
    def ist_nein(self) -> bool:
        return self.zustand is Zustand.NEIN

    @property
    def ist_unbekannt(self) -> bool:
        return self.zustand is Zustand.UNBEKANNT


# Woerter, die eine Angabe zu einer Vermutung machen. Kommen so in der Datei vor:
# "Wohl mind. C1", "C?", "B (Einsichtsnahme) --> C1".
UNSICHERHEIT = ("?", "-->", "->", "wohl", "mind", "evtl", "vermutl", "ca.", "unklar")

# Fuehrerscheinklassen, die ein C enthalten.
C_KLASSEN = frozenset({"C", "C1", "CE", "C1E"})
# Klassen ohne C - wer nur diese hat, hat nachweislich kein C.
KLASSEN_OHNE_C = frozenset({"B", "BE", "B196", "B197", "A", "A1", "A2", "AM", "L", "T"})
# Ausdrueckliche Verneinung in einem Textfeld.
KEIN_EINTRAG = frozenset({"--", "-", "keine", "kein", "nein", "n"})

_DATUM = re.compile(r"(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{2,4})")


def roh(wert) -> str:
    """Zellinhalt als Text fuer die Anzeige - unveraendert bis auf Randleerzeichen."""
    if wert is None:
        return ""
    if isinstance(wert, datetime):
        return wert.date().strftime("%d.%m.%Y")
    if isinstance(wert, date):
        return wert.strftime("%d.%m.%Y")
    if isinstance(wert, float) and wert.is_integer():
        return str(int(wert))
    return str(wert).strip()


def ist_leer(wert) -> bool:
    return roh(wert) == ""


def datum_aus(wert) -> date | None:
    """Liest ein Datum, auch wenn Text daneben steht.

    "30.11.2027 (bg)" und "(30.10.2023)" werden erkannt; "n" und Freitext ohne
    Datum ergeben None. Der Zellinhalt selbst wird dabei nie veraendert.
    """
    if isinstance(wert, datetime):
        return wert.date()
    if isinstance(wert, date):
        return wert
    treffer = _DATUM.search(roh(wert))
    if not treffer:
        return None
    tag, monat, jahr = (int(teil) for teil in treffer.groups())
    if jahr < 100:
        jahr += 2000
    try:
        return date(jahr, monat, tag)
    except ValueError:
        return None  # z.B. "23.20.25" - kein gueltiges Datum


def ja_nein(wert) -> Feldzustand:
    """Auswertung einer y/n-Spalte.

    Ein eingetragenes Datum gilt als JA: in den Fortbildungsspalten dokumentiert
    es, wann die Fortbildung stattgefunden hat. Alles andere ausser "y" und "n"
    (etwa "HA", "angemeldet", "(y)") ist UNBEKANNT - es ist weder ein Ja noch ein
    Nein, und die Anwendung tut nicht so, als waere es eines.
    """
    text = roh(wert)
    if not text:
        return Feldzustand(Zustand.UNBEKANNT, "")
    klein = text.lower()
    if klein == "y":
        return Feldzustand(Zustand.JA, text)
    if klein == "n":
        return Feldzustand(Zustand.NEIN, text)
    # Ein Datum zaehlt als Ja - egal ob es als Datumswert oder als Text in der
    # Zelle steht.
    if datum_aus(wert) is not None:
        return Feldzustand(Zustand.JA, text)
    return Feldzustand(Zustand.UNBEKANNT, text)


def hat_fuehrerschein_klasse_c(wert) -> Feldzustand:
    """Hat die Person eine Fuehrerscheinklasse mit C (C, C1, CE)?

    Vorkommende Werte: CE, C, C1, B, "B (Einsichtsnahme)",
    "B (Einsichtsnahme) --> C1", "--", "?", "Wohl mind. C1", "C?", leer.
    """
    text = roh(wert)
    if not text:
        return Feldzustand(Zustand.UNBEKANNT, "")
    klein = text.lower()
    if any(marke in klein for marke in UNSICHERHEIT):
        return Feldzustand(Zustand.UNBEKANNT, text)

    teile = {t.strip().upper() for t in re.split(r"[,/;()\s]+", text) if t.strip()}
    if teile & C_KLASSEN:
        return Feldzustand(Zustand.JA, text)
    if klein in KEIN_EINTRAG or teile & KLASSEN_OHNE_C:
        return Feldzustand(Zustand.NEIN, text)
    return Feldzustand(Zustand.UNBEKANNT, text)


def hat_fuehrerschein(wert) -> Feldzustand:
    """Hat die Person ueberhaupt einen Fuehrerschein - egal welcher Klasse?

    Anders als hat_fuehrerschein_klasse_c geht es hier nur darum, ob jemand
    faehrt. "--" heisst nachweislich keiner, "?" und leer heissen unbekannt,
    alles andere (auch "Wohl mind. C1") heisst: es ist einer eingetragen.
    """
    text = roh(wert)
    if not text:
        return Feldzustand(Zustand.UNBEKANNT, "")
    klein = text.strip().lower()
    if klein in KEIN_EINTRAG:
        return Feldzustand(Zustand.NEIN, text)
    if klein in ("?", "??", "unklar"):
        return Feldzustand(Zustand.UNBEKANNT, text)
    return Feldzustand(Zustand.JA, text)


def hat_qualifikation_rs(wert) -> Feldzustand:
    """Hat die Person die Qualifikation RS (Rettungssanitäter)?

    Massgeblich ist das Token "RS" - "RS, NFS Azubi" und "RS / Krankenschwester"
    zaehlen, "NotSan", "Esan" und "ESiP" nicht.
    """
    text = roh(wert)
    if not text:
        return Feldzustand(Zustand.UNBEKANNT, "")
    teile = {t.strip().upper() for t in re.split(r"[,/;]+", text) if t.strip()}
    if "RS" in teile:
        return Feldzustand(Zustand.JA, text)
    return Feldzustand(Zustand.NEIN, text)


def enthaelt(wert, gesucht: str) -> Feldzustand:
    """Enthaelt das Feld den gesuchten Teilstring? Leer bleibt UNBEKANNT."""
    text = roh(wert)
    if not text:
        return Feldzustand(Zustand.UNBEKANNT, "")
    if any(marke in text.lower() for marke in UNSICHERHEIT):
        return Feldzustand(Zustand.UNBEKANNT, text)
    treffer = gesucht.strip().lower() in text.lower()
    return Feldzustand(Zustand.JA if treffer else Zustand.NEIN, text)


def ist_gleich(wert, erwartet: str) -> Feldzustand:
    """Stimmt das Feld mit dem erwarteten Wert ueberein? Leer bleibt UNBEKANNT."""
    text = roh(wert)
    if not text:
        return Feldzustand(Zustand.UNBEKANNT, "")
    treffer = text.strip().lower() == erwartet.strip().lower()
    return Feldzustand(Zustand.JA if treffer else Zustand.NEIN, text)


def ist_gefuellt(wert) -> Feldzustand:
    """Steht ueberhaupt etwas in der Zelle?

    Das ist die einzige Auswertung, bei der "leer" eine Aussage ist - naemlich
    genau die, nach der gefragt wurde.
    """
    text = roh(wert)
    return Feldzustand(Zustand.JA if text else Zustand.NEIN, text)
