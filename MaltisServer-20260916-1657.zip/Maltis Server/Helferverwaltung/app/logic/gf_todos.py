"""Gruppenführer-Übersicht: Helfer je GF und ihre offenen Aufgaben.

Die Zuordnung zum Gruppenführer steht in der Excel-Spalte GF (``Niklas`` |
``Nino``). Dieses Modul baut daraus eine Aufgabenliste je Gruppenführer:

  * Jahrespflichten, die für das laufende Jahr fällig sind (RS-Fortbildung,
    Jahresgespräch, Unterweisung S/W-Rechte),
  * arbeitsmedizinische Untersuchungen, die abgelaufen, bald fällig oder
    fehlend sind,
  * fehlende Kleidergrößen (Dienstkleidung bzw. CBRN-Schutzausrüstung).

Wer noch keinen der beiden Gruppenführer eingetragen hat, wird als „ohne
Zuordnung“ separat geführt, damit sichtbar ist, dass die Verteilung noch offen
ist. Dieselbe Logik steckt hinter der GF-Auswahl in der Personalübersicht.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

from app.dateizugriff.schema import (
    GF_WERTE,
    SPALTE_CBRN_GROESSE,
    SPALTE_DIENSTKLEIDUNG_GROESSE,
    SPALTE_GF,
    AmuEintrag,
    Person,
)
from app.logic.amu import AmuBefund, AmuLage
from app.logic.jahrespflicht import Jahresbefund, Jahreslage
from app.logic.uebersicht import baue_befund
from app.logic.werte import ist_leer, roh

# Untersuchungen, die in der GF-Aufgabenliste stehen - alles, was nicht einfach
# "gültig" oder "erledigt" ist.
AMU_AUFFAELLIG = (
    AmuLage.ABGELAUFEN,
    AmuLage.LAEUFT_AB,
    AmuLage.FEHLT,
)


@dataclass
class GfPerson:
    """Eine Person in der GF-Übersicht mit den offenen Punkten für sie."""

    person: Person
    # Der unveränderte Wert aus der Spalte GF - leere und unbekannte Werte
    # landen in "ohne Zuordnung".
    gf_roh: str
    jahrespflichten: tuple[Jahresbefund, ...] = ()
    amu: tuple[AmuBefund, ...] = ()
    dienstkleidung_groesse_fehlt: bool = False
    cbrn_groesse_fehlt: bool = False

    @property
    def groessen_fehlen(self) -> int:
        return int(self.dienstkleidung_groesse_fehlt) + int(self.cbrn_groesse_fehlt)

    @property
    def hat_abgelaufene_amu(self) -> bool:
        """Für die Darstellung: wenigstens eine Untersuchung ist abgelaufen."""
        return any(a.lage is AmuLage.ABGELAUFEN for a in self.amu)

    @property
    def anzahl_offene_punkte(self) -> int:
        """Ein Punkt je offener Jahrespflicht, Untersuchung oder fehlender Größe."""
        return len(self.jahrespflichten) + len(self.amu) + self.groessen_fehlen

    @property
    def dringlichkeit(self) -> tuple:
        """Sortierschluessel: wer mehr offene Punkte hat, steht weiter oben."""
        return (-self.anzahl_offene_punkte, self.person.name.lower())


@dataclass
class GfGruppe:
    """Eine Gruppe in der GF-Übersicht - ein Gruppenführer oder "ohne"."""

    # None steht für "ohne Zuordnung".
    gf: str | None
    personen: list[GfPerson] = field(default_factory=list)

    @property
    def name(self) -> str:
        return self.gf or "Ohne Zuordnung"

    @property
    def ist_ohne_zordnung(self) -> bool:
        return self.gf is None

    @property
    def anzahl_personen(self) -> int:
        return len(self.personen)

    @property
    def anzahl_jahrespflichten(self) -> int:
        return sum(len(p.jahrespflichten) for p in self.personen)

    @property
    def anzahl_amu(self) -> int:
        return sum(len(p.amu) for p in self.personen)

    @property
    def anzahl_groessen(self) -> int:
        return sum(p.groessen_fehlen for p in self.personen)

    @property
    def anzahl_offene_punkte(self) -> int:
        return sum(p.anzahl_offene_punkte for p in self.personen)

    @property
    def alles_erledigt(self) -> bool:
        return self.anzahl_offene_punkte == 0

    @property
    def personen_mit_aufgaben(self) -> list[GfPerson]:
        return [p for p in self.personen if p.anzahl_offene_punkte]


def baue_gf_uebersicht(
    personen: list[Person], amu_katalog: dict[str, AmuEintrag], heute: date | None = None
) -> list[GfGruppe]:
    """Teilt die Personen nach GF auf und berechnet je Person die offenen Punkte.

    Die Reihenfolge der Gruppen folgt GF_WERTE (Niklas, Nino), danach kommt
    „ohne Zuordnung“. Innerhalb einer Gruppe stehen die Personen mit den meisten
    offenen Punkten zuerst.
    """
    gruppen: dict[str | None, GfGruppe] = {}
    for gf in GF_WERTE:
        gruppen.setdefault(gf, GfGruppe(gf=gf))

    for person in personen:
        befund = baue_befund(person, amu_katalog, heute)
        gf_roh = roh(person.wert(SPALTE_GF))
        gf = gf_roh if gf_roh in GF_WERTE else None
        gruppen.setdefault(gf, GfGruppe(gf=gf))
        gruppen[gf].personen.append(
            GfPerson(
                person=person,
                gf_roh=gf_roh,
                jahrespflichten=tuple(
                    j for j in befund.jahrespflichten if j.lage is Jahreslage.FAELLIG
                ),
                amu=tuple(a for a in befund.amu if a.lage in AMU_AUFFAELLIG),
                dienstkleidung_groesse_fehlt=ist_leer(
                    person.wert(SPALTE_DIENSTKLEIDUNG_GROESSE)
                ),
                cbrn_groesse_fehlt=ist_leer(person.wert(SPALTE_CBRN_GROESSE)),
            )
        )

    for gruppe in gruppen.values():
        gruppe.personen.sort(key=lambda p: p.dringlichkeit)

    reihenfolge = {gf: i for i, gf in enumerate(GF_WERTE)}
    return sorted(
        gruppen.values(),
        key=lambda g: (reihenfolge.get(g.gf, len(reihenfolge)), g.gf or ""),
    )