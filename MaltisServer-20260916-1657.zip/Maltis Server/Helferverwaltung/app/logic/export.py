"""Export für die PSA-Beauftragte.

Erzeugt Zeilen im Format von ``Übersichtsliste_Helfer.xlsx`` - dieselben 40
Spaltenüberschriften in derselben Reihenfolge. Die Vorlage selbst wird dabei
weder gelesen noch verändert; die Überschriften stehen hier zeichengenau als
Konstante (einmalig aus der Vorlage übernommen, einschließlich ihrer Tippfehler
und doppelten Leerzeichen).

Gefüllt werden nur die Spalten, für die es in der führenden Datei eine
Entsprechung gibt. Wo die Vorlage ein Datum erwartet, die führende Datei aber
nur ``y``/``n`` kennt (MGA-Module, Prävention, Funk, AV15, Masern), bleibt die
Zelle **leer** - dort wird nie ein Buchstabe eingetragen.

Dieses Modul kennt kein openpyxl; das Schreiben übernimmt das Zugriffsmodul.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from app.dateizugriff.schema import Person, Zellwert
from app.logic.werte import datum_aus

# Zeichengenau aus der Vorlage übernommen - Reihenfolge und Schreibweise dürfen
# sich nicht ändern, sonst passt der Export nicht mehr in ihre Liste.
EXPORT_UEBERSCHRIFTEN: tuple[str, ...] = (
    "Nachname",
    "Vorname",
    "Geburtsdatum",
    "Zugzuteilung",
    "Selbst- verpflicht- ungs- erklärung Prävo",
    "Datengeheimnis Verpflichtung Schweigepflicht",
    "Verpflichtung BOS Funk",
    "Einwilligung Foto Film Audio",
    "Einwilligung Aufnahme und Nutzung Fotos oder Filmaufnahmen Printmedien",
    "Einwilligung Aufnahme und Nutzung Fotos oder Filmaufnahmen Social Media",
    "Einwilligung Aufnahme und Nutzung Fotos oder Filmaufnahmen Malteser Webseiten",
    "Vereinbarung EA Mitarbeit",
    "Dienstausweis gültig bis",
    "Mitgliedsantrag",
    "AU med Tätigk G42 G 24 ggf G26.1  gültig bis",
    "AU fahrend Tätigkeit G25 gültig bis",
    "AU pflegende Ttigkeit G42 G24  gültig bis",
    "AU verwaltende Tätigkeit G37   gültig bis",
    "AU betreuende Tätigkeit gültig bis",
    "AU frei von ansteckenden Krankheiten am",
    "AU Tragen v Atemschutz G26.2 gültig bis",
    "AU Fahrerlaubnisuntersuchung C1 CE C am",
    "AU Fahrerlaubnisuntersuchung D1 DE D am",
    "Einsicht Masernimpfung",
    "Einsicht Fahrerlaubnis",
    "Einsicht P Schein",
    "Rettungsdienst Personal",
    "Datum EFZ",
    "Helfergrundausbildung (AV10) (ALT)",
    "Malteser Grundausbildung Modul 1",
    "Malteser Grundausbildung Modul 2",
    "Malteser Grundausbildung Modul 3",
    "Malteser Grundausbildung Modul 4",
    "Höchste Prävention (UE) - Datum",
    "Letzte Prävention (UE) - Datum",
    "Datum letzte Prävention",
    "AV15",
    "Funk A",
    "Funk B",
    "Funk C",
)

# Welche Exportspalte woher kommt. Alles, was hier fehlt, bleibt leer.
ZUORDNUNG: dict[str, str] = {
    "AU fahrend Tätigkeit G25 gültig bis": "G25",
    "AU verwaltende Tätigkeit G37   gültig bis": "G 37",
    "AU frei von ansteckenden Krankheiten am": "BOKraft",
    "AU Tragen v Atemschutz G26.2 gültig bis": "G 26.2",
    "AU Fahrerlaubnisuntersuchung C1 CE C am": "FeV 5/FeV 6",
}

# Spalten, in denen die Vorlage das früheste mehrerer Ablaufdaten führt.
FRUEHESTES: dict[str, tuple[str, ...]] = {
    "AU med Tätigk G42 G 24 ggf G26.1  gültig bis": ("G 42", "G24", "G 26.1"),
    "AU pflegende Ttigkeit G42 G24  gültig bis": ("G 42", "G24"),
}

ZUGZUTEILUNGEN: tuple[str, ...] = ("Behandlung", "Sanität", "Transport", "Neuhelfer")

# Die Ortsgruppe gehoert geschlossen zur Behandlungsgruppe; neue Personen
# bekommen das voreingestellt und koennen einzeln umgestellt werden.
STANDARD_ZUGZUTEILUNG = "Behandlung"


@dataclass
class Zusatzangaben:
    """Was die Anwendung zusätzlich zur Excel-Datei über eine Person weiß."""

    vorname: str = ""
    nachname: str = ""
    zugzuteilung: str = ""


def _fruehestes_datum(person: Person, spalten: tuple[str, ...]) -> date | None:
    daten = [
        datum_aus(person.wert(spalte))
        for spalte in spalten
        if spalte in person.werte
    ]
    vorhanden = [d for d in daten if d is not None]
    return min(vorhanden) if vorhanden else None


def zeile_fuer(person: Person, zusatz: Zusatzangaben) -> list[Zellwert]:
    """Baut eine Exportzeile - leere Felder bleiben leer."""
    werte: dict[str, Zellwert] = {
        "Nachname": zusatz.nachname or None,
        "Vorname": zusatz.vorname or None,
        "Geburtsdatum": datum_aus(person.wert("Geburtsdatum")),
        "Zugzuteilung": zusatz.zugzuteilung or None,
    }

    for ziel, quelle in ZUORDNUNG.items():
        werte[ziel] = datum_aus(person.wert(quelle)) if quelle in person.werte else None

    for ziel, quellen in FRUEHESTES.items():
        werte[ziel] = _fruehestes_datum(person, quellen)

    return [werte.get(ueberschrift) for ueberschrift in EXPORT_UEBERSCHRIFTEN]


def baue_zeilen(
    personen: list[Person], zusatz_je_person: dict[tuple[str, str], Zusatzangaben]
) -> list[list[Zellwert]]:
    """Alle Exportzeilen, alphabetisch nach Nachname und Vorname."""
    zeilen = []
    for person in personen:
        zusatz = zusatz_je_person.get(
            (person.blatt, person.name), Zusatzangaben()
        )
        zeilen.append((zusatz.nachname.lower(), zusatz.vorname.lower(),
                       zeile_fuer(person, zusatz)))
    zeilen.sort(key=lambda eintrag: (eintrag[0], eintrag[1]))
    return [zeile for _, _, zeile in zeilen]
