"""Jährlich fällige Nachweise.

Drei Dinge müssen jedes Jahr erneut gemacht werden und führen deshalb ein
**Datum** statt eines Häkchens:

  * RS-Fortbildung                      - nur für Personen mit Qualifikation RS
  * Jahresgespräch                      - für alle
  * Unterweisung Sonder- und Wegerechte - nur für Personen mit Führerschein

Die Regel ist überall dieselbe: steht in der Spalte ein Datum aus dem laufenden
Jahr, ist die Sache erledigt. Steht dort ein älteres Datum, ein ``n`` oder
nichts, ist sie fällig. Steht dort anderer Text (``y``, ``HA``, ``angemeldet``),
fehlt das Datum für das aktuelle Jahr - die Pflicht ist als "ausstehend"
markiert, statt ein Datum zu erfinden.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import Enum

from app.dateizugriff.schema import (
    SPALTE_JAHRESGESPRAECH,
    SPALTE_RS_FORTBILDUNG,
    SPALTE_UNTERWEISUNG_SW,
    Person,
)
from app.logic.werte import (
    Zustand,
    datum_aus,
    hat_fuehrerschein,
    hat_qualifikation_rs,
    roh,
)

SPALTE_MEDIZINISCH = "Medizinisch"
SPALTE_FUEHRERSCHEIN = "Führerschein"


class Jahreslage(str, Enum):
    ERLEDIGT = "erledigt"
    FAELLIG = "faellig"
    UNKLAR = "unklar"
    NICHT_NOETIG = "nicht_noetig"

    @property
    def beschriftung(self) -> str:
        return {
            "erledigt": "erledigt",
            "faellig": "steht an",
            "unklar": "Angabe fehlt",
            "nicht_noetig": "nicht erforderlich",
        }[self.value]

    @property
    def marke(self) -> str:
        """CSS-Klasse der Zustandsmarke."""
        return {
            "erledigt": "gueltig",
            "faellig": "abgelaufen",
            "unklar": "unklar",
            "nicht_noetig": "nicht_noetig",
        }[self.value]


@dataclass(frozen=True)
class Pflicht:
    spalte: str
    bezeichnung: str
    # Wen betrifft sie? Gibt JA / NEIN / UNBEKANNT zurueck.
    zielgruppe: str  # "alle" | "rs" | "fuehrerschein"

    def trifft_zu(self, person: Person) -> Zustand:
        if self.zielgruppe == "rs":
            return hat_qualifikation_rs(person.wert(SPALTE_MEDIZINISCH)).zustand
        if self.zielgruppe == "fuehrerschein":
            return hat_fuehrerschein(person.wert(SPALTE_FUEHRERSCHEIN)).zustand
        return Zustand.JA

    @property
    def zielgruppe_text(self) -> str:
        return {
            "alle": "alle",
            "rs": "Personen mit Qualifikation RS",
            "fuehrerschein": "Personen mit Führerschein",
        }[self.zielgruppe]


PFLICHTEN: tuple[Pflicht, ...] = (
    Pflicht(SPALTE_RS_FORTBILDUNG, "RS-Fortbildung", "rs"),
    Pflicht(SPALTE_JAHRESGESPRAECH, "Jahresgespräch", "alle"),
    Pflicht(SPALTE_UNTERWEISUNG_SW, "Unterweisung Sonder- und Wegerechte", "fuehrerschein"),
)


@dataclass
class Jahresbefund:
    pflicht: Pflicht
    lage: Jahreslage
    jahr: int
    letzte: date | None
    rohwert: str
    hinweis: str = ""
    # True, wenn in der Spalte ein Datum steht (auch ein frueheres Jahr).
    hat_datum: bool = False

    @property
    def bezeichnung(self) -> str:
        return self.pflicht.bezeichnung

    @property
    def steht_an(self) -> bool:
        return self.lage is Jahreslage.FAELLIG

    @property
    def ausstehend(self) -> bool:
        """Fällig, aber es ist noch gar kein Datum eingetragen."""
        return self.lage is Jahreslage.FAELLIG and not self.hat_datum


def beurteile(pflicht: Pflicht, person: Person, heute: date | None = None) -> Jahresbefund:
    heute = heute or date.today()
    jahr = heute.year
    wert = person.wert(pflicht.spalte)
    rohwert = roh(wert)

    betrifft = pflicht.trifft_zu(person)
    if betrifft is Zustand.NEIN:
        return Jahresbefund(pflicht, Jahreslage.NICHT_NOETIG, jahr, None, rohwert)
    if betrifft is Zustand.UNBEKANNT:
        return Jahresbefund(
            pflicht, Jahreslage.UNKLAR, jahr, None, rohwert,
            f"Ob nötig, lässt sich nicht sagen – die Angabe für "
            f"„{pflicht.zielgruppe_text}“ fehlt.",
        )

    # Kein Text wie "paket", sondern ein vollstaendiges Datum - das wird erst
    # aufgeloest, wenn es gueltig ist.
    if isinstance(wert, date):
        if wert.year >= jahr:
            return Jahresbefund(pflicht, Jahreslage.ERLEDIGT, jahr, wert, rohwert,
                                hat_datum=True)
        return Jahresbefund(
            pflicht, Jahreslage.FAELLIG, jahr, wert, rohwert,
            f"Zuletzt am {wert.strftime('%d.%m.%Y')} – für {jahr} steht sie an.",
            hat_datum=True,
        )

    letzte = datum_aus(wert)
    if letzte is not None:
        if letzte.year >= jahr:
            return Jahresbefund(pflicht, Jahreslage.ERLEDIGT, jahr, letzte, rohwert,
                                hat_datum=True)
        return Jahresbefund(
            pflicht, Jahreslage.FAELLIG, jahr, letzte, rohwert,
            f"Zuletzt am {letzte.strftime('%d.%m.%Y')} – für {jahr} steht sie an.",
            hat_datum=True,
        )

    if not rohwert or rohwert.strip().lower() == "n":
        return Jahresbefund(
            pflicht, Jahreslage.FAELLIG, jahr, None, rohwert,
            f"Kein Datum eingetragen – für {jahr} steht sie aus.",
        )

    # Freitext wie "y", "HA", "angemeldet" statt eines Datums: ein Datum fuer das
    # laufende Jahr fehlt, also ist die Pflicht ausstehend - nicht "Angabe fehlt",
    # denn die Pflicht selbst ist bekannt.
    return Jahresbefund(
        pflicht, Jahreslage.FAELLIG, jahr, None, rohwert,
        f"In der Spalte steht „{rohwert}“ statt eines Datums – "
        f"für {jahr} steht sie aus.",
    )


def befunde_fuer(person: Person, heute: date | None = None) -> list[Jahresbefund]:
    return [
        beurteile(pflicht, person, heute)
        for pflicht in PFLICHTEN
        if pflicht.spalte in person.werte
    ]
