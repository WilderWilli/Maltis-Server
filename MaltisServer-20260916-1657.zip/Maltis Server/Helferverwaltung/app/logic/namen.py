"""Aufteilung des Feldes "Name" in Vorname und Nachname.

Die fuehrende Datei kennt nur ein Namensfeld, die Exportvorlage der
PSA-Beauftragten will Nachname und Vorname getrennt. Die Trennung ist nicht
immer eindeutig ("Nino v. Stritzky", "Sebastian v. d. Beeck", "Afou Abdul
Rahim"), deshalb wird sie einmalig automatisch vorgeschlagen und danach zur
Kontrolle vorgelegt - geraten wird nichts endgueltig.
"""

from __future__ import annotations

from dataclasses import dataclass

# Namenspartikel, die zum Nachnamen gehoeren.
PARTIKEL = frozenset({
    "v.", "von", "van", "vom", "de", "del", "della", "der", "den", "dos", "das",
    "da", "di", "du", "le", "la", "zu", "zum", "zur", "d.", "y", "af", "av",
})


@dataclass
class Namensvorschlag:
    name: str
    vorname: str
    nachname: str
    unsicher: bool
    grund: str = ""


def trenne(name: str) -> Namensvorschlag:
    """Schlaegt eine Aufteilung vor und sagt dazu, wie sicher sie ist."""
    bereinigt = " ".join((name or "").split())
    if not bereinigt:
        return Namensvorschlag("", "", "", True, "Kein Name hinterlegt.")

    teile = bereinigt.split(" ")
    if len(teile) == 1:
        return Namensvorschlag(
            bereinigt, "", teile[0], True,
            "Nur ein Namensteil – Vorname oder Nachname ist unklar.",
        )

    # Der Nachname ist das letzte Wort, erweitert um davorstehende Partikel.
    beginn = len(teile) - 1
    while beginn > 1 and teile[beginn - 1].lower() in PARTIKEL:
        beginn -= 1

    nachname = " ".join(teile[beginn:])
    vorname = " ".join(teile[:beginn])

    grund = ""
    if beginn < len(teile) - 1:
        grund = "Namenspartikel erkannt – bitte prüfen."
    elif len(teile) > 2:
        grund = "Mehr als zwei Namensteile – bitte prüfen."

    return Namensvorschlag(bereinigt, vorname, nachname, bool(grund), grund)


def trenne_alle(namen: list[str]) -> list[Namensvorschlag]:
    return [trenne(name) for name in namen]
