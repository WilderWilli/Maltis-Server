"""Arbeitsmedizinische Untersuchungen: Fristen und fehlende Untersuchungen.

Zwei Fragen werden hier beantwortet:

1. Laeuft eine eingetragene Untersuchung bald ab oder ist sie abgelaufen?
   Massgeblich ist allein das eingetragene Datum. Der ``Turnus`` aus Zeile 4 des
   AMU-Blattes wird bewusst nicht ausgewertet - er ist Freitext ("1 / 3 J",
   "einmalig, dann Wunschuntersuchung").

2. Fehlt eine Untersuchung, die die Person nach ihrer Zielgruppe braucht?
   Hier greift die Dreiwertigkeit: ist die Zielgruppen-Voraussetzung unbekannt,
   wird nichts angemahnt, sondern in "Angabe fehlt, bitte prüfen" gesammelt.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import Enum

from app.config import VORWARNUNG_MONATE
from app.dateizugriff.schema import AMU_SPALTEN, AmuEintrag, Person
from app.logic.werte import (
    Zustand,
    datum_aus,
    hat_fuehrerschein_klasse_c,
    hat_qualifikation_rs,
    roh,
)

SPALTE_FUEHRERSCHEIN = "Führerschein"
SPALTE_MEDIZINISCH = "Medizinisch"

# Zielgruppen, wie sie in Zeile 3 des AMU-Blattes stehen.
ZIELGRUPPE_ALLE = "alle"
ZIELGRUPPE_KF_C = "kf c"
ZIELGRUPPE_RS = "rs"
# "neue KF C / Verlängerung" - wer neu ist oder eine Verlaengerung braucht, geht
# aus den Daten nicht hervor. Deshalb wird hier nie "fehlt" gemeldet, sondern
# immer nur zur Pruefung vorgelegt (Entscheidung E4).
ZIELGRUPPE_FEV = "neue kf c / verlängerung"


class AmuLage(str, Enum):
    GUELTIG = "gueltig"
    LAEUFT_AB = "laeuft_ab"
    ABGELAUFEN = "abgelaufen"
    FEHLT = "fehlt"
    UNKLAR = "unklar"
    NICHT_NOETIG = "nicht_noetig"

    @property
    def beschriftung(self) -> str:
        return {
            "gueltig": "gültig",
            "laeuft_ab": "läuft ab",
            "abgelaufen": "abgelaufen",
            "fehlt": "fehlt",
            "unklar": "Angabe fehlt",
            "nicht_noetig": "nicht erforderlich",
        }[self.value]


@dataclass
class AmuBefund:
    person: Person
    spalte: str
    eintrag: AmuEintrag | None
    lage: AmuLage
    ablauf: date | None
    rohwert: str
    hinweis: str = ""

    @property
    def bezeichnung(self) -> str:
        """Abkuerzung mit ausgeschriebener Bezeichnung, soweit bekannt."""
        if self.eintrag and self.eintrag.bezeichnung:
            return f"{self.spalte} – {self.eintrag.bezeichnung}"
        return self.spalte

    @property
    def tage_bis_ablauf(self) -> int | None:
        return (self.ablauf - date.today()).days if self.ablauf else None


def _monate_dazu(ausgang: date, monate: int) -> date:
    monat = ausgang.month - 1 + monate
    jahr = ausgang.year + monat // 12
    monat = monat % 12 + 1
    # Auf den letzten gueltigen Tag des Zielmonats begrenzen.
    tag = min(ausgang.day, [31, 29 if jahr % 4 == 0 and (jahr % 100 != 0 or jahr % 400 == 0)
                            else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][monat - 1])
    return date(jahr, monat, tag)


def _zielgruppe_trifft_zu(eintrag: AmuEintrag, person: Person) -> Zustand:
    """Braucht diese Person diese Untersuchung?"""
    zielgruppe = eintrag.zielgruppe.strip().lower()
    if zielgruppe == ZIELGRUPPE_ALLE:
        return Zustand.JA
    if zielgruppe in (ZIELGRUPPE_KF_C, ZIELGRUPPE_FEV):
        return hat_fuehrerschein_klasse_c(person.wert(SPALTE_FUEHRERSCHEIN)).zustand
    if zielgruppe == ZIELGRUPPE_RS:
        return hat_qualifikation_rs(person.wert(SPALTE_MEDIZINISCH)).zustand
    # Einzelfaelle wie "Blanca" bei G20: dafuer werden keine Vorschlaege erzeugt.
    return Zustand.NEIN


def beurteile(
    person: Person, spalte: str, katalog: dict[str, AmuEintrag], heute: date | None = None
) -> AmuBefund:
    heute = heute or date.today()
    wert = person.wert(spalte)
    eintrag = katalog.get(spalte)
    ablauf = datum_aus(wert)

    if ablauf is not None:
        if ablauf < heute:
            lage = AmuLage.ABGELAUFEN
        elif ablauf <= _monate_dazu(heute, VORWARNUNG_MONATE):
            lage = AmuLage.LAEUFT_AB
        else:
            lage = AmuLage.GUELTIG
        return AmuBefund(person, spalte, eintrag, lage, ablauf, roh(wert))

    # Ab hier steht kein Datum in der Zelle.
    if eintrag is None:
        # G 26.3 und Masern stehen in den Blaettern, aber nicht im Katalog -
        # ohne Zielgruppe wird nie etwas angemahnt.
        return AmuBefund(
            person, spalte, None, AmuLage.NICHT_NOETIG, None, roh(wert),
            "Nicht im AMU-Katalog hinterlegt – wird nicht angemahnt.",
        )

    if eintrag.ist_freiwillig:
        return AmuBefund(
            person, spalte, eintrag, AmuLage.NICHT_NOETIG, None, roh(wert),
            "Freiwillige Untersuchung.",
        )

    zustand = _zielgruppe_trifft_zu(eintrag, person)
    if zustand is Zustand.NEIN:
        return AmuBefund(person, spalte, eintrag, AmuLage.NICHT_NOETIG, None, roh(wert))
    if zustand is Zustand.UNBEKANNT:
        return AmuBefund(
            person, spalte, eintrag, AmuLage.UNKLAR, None, roh(wert),
            f"Zielgruppe „{eintrag.zielgruppe}“ – die dafür nötige Angabe fehlt.",
        )

    # Zielgruppe trifft zu, aber es steht kein Datum da.
    if eintrag.zielgruppe.strip().lower() == ZIELGRUPPE_FEV:
        return AmuBefund(
            person, spalte, eintrag, AmuLage.UNKLAR, None, roh(wert),
            "Zielgruppe „neue KF C / Verlängerung“ – ob erforderlich, "
            "geht aus den Daten nicht hervor.",
        )
    return AmuBefund(person, spalte, eintrag, AmuLage.FEHLT, None, roh(wert))


def katalog_als_verzeichnis(eintraege: list[AmuEintrag]) -> dict[str, AmuEintrag]:
    return {eintrag.abkuerzung: eintrag for eintrag in eintraege}


def befunde_fuer(
    person: Person, katalog: dict[str, AmuEintrag], heute: date | None = None
) -> list[AmuBefund]:
    """Alle AMU-Befunde einer Person - nur fuer Spalten, die ihr Blatt hat."""
    return [
        beurteile(person, spalte, katalog, heute)
        for spalte in AMU_SPALTEN
        if spalte in person.werte
    ]


def alle_befunde(
    personen: list[Person], katalog: dict[str, AmuEintrag], heute: date | None = None
) -> list[AmuBefund]:
    return [b for person in personen for b in befunde_fuer(person, katalog, heute)]
