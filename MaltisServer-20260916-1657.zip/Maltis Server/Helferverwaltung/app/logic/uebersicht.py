"""Alles, was in der Übersicht je Person zusammenkommt.

Die Übersicht ist nach Personen gegliedert, nicht nach Themen: pro Person eine
Zeile mit ihrem Status, ihren Qualifizierungen, ihren Fristen und dem, was bei
ihr fehlt. Damit sieht man auf einen Blick, wo jemand steht, statt dieselbe
Person in fünf Themenlisten wiederzufinden.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date

from app.dateizugriff.schema import (
    QUALIFIKATIONS_SPALTEN,
    SPALTE_FORTBILDUNG_STATUS,
    SPALTE_FORTBILDUNG_WELCHE,
    SPALTE_PASSIV_SEIT,
    SPALTE_STATUS,
    SPALTE_TELEFON,
    STATUS_PASSIV,
    AmuEintrag,
    Person,
)
from app.logic.amu import AmuBefund, AmuLage, befunde_fuer as amu_befunde_fuer
from app.logic.jahrespflicht import Jahresbefund, Jahreslage
from app.logic.jahrespflicht import befunde_fuer as jahres_befunde_fuer
from app.logic.werte import Zustand, datum_aus, ja_nein, roh


@dataclass
class Qualifikation:
    spalte: str
    zustand: Zustand
    rohwert: str

    @property
    def ist_ja(self) -> bool:
        return self.zustand is Zustand.JA


@dataclass
class Personenbefund:
    """Alles, was die Übersicht über eine Person zeigt."""

    person: Person
    ist_passiv: bool
    passiv_seit: date | None
    telefon: str
    fortbildungsstatus: str
    fortbildung_welche: str
    amu: list[AmuBefund]
    jahrespflichten: list[Jahresbefund]
    qualifikationen: list[Qualifikation] = field(default_factory=list)

    # -- Kennzahlen fuer die Uebersichtszeile --------------------------------

    @property
    def abgelaufen(self) -> list[AmuBefund]:
        return [b for b in self.amu if b.lage is AmuLage.ABGELAUFEN]

    @property
    def laeuft_ab(self) -> list[AmuBefund]:
        return [b for b in self.amu if b.lage is AmuLage.LAEUFT_AB]

    @property
    def fehlende_amu(self) -> list[AmuBefund]:
        return [b for b in self.amu if b.lage is AmuLage.FEHLT]

    @property
    def unklare_amu(self) -> list[AmuBefund]:
        return [b for b in self.amu if b.lage is AmuLage.UNKLAR]

    @property
    def anstehend(self) -> list[Jahresbefund]:
        """Jahrespflichten, die dieses Jahr noch zu erledigen sind."""
        return [b for b in self.jahrespflichten if b.lage is Jahreslage.FAELLIG]

    @property
    def unklare_jahrespflichten(self) -> list[Jahresbefund]:
        return [b for b in self.jahrespflichten if b.lage is Jahreslage.UNKLAR]

    @property
    def qualifikationen_vorhanden(self) -> list[Qualifikation]:
        return [q for q in self.qualifikationen if q.ist_ja]

    @property
    def hat_fortbildungswunsch(self) -> bool:
        return bool(self.fortbildungsstatus or self.fortbildung_welche)

    @property
    def anzahl_offene_angaben(self) -> int:
        return len(self.unklare_amu) + len(self.unklare_jahrespflichten)

    @property
    def braucht_aufmerksamkeit(self) -> bool:
        return bool(
            self.abgelaufen
            or self.laeuft_ab
            or self.fehlende_amu
            or self.anstehend
            or self.anzahl_offene_angaben
        )

    @property
    def dringlichkeit(self) -> tuple:
        """Sortierschluessel: erst das Dringendste, dann alphabetisch."""
        return (
            -len(self.abgelaufen),
            -len(self.anstehend),
            -len(self.laeuft_ab),
            -len(self.fehlende_amu),
            self.person.name.lower(),
        )


def _status(person: Person) -> tuple[bool, date | None]:
    rohwert = roh(person.wert(SPALTE_STATUS))
    return rohwert.strip().lower() == STATUS_PASSIV, datum_aus(person.wert(SPALTE_PASSIV_SEIT))


def baue_befund(
    person: Person, amu_katalog: dict[str, AmuEintrag], heute: date | None = None
) -> Personenbefund:
    heute = heute or date.today()
    ist_passiv, seit = _status(person)

    qualifikationen = []
    for spalte in QUALIFIKATIONS_SPALTEN:
        if spalte not in person.werte:
            continue
        befund = ja_nein(person.wert(spalte))
        qualifikationen.append(Qualifikation(spalte, befund.zustand, befund.rohwert))

    return Personenbefund(
        person=person,
        ist_passiv=ist_passiv,
        passiv_seit=seit,
        telefon=roh(person.wert(SPALTE_TELEFON)),
        fortbildungsstatus=roh(person.wert(SPALTE_FORTBILDUNG_STATUS)),
        fortbildung_welche=roh(person.wert(SPALTE_FORTBILDUNG_WELCHE)),
        amu=amu_befunde_fuer(person, amu_katalog, heute),
        jahrespflichten=jahres_befunde_fuer(person, heute),
        qualifikationen=qualifikationen,
    )


def baue_uebersicht(
    personen: list[Person], amu_katalog: dict[str, AmuEintrag], heute: date | None = None
) -> list[Personenbefund]:
    befunde = [baue_befund(p, amu_katalog, heute) for p in personen]
    befunde.sort(key=lambda b: b.dringlichkeit)
    return befunde
