"""Datenbank der Anwendung.

Hier stehen ausschliesslich die Daten, die die Anwendung selbst haelt:
Fortbildungskatalog, Aenderungsprotokoll, Zusatzfelder und Einstellungen.
Die Personendaten selbst stehen in der Excel-Datei und werden hier NICHT
gespiegelt.
"""

from __future__ import annotations

from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import DATA_DIR, DB_PATH

DATA_DIR.mkdir(parents=True, exist_ok=True)

engine = create_engine(
    f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


def get_db() -> Session:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def ergaenze_fehlende_spalten(spalten_je_tabelle: dict[str, tuple[str, str]]) -> list[str]:
    """Ergaenzt fehlende Spalten in bestehenden Tabellen.

    ``Base.metadata.create_all`` legt nur vermisste *Tabellen* an, keine
    vermissten Spalten. Wenn eine bestehende Datenbank aus einer frueheren
    Version ein Feld nicht kennt, wird es hier idempotent nachgezogen.

    Parameter: {Tabellenname: ((Spaltenname, SQL-Typ), ...)}.
    Gibt die ergaenzten Spalten als Liste zurueck (fuer das Protokoll).
    """
    bestand = inspect(engine)
    geaendert: list[str] = []
    for tabelle, spalten in spalten_je_tabelle.items():
        vorhandene = {c["name"] for c in bestand.get_columns(tabelle)}
        for name, sql_typ in spalten:
            if name in vorhandene:
                continue
            with engine.begin() as verbindung:
                verbindung.execute(
                    text(f"ALTER TABLE {tabelle} ADD COLUMN {name} {sql_typ}")
                )
            geaendert.append(f"{tabelle}.{name}")
    return geaendert
