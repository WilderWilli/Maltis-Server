"""Kontrollseite für die Aufteilung in Vor- und Nachname."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.dateizugriff import hole_helferdatei
from app.deps import base_context, hole_zusatz, templates, zusatz_verzeichnis
from app.logic.namen import trenne

router = APIRouter()


@router.get("/namen")
def kontrolle(request: Request, db: Session = Depends(get_db), meldung: str = ""):
    ctx = base_context(request, db)
    datei = hole_helferdatei()
    if not datei.ist_erreichbar():
        return templates.TemplateResponse("datei_fehlt.html", ctx)

    verzeichnis = zusatz_verzeichnis(db)
    zeilen = []
    for person in datei.lade_personen():
        eintrag = verzeichnis.get((person.blatt, person.name))
        vorschlag = trenne(person.name)
        zeilen.append(
            {
                "person": person,
                "kennung": person.schluessel.kennung,
                "vorname": (eintrag.vorname if eintrag else None) or vorschlag.vorname,
                "nachname": (eintrag.nachname if eintrag else None) or vorschlag.nachname,
                "unsicher": vorschlag.unsicher,
                "grund": vorschlag.grund,
                "geprueft": bool(eintrag and eintrag.name_geprueft),
            }
        )

    zeilen.sort(key=lambda z: (not z["unsicher"], z["person"].name))
    ctx.update(
        {
            "zeilen": zeilen,
            "offen": sum(1 for z in zeilen if not z["geprueft"]),
            "unsicher": sum(1 for z in zeilen if z["unsicher"]),
            "meldung": meldung,
        }
    )
    return templates.TemplateResponse("namen_kontrolle.html", ctx)


@router.post("/namen")
async def speichern(request: Request, db: Session = Depends(get_db)):
    formular = await request.form()
    personen = {p.schluessel.kennung: p for p in hole_helferdatei().lade_personen()}

    gespeichert = 0
    for schluessel, wert in formular.items():
        if not schluessel.startswith("vorname:"):
            continue
        kennung = schluessel[len("vorname:"):]
        person = personen.get(kennung)
        if person is None:
            continue
        zusatz = hole_zusatz(db, person)
        zusatz.vorname = str(wert).strip() or None
        zusatz.nachname = str(formular.get(f"nachname:{kennung}") or "").strip() or None
        zusatz.name_geprueft = True
        gespeichert += 1

    db.commit()
    return RedirectResponse(
        f"/namen?meldung={gespeichert} Name(n) bestätigt.", status_code=302
    )
