"""Übersicht: eine Zeile je Person statt mehrerer Themenlisten."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app.database import get_db
from app.dateizugriff import hole_helferdatei
from app.deps import base_context, templates
from app.logic.amu import katalog_als_verzeichnis
from app.logic.uebersicht import baue_uebersicht

router = APIRouter()


@router.get("/")
def dashboard(
    request: Request,
    db: Session = Depends(get_db),
    filter: str = "",
    suche: str = "",
):
    ctx = base_context(request, db)
    datei = hole_helferdatei()
    if not datei.ist_erreichbar():
        return templates.TemplateResponse("datei_fehlt.html", ctx)

    personen = datei.lade_personen()
    katalog = katalog_als_verzeichnis(datei.lade_amu_katalog())
    befunde = baue_uebersicht(personen, katalog)

    kennzahlen = {
        "personen": len(befunde),
        "passiv": sum(1 for b in befunde if b.ist_passiv),
        "abgelaufen": sum(len(b.abgelaufen) for b in befunde),
        "laeuft_ab": sum(len(b.laeuft_ab) for b in befunde),
        "fehlend": sum(len(b.fehlende_amu) for b in befunde),
        "anstehend": sum(len(b.anstehend) for b in befunde),
        "fortbildungswunsch": sum(1 for b in befunde if b.hat_fortbildungswunsch),
        "offen": sum(b.anzahl_offene_angaben for b in befunde),
    }

    # Filter der Übersicht - zeigt nur Personen, auf die etwas zutrifft.
    filter_regeln = {
        "abgelaufen": lambda b: b.abgelaufen,
        "laeuft_ab": lambda b: b.laeuft_ab,
        "fehlend": lambda b: b.fehlende_amu,
        "anstehend": lambda b: b.anstehend,
        "fortbildung": lambda b: b.hat_fortbildungswunsch,
        "offen": lambda b: b.anzahl_offene_angaben,
        "passiv": lambda b: b.ist_passiv,
        "handlungsbedarf": lambda b: b.braucht_aufmerksamkeit,
    }
    gefiltert = befunde
    if filter in filter_regeln:
        gefiltert = [b for b in befunde if filter_regeln[filter](b)]
    begriff = suche.strip().lower()
    if begriff:
        gefiltert = [b for b in gefiltert if begriff in b.person.name.lower()]

    ctx.update(
        {
            "befunde": gefiltert,
            "kennzahlen": kennzahlen,
            "filter": filter,
            "suche": suche,
            "angezeigt": len(gefiltert),
        }
    )
    return templates.TemplateResponse("dashboard.html", ctx)
