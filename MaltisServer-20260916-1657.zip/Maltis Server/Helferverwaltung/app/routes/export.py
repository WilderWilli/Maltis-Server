"""Export für die PSA-Beauftragte."""

from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app.config import EXPORT_ORDNER
from app.database import get_db
from app.dateizugriff import hole_helferdatei
from app.deps import (
    als_zusatzangaben,
    base_context,
    kuerzel_aus,
    templates,
    zusatz_verzeichnis,
)
from app.logic.export import (
    EXPORT_UEBERSCHRIFTEN,
    FRUEHESTES,
    ZUORDNUNG,
    Zusatzangaben,
    baue_zeilen,
)
from app.logic.namen import trenne
from app import models

router = APIRouter()


def _zuordnungsuebersicht() -> list[dict]:
    """Was gefüllt wird und was leer bleibt - vor dem Knopfdruck sichtbar."""
    herkunft = {
        "Nachname": "aus „Name“ getrennt",
        "Vorname": "aus „Name“ getrennt",
        "Geburtsdatum": "Geburtsdatum",
        "Zugzuteilung": "Feld der Anwendung",
    }
    for ziel, quelle in ZUORDNUNG.items():
        herkunft[ziel] = quelle
    for ziel, quellen in FRUEHESTES.items():
        herkunft[ziel] = "frühestes aus " + ", ".join(quellen)

    return [
        {"spalte": spalte, "quelle": herkunft.get(spalte, ""), "gefuellt": spalte in herkunft}
        for spalte in EXPORT_UEBERSCHRIFTEN
    ]


@router.get("/export")
def seite(request: Request, db: Session = Depends(get_db), meldung: str = ""):
    ctx = base_context(request, db)
    uebersicht = _zuordnungsuebersicht()
    verzeichnis = zusatz_verzeichnis(db)
    datei = hole_helferdatei()
    personen = datei.lade_personen() if datei.ist_erreichbar() else []
    ungeprueft = [
        p for p in personen
        if not (
            (eintrag := verzeichnis.get((p.blatt, p.name))) and eintrag.name_geprueft
        )
    ]

    ctx.update(
        {
            "uebersicht": uebersicht,
            "anzahl_gefuellt": sum(1 for z in uebersicht if z["gefuellt"]),
            "anzahl_personen": len(personen),
            "ohne_namen": len(ungeprueft),
            "export_ordner": str(EXPORT_ORDNER),
            "meldung": meldung,
        }
    )
    return templates.TemplateResponse("export.html", ctx)


@router.post("/export")
def erzeugen(request: Request, db: Session = Depends(get_db)):
    datei = hole_helferdatei()
    if not datei.ist_erreichbar():
        return RedirectResponse(
            "/export?meldung=Die führende Datei ist nicht erreichbar.", status_code=302
        )

    personen = datei.lade_personen()
    zusatz = als_zusatzangaben(zusatz_verzeichnis(db))

    # Wo die Namenstrennung noch nicht bestätigt wurde, greift der automatische
    # Vorschlag. Sonst stünde die Person mit leerem Namen in der Liste - und
    # eine Zeile ganz ohne Inhalt lässt Excel unter den Tisch fallen.
    for person in personen:
        schluessel = (person.blatt, person.name)
        vorhanden = zusatz.get(schluessel)
        if vorhanden and (vorhanden.nachname or vorhanden.vorname):
            continue
        vorschlag = trenne(person.name)
        zusatz[schluessel] = Zusatzangaben(
            vorname=vorschlag.vorname,
            nachname=vorschlag.nachname,
            zugzuteilung=vorhanden.zugzuteilung if vorhanden else "",
        )

    zeilen = baue_zeilen(personen, zusatz)

    stempel = datetime.now().strftime("%Y-%m-%d_%H-%M")
    ziel = EXPORT_ORDNER / f"Übersichtsliste_Helfer_{stempel}.xlsx"
    datei.schreibe_export(list(EXPORT_UEBERSCHRIFTEN), zeilen, ziel)

    db.add(
        models.Aenderung(
            kuerzel=kuerzel_aus(request) or "unbekannt",
            aktion="export_erzeugt",
            blatt="-",
            spalte="Export",
            name=ziel.name,
            neuer_wert=str(ziel),
        )
    )
    db.commit()
    return RedirectResponse(
        f"/export?meldung=Export mit {len(zeilen)} Personen erzeugt: {ziel.name}",
        status_code=302,
    )
