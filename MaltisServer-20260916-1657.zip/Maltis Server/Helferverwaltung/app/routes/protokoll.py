"""Änderungsprotokoll."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app import models
from app.database import get_db
from app.deps import base_context, templates

router = APIRouter()


@router.get("/protokoll")
def anzeigen(request: Request, db: Session = Depends(get_db), seite: int = 1):
    ctx = base_context(request, db)
    pro_seite = 100
    seite = max(1, seite)

    gesamt = db.scalar(select(func.count(models.Aenderung.id))) or 0

    eintraege = db.scalars(
        select(models.Aenderung)
        .order_by(models.Aenderung.zeitpunkt.desc(), models.Aenderung.id.desc())
        .offset((seite - 1) * pro_seite)
        .limit(pro_seite)
    ).all()

    ctx.update(
        {
            "eintraege": eintraege,
            "seite": seite,
            "gesamt": gesamt,
            "hat_weitere": seite * pro_seite < gesamt,
        }
    )
    return templates.TemplateResponse("protokoll.html", ctx)
