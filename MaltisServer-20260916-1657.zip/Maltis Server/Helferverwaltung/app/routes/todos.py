"""Gruppenführer-Übersicht und schnelle GF-Zuordnung.

Die Aufgabenliste je Gruppenführer (wer gehört zu wem, was steht an) trägt ihre
Logik in ``app.logic.gf_todos`` - hier steht nur die HTTP-Schicht. Die schnelle
Zuweisung über die Personalübersicht läuft über ``/gf-zuweisen`` und schreibt
allein in die Excel-Spalte GF.
"""

from __future__ import annotations

from urllib.parse import quote

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.dateizugriff import hole_helferdatei
from app.dateizugriff.schema import (
    GF_WERTE,
    SPALTE_GF,
    DateiGesperrt,
    DateiVeraendert,
    ZeileVeraendert,
)
from app.deps import base_context, kuerzel_aus, protokolliere, templates
from app.logic.amu import katalog_als_verzeichnis
from app.logic.gf_todos import baue_gf_uebersicht
from app.routes.helfer import _person_suchen

router = APIRouter()


@router.get("/gruppenfuehrer")
def gruppenfuehrer(request: Request, db: Session = Depends(get_db)):
    ctx = base_context(request, db)
    datei = hole_helferdatei()
    if not datei.ist_erreichbar():
        return templates.TemplateResponse("datei_fehlt.html", ctx)

    personen = datei.lade_personen()
    katalog = katalog_als_verzeichnis(datei.lade_amu_katalog())
    gruppen = baue_gf_uebersicht(personen, katalog)

    kennzahlen = {
        "aufgaben": sum(g.anzahl_offene_punkte for g in gruppen),
        "zugewiesen": sum(g.anzahl_personen for g in gruppen if g.gf is not None),
        "ohne": sum(g.anzahl_personen for g in gruppen if g.gf is None),
    }
    ctx.update({"gruppen": gruppen, "kennzahlen": kennzahlen})
    return templates.TemplateResponse("gruppenfuehrer.html", ctx)


@router.post("/gf-zuweisen")
async def gf_zuweisen(request: Request, db: Session = Depends(get_db)):
    """Schnelle Zuordnung direkt aus der Personalübersicht.

    Leer heisst "ohne Gruppenführer" - die Angabe wird gelöscht. Geschrieben
    wird nur in die Excel-Spalte GF; in die Datenbank geht einzig die
    Protokollzeile.
    """
    ctx = base_context(request, db)
    formular = await request.form()
    kennung = str(formular.get("kennung") or "").strip()
    gf = str(formular.get("gf") or "").strip()

    if gf and gf not in GF_WERTE:
        ctx.update(
            {
                "titel": "Nicht geändert",
                "text": f"Die Auswahl „{gf or '(leer)'}“ ist kein gültiger Gruppenführer. "
                        "Erlaubt sind: Niklas, Nino – oder leer für ohne Zuordnung.",
                "zurueck": "/helfer",
            }
        )
        return templates.TemplateResponse("meldung.html", ctx, status_code=400)

    person, _ = _person_suchen(kennung)
    if person is None:
        ctx.update(
            {
                "titel": "Person nicht gefunden",
                "text": "Diese Person steht nicht mehr in der Datei. Es wurde nichts geändert.",
                "zurueck": "/helfer",
            }
        )
        return templates.TemplateResponse("meldung.html", ctx, status_code=404)

    try:
        saetze = hole_helferdatei().speichere_person(
            person.schluessel, {SPALTE_GF: gf or None}
        )
    except (DateiGesperrt, ZeileVeraendert, DateiVeraendert) as fehler:
        db.rollback()
        ctx.update(
            {
                "titel": "Nicht gespeichert",
                "text": str(fehler),
                "zurueck": f"/helfer/{person.schluessel.kennung}",
            }
        )
        return templates.TemplateResponse("meldung.html", ctx, status_code=409)

    protokolliere(db, kuerzel_aus(request), saetze)
    db.commit()

    ziel = request.headers.get("referer") or "/helfer"
    text = (
        f"{person.name}: Gruppenführer ist {gf}."
        if gf else f"{person.name}: ohne Gruppenführer."
    )
    trenner = "&" if "?" in ziel else "?"
    return RedirectResponse(
        f"{ziel}{trenner}meldung={quote(text)}", status_code=302
    )