"""Einstellungen und Zustand der Anwendung."""

from __future__ import annotations

from datetime import datetime
from urllib.parse import quote

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app.config import (
    BLATT_GRUPPE_1,
    EXPORT_ORDNER,
    GRAPH_DATEI,
    GRAPH_ORDNER,
    GRAPH_SITE_ID,
    HELFERDATEI_PFAD,
    MAX_SICHERUNGEN,
    SICHERUNGS_ORDNER,
    VORWARNUNG_MONATE,
    graph_konfiguriert,
)
from app.database import get_db
from app.dateizugriff import hole_helferdatei
from app.dateizugriff.graph import (
    GraphHelferdatei,
    sync_status_aktualisieren,
)
from app.dateizugriff.schema import ERWARTETE_SPALTEN
from app.deps import base_context, templates

router = APIRouter()


def _mit_meldung(ziel: str, meldung: str) -> str:
    trenner = "&" if "?" in ziel else "?"
    return f"{ziel}{trenner}sync_meldung={quote(meldung)}"


@router.get("/einstellungen")
def anzeigen(request: Request, db: Session = Depends(get_db)):
    ctx = base_context(request, db)
    datei = hole_helferdatei()

    sicherungen = []
    if SICHERUNGS_ORDNER.exists():
        sicherungen = sorted(
            SICHERUNGS_ORDNER.glob("*.xlsx"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )

    # Stimmt der Aufbau der Datei noch mit dem überein, was die Anwendung erwartet?
    spaltenpruefung = []
    if datei.ist_erreichbar():
        for blatt, erwartet in ((BLATT_GRUPPE_1, ERWARTETE_SPALTEN),):
            try:
                ist = datei.spalten(blatt)
            except KeyError:
                spaltenpruefung.append(
                    {"blatt": blatt, "stimmt": False, "text": "Blatt nicht gefunden."}
                )
                continue
            stimmt = tuple(ist) == erwartet
            fehlend = [s for s in erwartet if s not in ist]
            neu = [s for s in ist if s not in erwartet]
            text = "Aufbau unverändert."
            if not stimmt:
                teile = []
                if fehlend:
                    teile.append("fehlt: " + ", ".join(fehlend))
                if neu:
                    teile.append("neu: " + ", ".join(neu))
                text = "; ".join(teile) or "Reihenfolge geändert."
            spaltenpruefung.append({"blatt": blatt, "stimmt": stimmt, "text": text})

    ist_graph = isinstance(datei, GraphHelferdatei)

    ctx.update(
        {
            "quelle": "sharepoint" if ist_graph else "lokal",
            "graph_config_meldung": graph_konfiguriert(),
            "graph_pfad": (
                f"/sites/{GRAPH_SITE_ID}/drive/root:/{GRAPH_ORDNER}/{GRAPH_DATEI}"
                if ist_graph
                else None
            ),
            "lokal_kopie": str(datei.pfad),
            "helferdatei": str(HELFERDATEI_PFAD),
            "export_ordner": str(EXPORT_ORDNER),
            "sicherungs_ordner": str(SICHERUNGS_ORDNER),
            "max_sicherungen": MAX_SICHERUNGEN,
            "vorwarnung_monate": VORWARNUNG_MONATE,
            "sicherungen": [
                {
                    "name": p.name,
                    "zeitpunkt": datetime.fromtimestamp(p.stat().st_mtime),
                    "groesse": p.stat().st_size,
                }
                for p in sicherungen
            ],
            "spaltenpruefung": spaltenpruefung,
            "amu_katalog": datei.lade_amu_katalog() if datei.ist_erreichbar() else [],
            "sync_meldung": request.query_params.get("sync_meldung", ""),
        }
    )
    return templates.TemplateResponse("einstellungen.html", ctx)


@router.post("/sync/test")
def sync_testen(request: Request, db: Session = Depends(get_db)):
    """Lebende Pruefung der Verbindung; Ergebnis landet im Status in der DB."""
    datei = hole_helferdatei()
    if isinstance(datei, GraphHelferdatei):
        ok, meldung = datei.pruefe_verbindung()
        augenblick = datei.status_augenblick()
        sync_status_aktualisieren(
            db,
            modus="sharepoint",
            verbunden=ok,
            offline=not ok,
            ausstehend=augenblick["ausstehend"],
            letzte_synchronisierung=augenblick["letzte_synchronisierung"],
            meldung=meldung,
        )
    else:
        erreichbar = datei.ist_erreichbar()
        if not erreichbar:
            meldung = (
                "Datei nicht gefunden – bitte HELFERDATEI_PFAD in der .env prüfen."
            )
            verbunden = False
        else:
            gesperrt, sperrtext = datei.ist_gesperrt()
            if gesperrt:
                meldung = f"Datei gefunden, aber gerade in Excel geöffnet: {sperrtext}"
                verbunden = False
            else:
                meldung = "Lokaler Ordner erreichbar, Datei nicht geöffnet."
                verbunden = True
        sync_status_aktualisieren(
            db, modus="lokal", verbunden=verbunden, offline=False, meldung=meldung
        )
    ziel = request.headers.get("referer") or "/einstellungen"
    return RedirectResponse(_mit_meldung(ziel, meldung), status_code=302)


@router.post("/sync/now")
def sync_jetzt(request: Request, db: Session = Depends(get_db)):
    """Erzwingt den Abgleich und haelt das Ergebnis im Status fest."""
    datei = hole_helferdatei()
    if isinstance(datei, GraphHelferdatei):
        meldung = datei.synchronisiere_jetzt()
        augenblick = datei.status_augenblick()
        sync_status_aktualisieren(
            db,
            modus="sharepoint",
            verbunden=not augenblick["offline"],
            offline=augenblick["offline"],
            ausstehend=augenblick["ausstehend"],
            letzte_synchronisierung=augenblick["letzte_synchronisierung"],
            meldung=meldung,
        )
    else:
        meldung = "Lokaler Modus – es gibt nichts zu synchronisieren."
        sync_status_aktualisieren(
            db,
            modus="lokal",
            verbunden=datei.ist_erreichbar(),
            offline=False,
            ausstehend=False,
            meldung=meldung,
        )
    ziel = request.headers.get("referer") or "/einstellungen"
    return RedirectResponse(_mit_meldung(ziel, meldung), status_code=302)