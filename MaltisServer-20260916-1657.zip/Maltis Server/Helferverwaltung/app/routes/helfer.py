"""Helferliste, Profilseite, Bearbeiten und Neuanlage."""

from __future__ import annotations

import re
from datetime import date

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app import models
from app.config import GRUPPENBLAETTER
from app.database import get_db
from app.dateizugriff import hole_helferdatei
from app.dateizugriff.schema import (
    AMU_SPALTEN,
    AUSWAHLWERTE,
    FORTBILDUNGS_SPALTEN,
    GF_WERTE,
    SPALTE_CBRN_GROESSE,
    SPALTE_DIENSTAUSWEIS,
    SPALTE_DIENSTKLEIDUNG,
    SPALTE_DIENSTKLEIDUNG_GROESSE,
    SPALTE_GF,
    SPALTE_NAME,
    SPALTE_NR,
    SPALTE_PASSIV_SEIT,
    SPALTE_RS_FORTBILDUNG,
    SPALTE_AUSTRITT,
    SPALTE_STATUS,
    Aenderungssatz,
    DateiGesperrt,
    DateiVeraendert,
    Feldart,
    Person,
    Personenschluessel,
    ZeileVeraendert,
    Zellwert,
    feldart,
)
from app.deps import (
    base_context,
    hole_zusatz,
    kuerzel_aus,
    protokolliere,
    templates,
    zusatz_verzeichnis,
)
from app.logic.amu import befunde_fuer, katalog_als_verzeichnis
from app.logic.export import STANDARD_ZUGZUTEILUNG, ZUGZUTEILUNGEN
from app.logic.namen import trenne
from app.logic.jahrespflicht import befunde_fuer as jahres_befunde_fuer
from app.logic.werte import datum_aus, ja_nein, roh

router = APIRouter()

# Reihenfolge und Gruppierung der Felder auf der Profilseite.
GRUPPEN: tuple[tuple[str, tuple[str, ...]], ...] = (
    (
        "Stammdaten",
        (
            "Nr", "Name", "Geburtsdatum", "Eintrittsdatum Gliederung", "Mitglied?",
            SPALTE_STATUS, SPALTE_PASSIV_SEIT, SPALTE_GF, "Jahresgespräch",
            "Verpflichtung?", "Divera?", SPALTE_DIENSTKLEIDUNG, SPALTE_DIENSTAUSWEIS,
            SPALTE_DIENSTKLEIDUNG_GROESSE, SPALTE_CBRN_GROESSE,
        ),
    ),
    (
        "Qualifikation und Einsatz",
        (
            "Medizinisch", SPALTE_RS_FORTBILDUNG, "Taktisch", "Führerschein",
            "Leistungserbringer", "Fahrzeugeinweisung GwSan", "Einweisung NTKW ZS",
            "Freigabeerklärungen",
        ),
    ),
    (
        "Arbeitsmedizinische Untersuchungen",
        AMU_SPALTEN + ("Masern", "AMU Dok  in ARNO", "Freigaben abgeschlossen"),
    ),
    ("Fortbildungen und Unterweisungen", FORTBILDUNGS_SPALTEN),
    ("Sonstiges", ("Sonstige",)),
)

# Nur ein vollstaendiges Datum wird als Datum gespeichert. "30.11.2027 (bg)"
# bleibt Text, damit der Zusatz nicht verlorengeht.
_NUR_DATUM = re.compile(r"^(\d{1,2})\.(\d{1,2})\.(\d{2,4})$")
_NUR_ISO = re.compile(r"^(\d{4})-(\d{1,2})-(\d{1,2})$")


def wert_aus_eingabe(spalte: str, eingabe: str) -> Zellwert:
    """Formulareingabe in einen Zellwert umsetzen - ohne zu vereinheitlichen."""
    text = (eingabe or "").strip()
    if not text:
        return None

    art = feldart(spalte)
    if art in (Feldart.DATUM, Feldart.GEMISCHT):
        treffer = _NUR_DATUM.match(text)
        if treffer:
            tag, monat, jahr = (int(t) for t in treffer.groups())
            if jahr < 100:
                jahr += 2000
            try:
                return date(jahr, monat, tag)
            except ValueError:
                return text
        treffer = _NUR_ISO.match(text)
        if treffer:
            jahr, monat, tag = (int(t) for t in treffer.groups())
            try:
                return date(jahr, monat, tag)
            except ValueError:
                return text
    if art is Feldart.ZAHL and text.isdigit():
        return int(text)
    return text


def _feld(person: Person, spalte: str) -> dict:
    wert = person.wert(spalte)
    art = feldart(spalte)
    return {
        "spalte": spalte,
        "art": art.value,
        "ist_ja_nein": art is Feldart.JA_NEIN,
        "ist_auswahl": art is Feldart.AUSWAHL,
        "auswahl": AUSWAHLWERTE.get(spalte, ()),
        "nur_lesen": spalte == SPALTE_NR,
        "rohwert": roh(wert),
        "zustand": ja_nein(wert).zustand.value if art is Feldart.JA_NEIN else "",
    }


def _gruppen_fuer(person: Person) -> list[dict]:
    gruppen = []
    for titel, spalten in GRUPPEN:
        felder = [_feld(person, s) for s in spalten if s in person.werte]
        if felder:
            gruppen.append({"titel": titel, "felder": felder})
    # Spalten, die in keiner Gruppe stehen, gehen nicht verloren.
    bekannt = {s for _, spalten in GRUPPEN for s in spalten}
    rest = [_feld(person, s) for s in person.werte if s not in bekannt]
    if rest:
        gruppen.append({"titel": "Weitere Spalten", "felder": rest})
    return gruppen


def _person_suchen(kennung: str) -> tuple[Person | None, list[Person]]:
    schluessel = Personenschluessel.aus_kennung(kennung)
    personen = hole_helferdatei().lade_personen()
    for person in personen:
        if (
            person.blatt == schluessel.blatt
            and person.schluessel.zeile == schluessel.zeile
            and person.name == schluessel.name
        ):
            return person, personen
    # Zeile verschoben? Dann ueber Blatt und Name suchen.
    for person in personen:
        if person.blatt == schluessel.blatt and person.name == schluessel.name:
            return person, personen
    return None, personen


@router.get("/helfer")
def liste(
    request: Request,
    db: Session = Depends(get_db),
    suche: str = "",
    gf: str = "",
    meldung: str = "",
):
    ctx = base_context(request, db)
    datei = hole_helferdatei()
    if not datei.ist_erreichbar():
        return templates.TemplateResponse("datei_fehlt.html", ctx)

    personen = datei.lade_personen()
    katalog = katalog_als_verzeichnis(datei.lade_amu_katalog())
    zusatz = zusatz_verzeichnis(db)

    # Filter nach Gruppenführer - "ohne" zeigt alle ohne gültige Zuordnung.
    if gf:
        if gf == "ohne":
            personen = [p for p in personen if roh(p.wert(SPALTE_GF)) not in GF_WERTE]
        else:
            personen = [p for p in personen if roh(p.wert(SPALTE_GF)) == gf]

    begriff = suche.strip().lower()
    if begriff:
        personen = [p for p in personen if begriff in p.name.lower()]

    zeilen = []
    for person in personen:
        befunde = befunde_fuer(person, katalog)
        eintrag = zusatz.get((person.blatt, person.name))
        zeilen.append(
            {
                "person": person,
                "zusatz": eintrag,
                "gf": roh(person.wert(SPALTE_GF)),
                "abgelaufen": sum(1 for b in befunde if b.lage.value == "abgelaufen"),
                "laeuft_ab": sum(1 for b in befunde if b.lage.value == "laeuft_ab"),
                "fehlend": sum(1 for b in befunde if b.lage.value == "fehlt"),
            }
        )

    ctx.update(
        {
            "zeilen": zeilen,
            "suche": suche,
            "gf": gf,
            "gf_werte": GF_WERTE,
            "meldung": meldung,
            "anzahl": len(zeilen),
        }
    )
    return templates.TemplateResponse("helfer_liste.html", ctx)


@router.get("/helfer/{kennung:path}")
def profil(
    kennung: str, request: Request, db: Session = Depends(get_db), meldung: str = ""
):
    ctx = base_context(request, db)
    datei = hole_helferdatei()
    if not datei.ist_erreichbar():
        return templates.TemplateResponse("datei_fehlt.html", ctx)

    person, _ = _person_suchen(kennung)
    if person is None:
        ctx.update(
            {
                "titel": "Person nicht gefunden",
                "text": "Diese Person steht nicht mehr in der Datei. "
                        "Möglicherweise wurde die Zeile in Excel gelöscht.",
            }
        )
        return templates.TemplateResponse("meldung.html", ctx, status_code=404)

    katalog = katalog_als_verzeichnis(datei.lade_amu_katalog())
    befunde = befunde_fuer(person, katalog)

    zusatz = zusatz_verzeichnis(db).get((person.blatt, person.name))
    ctx.update(
        {
            "jahrespflichten": jahres_befunde_fuer(person),
            "person": person,
            "kennung": person.schluessel.kennung,
            "gruppen": _gruppen_fuer(person),
            "befunde": befunde,
            "zusatz": zusatz,
            "zugzuteilungen": ZUGZUTEILUNGEN,
            "meldung": meldung,
        }
    )
    return templates.TemplateResponse("helfer_profil.html", ctx)


@router.post("/helfer/{kennung:path}")
async def speichern(kennung: str, request: Request, db: Session = Depends(get_db)):
    ctx = base_context(request, db)
    formular = await request.form()

    # Immer neu einlesen - nie auf einem alten Stand im Speicher arbeiten.
    person, _ = _person_suchen(kennung)
    if person is None:
        ctx.update(
            {
                "titel": "Person nicht gefunden",
                "text": "Diese Person steht nicht mehr in der Datei. "
                        "Es wurde nichts geändert.",
            }
        )
        return templates.TemplateResponse("meldung.html", ctx, status_code=404)

    aenderungen: dict[str, Zellwert] = {}
    for schluessel, eingabe in formular.items():
        if not schluessel.startswith("feld:"):
            continue
        spalte = schluessel[5:]
        if spalte not in person.werte or spalte == SPALTE_NR:
            continue
        aenderungen[spalte] = wert_aus_eingabe(spalte, str(eingabe))

    # Zusatzfelder der Anwendung (stehen nicht in der Excel-Datei).
    zusatz = hole_zusatz(db, person)
    zuteilung = (formular.get("zugzuteilung") or "").strip()
    zusatz.zugzuteilung = zuteilung or None
    bemerkung = (formular.get("bemerkung") or "").strip()
    zusatz.bemerkung = bemerkung or None

    try:
        saetze = hole_helferdatei().speichere_person(person.schluessel, aenderungen)
    except (DateiGesperrt, ZeileVeraendert, DateiVeraendert) as fehler:
        db.rollback()
        ctx.update({"titel": "Nicht gespeichert", "text": str(fehler),
                    "zurueck": f"/helfer/{person.schluessel.kennung}"})
        return templates.TemplateResponse("meldung.html", ctx, status_code=409)

    # Wurde der Name geändert, wandert der Zusatzsatz mit.
    if SPALTE_NAME in aenderungen and aenderungen[SPALTE_NAME]:
        neuer_name = str(aenderungen[SPALTE_NAME]).strip()
        if neuer_name != person.name:
            zusatz.name = neuer_name
            vorschlag = trenne(neuer_name)
            zusatz.vorname, zusatz.nachname = vorschlag.vorname, vorschlag.nachname
            zusatz.name_geprueft = False

    protokolliere(db, kuerzel_aus(request), saetze)
    db.commit()

    ziel_name = str(aenderungen.get(SPALTE_NAME) or person.name).strip()
    ziel = Personenschluessel(person.blatt, person.schluessel.zeile, ziel_name)
    text = (
        f"{len(saetze)} Feld(er) gespeichert." if saetze else "Keine Änderung nötig."
    )
    return RedirectResponse(f"/helfer/{ziel.kennung}?meldung={text}", status_code=302)


@router.get("/neue-person")
def neu_formular(request: Request, db: Session = Depends(get_db)):
    ctx = base_context(request, db)
    datei = hole_helferdatei()
    if not datei.ist_erreichbar():
        return templates.TemplateResponse("datei_fehlt.html", ctx)
    ctx.update(
        {
            "blaetter": GRUPPENBLAETTER,
            "spalten_je_blatt": {b: datei.spalten(b) for b in GRUPPENBLAETTER},
            "gruppen_vorlage": GRUPPEN,
            "zugzuteilungen": ZUGZUTEILUNGEN,
        }
    )
    return templates.TemplateResponse("helfer_neu.html", ctx)


@router.post("/neue-person")
async def neu_anlegen(request: Request, db: Session = Depends(get_db)):
    ctx = base_context(request, db)
    formular = await request.form()
    blatt = (formular.get("blatt") or "").strip()
    name = (formular.get("feld:Name") or "").strip()

    if blatt not in GRUPPENBLAETTER or not name:
        ctx.update({"titel": "Nicht angelegt",
                    "text": "Bitte geben Sie einen Namen an und wählen Sie eine Gruppe.",
                    "zurueck": "/neue-person"})
        return templates.TemplateResponse("meldung.html", ctx, status_code=400)

    datei = hole_helferdatei()
    spalten = datei.spalten(blatt)
    werte: dict[str, Zellwert] = {}
    for schluessel, eingabe in formular.items():
        if not schluessel.startswith("feld:"):
            continue
        spalte = schluessel[5:]
        if spalte in spalten and spalte != SPALTE_NR:
            wert = wert_aus_eingabe(spalte, str(eingabe))
            if wert is not None:
                werte[spalte] = wert

    try:
        schluessel = datei.lege_person_an(blatt, werte)
    except (DateiGesperrt, DateiVeraendert, ValueError) as fehler:
        ctx.update({"titel": "Nicht angelegt", "text": str(fehler),
                    "zurueck": "/neue-person"})
        return templates.TemplateResponse("meldung.html", ctx, status_code=409)

    vorschlag = trenne(name)
    zuteilung = (formular.get("zugzuteilung") or "").strip()
    db.add(
        models.Helferzusatz(
            blatt=blatt, name=name, vorname=vorschlag.vorname,
            nachname=vorschlag.nachname,
            zugzuteilung=zuteilung or STANDARD_ZUGZUTEILUNG,
        )
    )
    protokolliere(
        db,
        kuerzel_aus(request),
        [
            Aenderungssatz(
                blatt=blatt, zeile=schluessel.zeile, zelle="", spalte=spalte,
                name=name, alter_wert=None, neuer_wert=wert,
            )
            for spalte, wert in werte.items()
        ],
        aktion="person_angelegt",
    )
    db.commit()
    return RedirectResponse(
        f"/helfer/{schluessel.kennung}?meldung=Person angelegt.", status_code=302
    )


@router.post("/ausgliedern")
async def ausgliedern(request: Request, db: Session = Depends(get_db)):
    """Verschiebt eine Person in das Blatt der Ausgeschiedenen."""
    ctx = base_context(request, db)
    formular = await request.form()
    kennung = str(formular.get("kennung") or "")

    person, _ = _person_suchen(kennung)
    if person is None:
        ctx.update({"titel": "Person nicht gefunden",
                    "text": "Diese Person steht nicht mehr in der Datei."})
        return templates.TemplateResponse("meldung.html", ctx, status_code=404)

    austritt = wert_aus_eingabe("Austrittsdatum", str(formular.get("austrittsdatum") or ""))
    if not isinstance(austritt, date):
        austritt = date.today()

    try:
        ziel = hole_helferdatei().gliedere_aus(person.schluessel, austritt)
    except (DateiGesperrt, ZeileVeraendert, DateiVeraendert) as fehler:
        ctx.update({"titel": "Nicht ausgegliedert", "text": str(fehler),
                    "zurueck": f"/helfer/{person.schluessel.kennung}"})
        return templates.TemplateResponse("meldung.html", ctx, status_code=409)

    protokolliere(
        db, kuerzel_aus(request),
        [Aenderungssatz(blatt=person.blatt, zeile=person.schluessel.zeile, zelle="",
                        spalte="Austritt", name=person.name, alter_wert=person.blatt,
                        neuer_wert=f"{ziel.blatt} ({austritt.strftime('%d.%m.%Y')})")],
        aktion="ausgegliedert",
    )
    db.commit()
    return RedirectResponse(
        f"/ausgeschieden?meldung={person.name} wurde ausgegliedert.", status_code=302
    )


@router.get("/ausgeschieden")
def ausgeschiedene(request: Request, db: Session = Depends(get_db), meldung: str = ""):
    """Alle, die die Ortsgruppe verlassen haben - eigenes Blatt der Datei."""
    ctx = base_context(request, db)
    datei = hole_helferdatei()
    if not datei.ist_erreichbar():
        return templates.TemplateResponse("datei_fehlt.html", ctx)

    personen = datei.lade_ausgeschiedene()
    personen.sort(
        key=lambda p: (datum_aus(p.wert(SPALTE_AUSTRITT)) or date.min), reverse=True
    )
    ctx.update({
        "personen": personen,
        "spalte_austritt": SPALTE_AUSTRITT,
        "meldung": meldung,
    })
    return templates.TemplateResponse("ausgeschieden.html", ctx)


@router.post("/zurueckholen")
async def zurueckholen(request: Request, db: Session = Depends(get_db)):
    """Holt eine ausgeschiedene Person zurueck ins aktive Personal."""
    ctx = base_context(request, db)
    formular = await request.form()
    schluessel = Personenschluessel.aus_kennung(str(formular.get("kennung") or ""))

    try:
        ziel = hole_helferdatei().hole_zurueck(schluessel)
    except (DateiGesperrt, ZeileVeraendert, DateiVeraendert) as fehler:
        ctx.update({"titel": "Nicht zurückgeholt", "text": str(fehler),
                    "zurueck": "/ausgeschieden"})
        return templates.TemplateResponse("meldung.html", ctx, status_code=409)

    protokolliere(
        db, kuerzel_aus(request),
        [Aenderungssatz(blatt=ziel.blatt, zeile=ziel.zeile, zelle="",
                        spalte="Wiedereintritt", name=schluessel.name,
                        alter_wert=schluessel.blatt, neuer_wert=ziel.blatt)],
        aktion="zurueckgeholt",
    )
    db.commit()
    return RedirectResponse(
        f"/helfer/{ziel.kennung}?meldung={schluessel.name} ist wieder im aktiven Personal.",
        status_code=302,
    )
