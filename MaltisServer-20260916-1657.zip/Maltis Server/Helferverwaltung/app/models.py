"""Datenmodell der Anwendung.

Wichtig: hier stehen KEINE Personendaten. Der Bestand der Helferinnen und Helfer
lebt allein in der Excel-Datei. Gespeichert wird nur, was die Excel-Datei nicht
hergibt: das Aenderungsprotokoll, die wenigen Zusatzfelder und die
Einstellungen.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


def jetzt() -> datetime:
    return datetime.now()


class Helferzusatz(Base):
    """Felder zu einer Person, fuer die es in der Excel-Datei keine Spalte gibt.

    Schluessel ist (Blatt, Name) und nicht die Zeilennummer: Zeilen verschieben
    sich, wenn jemand direkt in Excel eine Zeile einfuegt oder loescht. Innerhalb
    eines Blattes sind die Namen eindeutig; ueber beide Blaetter hinweg kommt
    derselbe Name vor (Sven Marquardt), deshalb gehoert das Blatt zum Schluessel.
    """

    __tablename__ = "helferzusatz"
    __table_args__ = (UniqueConstraint("blatt", "name", name="uq_helferzusatz"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    blatt: Mapped[str] = mapped_column(String(30))
    name: Mapped[str] = mapped_column(String(120))

    vorname: Mapped[str | None] = mapped_column(String(80), default=None)
    nachname: Mapped[str | None] = mapped_column(String(80), default=None)
    # Behandlung | Sanitaet | Transport | Neuhelfer | None
    zugzuteilung: Mapped[str | None] = mapped_column(String(20), default=None)
    # True, sobald die Namenstrennung von Hand bestaetigt wurde.
    name_geprueft: Mapped[bool] = mapped_column(default=False)
    # Interne Bemerkung - steht nicht in der Excel-Datei.
    bemerkung: Mapped[str | None] = mapped_column(Text, default=None)


class Aenderung(Base):
    """Protokoll: wer hat wann welche Zelle von welchem auf welchen Wert gesetzt."""

    __tablename__ = "aenderungen"

    id: Mapped[int] = mapped_column(primary_key=True)
    zeitpunkt: Mapped[datetime] = mapped_column(default=jetzt)
    kuerzel: Mapped[str] = mapped_column(String(40))
    # feld_geaendert | person_angelegt | export_erzeugt
    aktion: Mapped[str] = mapped_column(String(20), default="feld_geaendert")
    blatt: Mapped[str] = mapped_column(String(30))
    zeile: Mapped[int] = mapped_column(default=0)
    zelle: Mapped[str] = mapped_column(String(12), default="")
    spalte: Mapped[str] = mapped_column(String(60), default="")
    name: Mapped[str] = mapped_column(String(120), default="")
    alter_wert: Mapped[str | None] = mapped_column(Text, default=None)
    neuer_wert: Mapped[str | None] = mapped_column(Text, default=None)


class Einstellung(Base):
    """Kleine Schluessel-Wert-Ablage fuer Zustaende der Anwendung."""

    __tablename__ = "einstellungen"

    schluessel: Mapped[str] = mapped_column(String(60), primary_key=True)
    wert: Mapped[str | None] = mapped_column(Text, default=None)


class SyncStatus(Base):
    """Einzeiliger Zustand der Synchronisation.

    Gilt fuer beide Modi: im lokalen Modus wird nur festgehalten, dass auf den
    Sync-Ordner gearbeitet wird; im SharePoint-Modus kommen Verbindungszustand,
    Zeitpunkt der letzten Synchronisierung und ausstehende (noch nicht
    hochgeladene) Aenderungen dazu.
    """

    __tablename__ = "sync_status"

    # Immer der gleiche Datensatz (id=1), damit es nur einen Zustand gibt.
    id: Mapped[int] = mapped_column(primary_key=True)
    # "lokal" | "sharepoint"
    modus: Mapped[str] = mapped_column(String(20), default="lokal")
    verbunden: Mapped[bool] = mapped_column(default=False)
    offline: Mapped[bool] = mapped_column(default=True)
    # Es gibt lokale Aenderungen, die noch nicht zu SharePoint hochgeladen wurden.
    ausstehende_aenderungen: Mapped[bool] = mapped_column(default=False)
    letzte_synchronisierung: Mapped[datetime | None] = mapped_column(
        DateTime, default=None
    )
    # Letzte verstaendliche Meldung, z.B. nach "Verbindung testen".
    letzte_meldung: Mapped[str] = mapped_column(Text, default="")
