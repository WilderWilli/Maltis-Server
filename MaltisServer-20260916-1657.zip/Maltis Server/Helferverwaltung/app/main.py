"""Zusammenbau der Anwendung."""

from __future__ import annotations

from fastapi import FastAPI, Form, Request
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.config import BASE_DIR, BENUTZER_COOKIE
from app.database import Base, engine, ergaenze_fehlende_spalten
from app.routes import dashboard, einstellungen, export, helfer, namen, protokoll, todos

Base.metadata.create_all(engine)

# Bestehende Datenbanken aus der Zeit vor dem Bemerkungsfeld bekommen die
# Spalte hier nachgeliefert - create_all legt nur Tabellen an, keine Spalten.
ergaenze_fehlende_spalten({"helferzusatz": (("bemerkung", "TEXT"),)})

app = FastAPI(title="Helferverwaltung Ortsgruppe", docs_url=None, redoc_url=None)
app.mount(
    "/static", StaticFiles(directory=str(BASE_DIR / "app" / "static")), name="static"
)

for modul in (dashboard, helfer, todos, namen, export, protokoll, einstellungen):
    app.include_router(modul.router)


@app.post("/anmelden")
def anmelden(request: Request, kuerzel: str = Form("")):
    """Kürzel merken - nur für das Änderungsprotokoll, kein Rechtesystem."""
    ziel = request.headers.get("referer") or "/"
    antwort = RedirectResponse(ziel, status_code=302)
    antwort.set_cookie(
        BENUTZER_COOKIE, kuerzel.strip()[:40], max_age=60 * 60 * 24 * 365,
        samesite="lax",
    )
    return antwort
