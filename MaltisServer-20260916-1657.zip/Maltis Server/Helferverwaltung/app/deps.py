"""Gemeinsame Bausteine der Routen: Templates, Grundkontext, kleine Helfer."""

from __future__ import annotations

from datetime import date, datetime

from fastapi import Request
from fastapi.templating import Jinja2Templates
from sqlalchemy import select
from sqlalchemy.orm import Session

from app import models
from app.config import BASE_DIR, BENUTZER_COOKIE
from app.dateizugriff import hole_helferdatei
from app.dateizugriff.graph import GraphHelferdatei, sync_status_holen
from app.dateizugriff.schema import Aenderungssatz, Person
from app.logic.export import Zusatzangaben

# Absoluter Pfad, damit die Anwendung nicht nur aus dem Projektordner startet.
templates = Jinja2Templates(directory=str(BASE_DIR / "app" / "templates"))


def _datum(wert, format: str = "%d.%m.%Y") -> str:
    if isinstance(wert, datetime):
        return wert.strftime(format)
    if isinstance(wert, date):
        return wert.strftime(format)
    return "" if wert is None else str(wert)


templates.env.filters["datum"] = _datum


def kuerzel_aus(request: Request) -> str:
    """Kürzel der angemeldeten Person - dient nur der Protokollierung."""
    return (request.cookies.get(BENUTZER_COOKIE) or "").strip()


def base_context(request: Request, db: Session) -> dict:
    datei = hole_helferdatei()
    gesperrt, meldung = (False, None)
    if datei.ist_erreichbar():
        gesperrt, meldung = datei.ist_gesperrt()

    status = sync_status_holen(db)
    verbunden = False
    if isinstance(datei, GraphHelferdatei):
        augenblick = datei.status_augenblick()
        status.modus = "sharepoint"
        status.verbunden = not augenblick["offline"]
        status.offline = augenblick["offline"]
        status.ausstehende_aenderungen = augenblick["ausstehend"]
        if augenblick["letzte_synchronisierung"]:
            status.letzte_synchronisierung = augenblick["letzte_synchronisierung"]
        verbunden = status.verbunden
    else:
        status.modus = "lokal"
        status.offline = False
        status.ausstehende_aenderungen = False
        verbunden = datei.ist_erreichbar()
        status.verbunden = verbunden

    return {
        "request": request,
        "kuerzel": kuerzel_aus(request),
        "datei_erreichbar": datei.ist_erreichbar(),
        "datei_pfad": str(datei.pfad),
        "datei_gesperrt": gesperrt,
        "sperr_meldung": meldung,
        "heute": date.today(),
        "sync": {
            "modus": status.modus,
            "modus_label": "SharePoint" if status.modus == "sharepoint" else "lokaler Ordner",
            "verbunden": verbunden,
            "offline": status.offline,
            "ausstehend": status.ausstehende_aenderungen,
            "letzte_synchronisierung": status.letzte_synchronisierung,
            "letzte_meldung": status.letzte_meldung or "",
        },
    }


def zusatz_verzeichnis(db: Session) -> dict[tuple[str, str], models.Helferzusatz]:
    """(Blatt, Name) -> Zusatzangaben der Anwendung."""
    return {
        (z.blatt, z.name): z
        for z in db.scalars(select(models.Helferzusatz)).all()
    }


def hole_zusatz(db: Session, person: Person) -> models.Helferzusatz:
    """Zusatzsatz einer Person, notfalls neu angelegt (noch ohne Commit)."""
    vorhanden = db.scalar(
        select(models.Helferzusatz).where(
            models.Helferzusatz.blatt == person.blatt,
            models.Helferzusatz.name == person.name,
        )
    )
    if vorhanden:
        return vorhanden
    neu = models.Helferzusatz(blatt=person.blatt, name=person.name)
    db.add(neu)
    return neu


def als_zusatzangaben(
    verzeichnis: dict[tuple[str, str], models.Helferzusatz]
) -> dict[tuple[str, str], Zusatzangaben]:
    return {
        schluessel: Zusatzangaben(
            vorname=eintrag.vorname or "",
            nachname=eintrag.nachname or "",
            zugzuteilung=eintrag.zugzuteilung or "",
        )
        for schluessel, eintrag in verzeichnis.items()
    }


def protokolliere(
    db: Session,
    kuerzel: str,
    saetze: list[Aenderungssatz],
    aktion: str = "feld_geaendert",
) -> None:
    """Schreibt jede geschriebene Zelle ins Protokoll."""
    for satz in saetze:
        db.add(
            models.Aenderung(
                kuerzel=kuerzel or "unbekannt",
                aktion=aktion,
                blatt=satz.blatt,
                zeile=satz.zeile,
                zelle=satz.zelle,
                spalte=satz.spalte,
                name=satz.name,
                alter_wert=_datum(satz.alter_wert) or None,
                neuer_wert=_datum(satz.neuer_wert) or None,
            )
        )
