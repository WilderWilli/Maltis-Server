"""Der gesamte Zugriff auf die fuehrende Excel-Datei.

Ausserhalb dieses Pakets wird openpyxl nirgends benutzt. Wer Personendaten
braucht, geht ueber ``hole_helferdatei()`` und bekommt die Dataclasses aus
``schema.py`` - keine Arbeitsmappen, keine Zellbezuege.

Heute steht dahinter der lokale Sync-Ordner (``sync_ordner.py``). Sobald die
App-Registrierung im Malteser-Tenant vorliegt, tritt an dieselbe Stelle eine
Graph-Implementierung (``graph.py``), ohne dass der Rest der Anwendung sich
aendert.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date
from pathlib import Path

from app.dateizugriff.schema import (
    Aenderungssatz,
    AmuEintrag,
    Person,
    Personenschluessel,
    Zellwert,
)


class Helferdatei(ABC):
    """Schmale Schnittstelle auf die fuehrende Datei."""

    @abstractmethod
    def ist_erreichbar(self) -> bool:
        """Liegt die Datei da, wo sie erwartet wird?"""

    @abstractmethod
    def ist_gesperrt(self) -> tuple[bool, str | None]:
        """(gesperrt, Erklaerung) - True, wenn die Datei gerade in Excel offen ist."""

    @abstractmethod
    def spalten(self, blatt: str) -> list[str]:
        """Die Spaltenueberschriften eines Gruppenblattes in ihrer Reihenfolge."""

    @abstractmethod
    def lade_personen(self) -> list[Person]:
        """Alle Personen beider Gruppenblaetter. Liest die Datei jedes Mal neu."""

    @abstractmethod
    def lade_ausgeschiedene(self) -> list[Person]:
        """Personal, das die Ortsgruppe verlassen hat (eigenes Blatt)."""

    @abstractmethod
    def lade_amu_katalog(self) -> list[AmuEintrag]:
        """Die Zeilen 1-5 des Blattes "AMU"."""

    @abstractmethod
    def speichere_person(
        self, schluessel: Personenschluessel, aenderungen: dict[str, Zellwert]
    ) -> list[Aenderungssatz]:
        """Schreibt nur die uebergebenen Felder und nur, wenn sie sich aendern."""

    @abstractmethod
    def lege_person_an(self, blatt: str, werte: dict[str, Zellwert]) -> Personenschluessel:
        """Haengt eine neue Zeile an ein Gruppenblatt an."""

    @abstractmethod
    def gliedere_aus(
        self, schluessel: Personenschluessel, austrittsdatum: date | None = None
    ) -> Personenschluessel:
        """Verschiebt eine Person zu den Ausgeschiedenen."""

    @abstractmethod
    def hole_zurueck(self, schluessel: Personenschluessel) -> Personenschluessel:
        """Holt eine ausgeschiedene Person zurueck ins aktive Personal."""

    @abstractmethod
    def schreibe_export(
        self, ueberschriften: list[str], zeilen: list[list[Zellwert]], ziel: Path
    ) -> Path:
        """Schreibt die Exportdatei fuer die PSA-Beauftragte."""


_graph_datei: "GraphHelferdatei | None" = None


def hole_helferdatei() -> Helferdatei:
    """Liefert die aktuell gueltige Implementierung.

    Mit ausgefuellter SharePoint-Konfiguration (``SHAREPOINT_AKTIV=1`` und
    Zugangsdaten in der .env) wird die Datei ueber Microsoft Graph abgeglichen;
    sonst arbeitet die Anwendung wie bisher gegen den lokalen Sync-Ordner.

    Die Graph-Implementierung haelt Zustand (Verbindung, ausstehende
    Aenderungen) und wird deshalb nur einmal je Prozess erzeugt.
    """
    global _graph_datei
    from app.config import (
        GRAPH_CLIENT_ID,
        GRAPH_CLIENT_SECRET,
        GRAPH_DATEI,
        GRAPH_LOKAL_ORDNER,
        GRAPH_ORDNER,
        GRAPH_SITE_ID,
        GRAPH_TENANT_ID,
        HELFERDATEI_PFAD,
        graf_aktiv,
    )
    from app.dateizugriff.graph import GraphClient, GraphHelferdatei
    from app.dateizugriff.sync_ordner import SyncOrdnerHelferdatei

    if graf_aktiv():
        if _graph_datei is None:
            _graph_datei = GraphHelferdatei(
                client=GraphClient(
                    tenant=GRAPH_TENANT_ID,
                    client_id=GRAPH_CLIENT_ID,
                    client_secret=GRAPH_CLIENT_SECRET,
                ),
                site_id=GRAPH_SITE_ID,
                pfad_in_bibliothek=f"{GRAPH_ORDNER}/{GRAPH_DATEI}",
                lokal=GRAPH_LOKAL_ORDNER / GRAPH_DATEI,
            )
        return _graph_datei
    return SyncOrdnerHelferdatei(HELFERDATEI_PFAD)


__all__ = [
    "Helferdatei",
    "hole_helferdatei",
    "Person",
    "Personenschluessel",
    "AmuEintrag",
    "Aenderungssatz",
]
