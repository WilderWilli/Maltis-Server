"""Wiederherstellung der Paketteile, die openpyxl beim Speichern verliert.

Eine XLSX-Datei ist ein ZIP-Paket aus vielen Einzelteilen. openpyxl liest nur die
Teile, die es versteht, und schreibt beim Speichern folglich auch nur diese zurueck.
Bei der fuehrenden Datei der Ortsgruppe betrifft das zwei Dinge, die nicht verloren
gehen duerfen:

  * ``customXml/*`` - die SharePoint-Metadaten (Inhaltstyp "Dokument"). Ohne sie
    verliert die Datei in der Dokumentbibliothek ihre Inhaltstyp-Bindung.
  * ``xl/printerSettings/*`` - die gespeicherten Druckeinstellungen. openpyxl
    behaelt zwar Ausrichtung und Skalierung, wirft aber den Verweis darauf weg.

Nicht wiederhergestellt werden Teile, die Excel selbst neu aufbaut:
``xl/calcChain.xml`` (Berechnungsreihenfolge) und ``xl/sharedStrings.xml``
(openpyxl legt Texte stattdessen direkt in den Blaettern ab).

Das Vertraulichkeitskennzeichen der Datei steht in ``docProps/custom.xml`` und
wird von openpyxl bereits selbst erhalten - hier ist nichts zu tun.
"""

from __future__ import annotations

import re
import shutil
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

# Praefixe der Teile, die zurueckgeholt werden.
WIEDERHERSTELLEN = ("customXml/", "xl/printerSettings/")

# Teile, die Excel selbst neu erzeugt - deren Fehlen ist unbedenklich.
SELBSTHEILEND = ("xl/calcChain.xml", "xl/sharedStrings.xml")

CT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
SHEET_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"

CUSTOM_XML_TYP = f"{R_NS}/customXml"
PRINTER_TYP = f"{R_NS}/printerSettings"


def _freie_id(vorhandene: set[str]) -> str:
    """Naechste rId, die noch nicht vergeben ist."""
    nummer = 1
    while f"rId{nummer}" in vorhandene:
        nummer += 1
    return f"rId{nummer}"


def _ergaenze_content_types(alt: bytes, neu: bytes, teile: list[str]) -> bytes:
    """Uebernimmt Override- und Default-Eintraege fuer die zurueckgeholten Teile."""
    baum_alt = ET.fromstring(alt)
    baum_neu = ET.fromstring(neu)

    vorhandene_overrides = {
        e.get("PartName") for e in baum_neu.findall(f"{{{CT_NS}}}Override")
    }
    vorhandene_defaults = {
        (e.get("Extension") or "").lower() for e in baum_neu.findall(f"{{{CT_NS}}}Default")
    }
    benoetigte_endungen = {Path(t).suffix.lstrip(".").lower() for t in teile}

    for eintrag in baum_alt:
        marke = eintrag.tag.split("}")[-1]
        if marke == "Override":
            teil = (eintrag.get("PartName") or "").lstrip("/")
            if teil in teile and eintrag.get("PartName") not in vorhandene_overrides:
                baum_neu.append(eintrag)
        elif marke == "Default":
            endung = (eintrag.get("Extension") or "").lower()
            if endung in benoetigte_endungen and endung not in vorhandene_defaults:
                baum_neu.append(eintrag)

    return ET.tostring(baum_neu, encoding="UTF-8", xml_declaration=True)


def _ergaenze_beziehungen(alt: bytes, neu: bytes, teile: list[str],
                          basis: str) -> tuple[bytes, dict[str, str]]:
    """Haengt fehlende Beziehungen an eine .rels-Datei an.

    Gibt die neue .rels-Datei zurueck sowie eine Zuordnung
    "Zielteil -> neu vergebene rId", damit der Aufrufer den Verweis im Blatt
    nachziehen kann.
    """
    baum_alt = ET.fromstring(alt) if alt else ET.Element(f"{{{REL_NS}}}Relationships")
    baum_neu = ET.fromstring(neu) if neu else ET.Element(f"{{{REL_NS}}}Relationships")

    vergeben = {e.get("Id") for e in baum_neu}
    schon_verlinkt = {
        _aufloesen(basis, e.get("Target", "")) for e in baum_neu
    }
    neue_ids: dict[str, str] = {}

    for eintrag in baum_alt:
        ziel = _aufloesen(basis, eintrag.get("Target", ""))
        if ziel not in teile or ziel in schon_verlinkt:
            continue
        kennung = _freie_id(vergeben)
        vergeben.add(kennung)
        ET.SubElement(
            baum_neu,
            f"{{{REL_NS}}}Relationship",
            {"Id": kennung, "Type": eintrag.get("Type"), "Target": eintrag.get("Target")},
        )
        neue_ids[ziel] = kennung

    return ET.tostring(baum_neu, encoding="UTF-8", xml_declaration=True), neue_ids


def _aufloesen(basis: str, ziel: str) -> str:
    """Rechnet ein relatives Beziehungsziel in einen Paketpfad um."""
    if ziel.startswith("/"):
        return ziel.lstrip("/")
    pfad = Path(basis) / ziel
    return str(Path(*_normalisieren(pfad.parts))).replace("\\", "/")


def _normalisieren(teile: tuple[str, ...]) -> list[str]:
    ergebnis: list[str] = []
    for teil in teile:
        if teil == "..":
            if ergebnis:
                ergebnis.pop()
        elif teil not in (".", ""):
            ergebnis.append(teil)
    return ergebnis


def _setze_pagesetup_verweis(blatt_xml: bytes, kennung: str) -> bytes:
    """Traegt den r:id-Verweis auf die Druckeinstellungen wieder ins Blatt ein."""
    text = blatt_xml.decode("utf-8")
    # Der Praefix muss am Wurzelelement haengen, damit er ueberall im Blatt gilt.
    # openpyxl deklariert ihn nur lokal an einzelnen Elementen (z.B. tableParts),
    # deshalb wird hier gezielt das <worksheet>-Element geprueft, nicht der Text.
    wurzel = re.search(r"<worksheet\b[^>]*>", text)
    if wurzel and "xmlns:r=" not in wurzel.group(0):
        ersetzt = wurzel.group(0)[:-1].rstrip() + f' xmlns:r="{R_NS}">'
        text = text[: wurzel.start()] + ersetzt + text[wurzel.end():]
    treffer = re.search(r"<pageSetup\b[^>]*?/?>", text)
    if not treffer:
        return text.encode("utf-8")
    marke = treffer.group(0)
    if "r:id=" in marke:
        return text.encode("utf-8")
    ersatz = marke.rstrip("/>").rstrip() + f' r:id="{kennung}"/>'
    return (text[: treffer.start()] + ersatz + text[treffer.end():]).encode("utf-8")


def fehlende_teile(original: Path, geschrieben: Path) -> list[str]:
    """Teile, die im Original stehen, in der geschriebenen Datei aber fehlen."""
    with zipfile.ZipFile(original) as z:
        alt = set(z.namelist())
    with zipfile.ZipFile(geschrieben) as z:
        neu = set(z.namelist())
    return sorted(t for t in alt - neu if t not in SELBSTHEILEND)


def stelle_paketteile_wieder_her(original: Path, geschrieben: Path) -> list[str]:
    """Holt die verlorenen Paketteile aus dem Original in die geschriebene Datei.

    Arbeitet ueber eine temporaere Datei und ersetzt ``geschrieben`` erst am Ende,
    damit bei einem Fehler keine halbe Datei stehen bleibt.

    Gibt die Liste der wiederhergestellten Teile zurueck.
    """
    with zipfile.ZipFile(original) as z:
        teile_alt = set(z.namelist())
    with zipfile.ZipFile(geschrieben) as z:
        teile_neu = set(z.namelist())

    zurueckzuholen = sorted(
        t for t in teile_alt - teile_neu if t.startswith(WIEDERHERSTELLEN)
    )
    if not zurueckzuholen:
        return []

    ziel = geschrieben.with_suffix(geschrieben.suffix + ".repariert")
    with zipfile.ZipFile(original) as quelle, zipfile.ZipFile(geschrieben) as gebaut:
        # 1. Content-Types ergaenzen
        content_types = _ergaenze_content_types(
            quelle.read("[Content_Types].xml"),
            gebaut.read("[Content_Types].xml"),
            zurueckzuholen,
        )

        # 2. Beziehungen der Arbeitsmappe (customXml haengt an der Mappe)
        mappen_rels, _ = _ergaenze_beziehungen(
            quelle.read("xl/_rels/workbook.xml.rels"),
            gebaut.read("xl/_rels/workbook.xml.rels"),
            zurueckzuholen,
            basis="xl",
        )

        # 3. Beziehungen je Blatt (Druckeinstellungen haengen am Blatt)
        blatt_rels: dict[str, bytes] = {}
        blatt_verweise: dict[str, str] = {}
        for name in teile_alt:
            if not re.fullmatch(r"xl/worksheets/_rels/sheet\d+\.xml\.rels", name):
                continue
            blattdatei = name.replace("_rels/", "").replace(".rels", "")
            vorhanden = gebaut.read(name) if name in teile_neu else b""
            neue_rels, neue_ids = _ergaenze_beziehungen(
                quelle.read(name), vorhanden, zurueckzuholen, basis="xl/worksheets"
            )
            if neue_ids:
                blatt_rels[name] = neue_rels
                for zielteil, kennung in neue_ids.items():
                    if zielteil.startswith("xl/printerSettings/"):
                        blatt_verweise[blattdatei] = kennung

        ersetzungen = {
            "[Content_Types].xml": content_types,
            "xl/_rels/workbook.xml.rels": mappen_rels,
            **blatt_rels,
        }
        for blattdatei, kennung in blatt_verweise.items():
            ersetzungen[blattdatei] = _setze_pagesetup_verweis(
                gebaut.read(blattdatei), kennung
            )

        with zipfile.ZipFile(ziel, "w", zipfile.ZIP_DEFLATED) as neu_datei:
            for eintrag in gebaut.infolist():
                inhalt = ersetzungen.pop(eintrag.filename, None)
                neu_datei.writestr(eintrag, inhalt if inhalt is not None else gebaut.read(eintrag))
            for name, inhalt in ersetzungen.items():
                neu_datei.writestr(name, inhalt)
            for name in zurueckzuholen:
                neu_datei.writestr(name, quelle.read(name))

    shutil.move(str(ziel), str(geschrieben))
    return zurueckzuholen
