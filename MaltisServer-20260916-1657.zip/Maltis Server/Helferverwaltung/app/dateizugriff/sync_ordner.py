"""Zugriff auf die fuehrende Datei im lokalen Sync-Ordner.

Die einzige Stelle der Anwendung, an der openpyxl vorkommt (neben ``paket.py``,
das die Paketteile repariert).

Beim Schreiben gilt durchgaengig: erst pruefen, dann sichern, dann schreiben -
und lieber gar nichts schreiben als etwas Halbes.
"""

from __future__ import annotations

import os
import re
import shutil
from datetime import date, datetime
from pathlib import Path

import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from app.config import (
    BLATT_AMU,
    BLATT_AUSGESCHIEDEN,
    BLATT_GRUPPE_1,
    GRUPPENBLAETTER,
    MAX_SICHERUNGEN,
    SICHERUNGS_ORDNER,
)
from app.dateizugriff import Helferdatei
from app.dateizugriff.paket import stelle_paketteile_wieder_her
from app.dateizugriff.schema import (
    SPALTE_AUSTRITT,
    SPALTE_NAME,
    SPALTE_NR,
    Aenderungssatz,
    AmuEintrag,
    DateiGesperrt,
    DateiVeraendert,
    Person,
    Personenschluessel,
    ZeileVeraendert,
    Zellwert,
)

# Zeile, in der die Datei ihre COUNTIF-Summen fuehrt. Ab hier stehen keine
# Personen mehr, sondern Notizen.
ENDE_MARKE = "fehlsumme"

DATUMSFORMAT = "TT.MM.JJJJ"
_DATUMSZEICHEN = re.compile(r"(d{1,4}|m{1,5}|y{2,4}|t{1,4}|j{2,4})", re.IGNORECASE)


def _ist_datumsformat(format_code: str | None) -> bool:
    """Zeigt die Zelle bereits ein Datum an?"""
    if not format_code or format_code.lower() in ("general", "@"):
        return False
    # Waehrungs- und Prozentformate enthalten kein Datumsmuster.
    ohne_text = re.sub(r'"[^"]*"', "", format_code)
    return bool(_DATUMSZEICHEN.search(ohne_text))


def _als_wert(roh) -> Zellwert:
    """Zellinhalt in einen Wert der Anwendung umsetzen - ohne zu vereinheitlichen."""
    if isinstance(roh, datetime):
        return roh.date()
    return roh


def _vergleichbar(wert: Zellwert) -> str:
    """Normalisierte Fassung fuer den Vergleich - nie fuer das Schreiben."""
    if wert is None:
        return ""
    if isinstance(wert, datetime):
        wert = wert.date()
    if isinstance(wert, date):
        return wert.isoformat()
    if isinstance(wert, float) and wert.is_integer():
        return str(int(wert))
    return str(wert).strip()


class SyncOrdnerHelferdatei(Helferdatei):
    def __init__(self, pfad: Path) -> None:
        self.pfad = Path(pfad)

    # ------------------------------------------------------------------
    # Zustand
    # ------------------------------------------------------------------

    def ist_erreichbar(self) -> bool:
        return self.pfad.is_file()

    @property
    def sperrdatei(self) -> Path:
        return self.pfad.parent / f"~${self.pfad.name}"

    def ist_gesperrt(self) -> tuple[bool, str | None]:
        if self.sperrdatei.exists():
            return True, (
                f"Die Datei „{self.pfad.name}“ ist gerade in Excel geöffnet. "
                "Bitte schließen Sie sie und versuchen Sie es noch einmal."
            )
        return False, None

    # ------------------------------------------------------------------
    # Lesen
    # ------------------------------------------------------------------

    def _mappe(self, *, nur_lesen: bool = True):
        return openpyxl.load_workbook(self.pfad, data_only=False, read_only=nur_lesen)

    @staticmethod
    def _ueberschriften(blatt: Worksheet) -> list[str]:
        ueberschriften: list[str] = []
        for zelle in next(blatt.iter_rows(min_row=1, max_row=1)):
            wert = zelle.value
            ueberschriften.append(str(wert) if wert is not None else "")
        while ueberschriften and not ueberschriften[-1]:
            ueberschriften.pop()
        return ueberschriften

    def spalten(self, blatt: str) -> list[str]:
        mappe = self._mappe()
        try:
            return self._ueberschriften(mappe[blatt])
        finally:
            mappe.close()

    @classmethod
    def _personen_aus_blatt(cls, mappe, blattname: str) -> list[Person]:
        if blattname not in mappe.sheetnames:
            return []
        blatt = mappe[blattname]
        ueberschriften = cls._ueberschriften(blatt)
        if SPALTE_NAME not in ueberschriften:
            return []
        name_index = ueberschriften.index(SPALTE_NAME)

        personen: list[Person] = []
        for zeilennummer, zeile in enumerate(
            blatt.iter_rows(min_row=2, values_only=True), start=2
        ):
            rohname = zeile[name_index] if name_index < len(zeile) else None
            name = str(rohname).strip() if rohname is not None else ""
            if name.lower() == ENDE_MARKE:
                break  # ab hier stehen nur noch Summen und Notizen
            if not name:
                continue
            werte = {
                ueberschrift: _als_wert(zeile[i]) if i < len(zeile) else None
                for i, ueberschrift in enumerate(ueberschriften)
                if ueberschrift
            }
            personen.append(
                Person(
                    schluessel=Personenschluessel(blattname, zeilennummer, name),
                    werte=werte,
                )
            )
        return personen

    def lade_personen(self) -> list[Person]:
        """Das aktive Personal. Ausgeschiedene stehen in einem eigenen Blatt."""
        mappe = self._mappe()
        try:
            return [
                person
                for blattname in GRUPPENBLAETTER
                for person in self._personen_aus_blatt(mappe, blattname)
            ]
        finally:
            mappe.close()

    def lade_ausgeschiedene(self) -> list[Person]:
        mappe = self._mappe()
        try:
            return self._personen_aus_blatt(mappe, BLATT_AUSGESCHIEDEN)
        finally:
            mappe.close()

    def lade_amu_katalog(self) -> list[AmuEintrag]:
        mappe = self._mappe()
        try:
            if BLATT_AMU not in mappe.sheetnames:
                return []
            blatt = mappe[BLATT_AMU]
            # Nur die Zeilen 1-5 sind der Katalog, alles darunter ist etwas anderes.
            zeilen = list(blatt.iter_rows(min_row=1, max_row=5, values_only=True))
            while len(zeilen) < 5:
                zeilen.append(())

            eintraege: list[AmuEintrag] = []
            spaltenzahl = max((len(z) for z in zeilen), default=0)
            for spalte in range(1, spaltenzahl):  # Spalte 0 ist die Zeilenbeschriftung
                def feld(zeile: int) -> str:
                    reihe = zeilen[zeile]
                    wert = reihe[spalte] if spalte < len(reihe) else None
                    return str(wert).strip() if wert is not None else ""

                abkuerzung = feld(0)
                if not abkuerzung:
                    continue
                eintraege.append(
                    AmuEintrag(
                        abkuerzung=abkuerzung,
                        bezeichnung=feld(1),
                        zielgruppe=feld(2),
                        turnus=feld(3),
                        freiwillig_roh=feld(4),
                    )
                )
            return eintraege
        finally:
            mappe.close()

    # ------------------------------------------------------------------
    # Schreiben
    # ------------------------------------------------------------------

    def _sicherung_anlegen(self) -> Path:
        SICHERUNGS_ORDNER.mkdir(parents=True, exist_ok=True)
        stempel = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        ziel = SICHERUNGS_ORDNER / f"{self.pfad.stem}_{stempel}{self.pfad.suffix}"
        zaehler = 1
        while ziel.exists():
            zaehler += 1
            ziel = SICHERUNGS_ORDNER / f"{self.pfad.stem}_{stempel}_{zaehler}{self.pfad.suffix}"
        shutil.copy2(self.pfad, ziel)
        self._alte_sicherungen_entfernen()
        return ziel

    def _alte_sicherungen_entfernen(self) -> None:
        sicherungen = sorted(
            SICHERUNGS_ORDNER.glob(f"{self.pfad.stem}_*{self.pfad.suffix}"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        for veraltet in sicherungen[MAX_SICHERUNGEN:]:
            veraltet.unlink(missing_ok=True)

    def _schreibe_mappe(self, mappe, stand: float) -> None:
        """Speichert die Mappe atomar und stellt die Paketteile wieder her."""
        vorlaeufig = self.pfad.with_name(f".{self.pfad.name}.neu")
        try:
            mappe.save(vorlaeufig)
            stelle_paketteile_wieder_her(self.pfad, vorlaeufig)

            # Letzte Kontrolle: hat jemand die Datei waehrenddessen angefasst?
            if self.pfad.stat().st_mtime != stand:
                raise DateiVeraendert(
                    "Die Datei wurde während des Speicherns von außen verändert. "
                    "Es wurde nichts geschrieben. Bitte laden Sie die Seite neu."
                )
            os.replace(vorlaeufig, self.pfad)
        finally:
            vorlaeufig.unlink(missing_ok=True)

    def _pruefe_bereit(self) -> float:
        gesperrt, meldung = self.ist_gesperrt()
        if gesperrt:
            raise DateiGesperrt(meldung)
        return self.pfad.stat().st_mtime

    @staticmethod
    def _setze_zelle(blatt: Worksheet, zeile: int, spalte: int, wert: Zellwert) -> None:
        zelle = blatt.cell(row=zeile, column=spalte)
        zelle.value = wert
        # Datumsformat nur setzen, wenn die Zelle noch keines hat - sonst zeigte
        # Excel eine Zahl. Bestehende Formate bleiben unangetastet.
        if isinstance(wert, date) and not _ist_datumsformat(zelle.number_format):
            zelle.number_format = DATUMSFORMAT

    def speichere_person(
        self, schluessel: Personenschluessel, aenderungen: dict[str, Zellwert]
    ) -> list[Aenderungssatz]:
        stand = self._pruefe_bereit()
        mappe = openpyxl.load_workbook(self.pfad, data_only=False)
        try:
            blatt = mappe[schluessel.blatt]
            ueberschriften = self._ueberschriften(blatt)
            name_spalte = ueberschriften.index(SPALTE_NAME) + 1

            vorhandener_name = blatt.cell(row=schluessel.zeile, column=name_spalte).value
            if str(vorhandener_name or "").strip() != schluessel.name:
                raise ZeileVeraendert(
                    f"In Zeile {schluessel.zeile} von „{schluessel.blatt}“ steht "
                    f"inzwischen „{str(vorhandener_name or '').strip() or '(leer)'}“ "
                    f"statt „{schluessel.name}“. Es wurde nichts geändert. "
                    "Bitte laden Sie die Seite neu."
                )

            saetze: list[Aenderungssatz] = []
            for spalte, neuer_wert in aenderungen.items():
                if spalte not in ueberschriften:
                    continue
                index = ueberschriften.index(spalte) + 1
                zelle = blatt.cell(row=schluessel.zeile, column=index)
                alter_wert = _als_wert(zelle.value)
                if _vergleichbar(alter_wert) == _vergleichbar(neuer_wert):
                    continue  # unveraenderte Felder werden nicht angefasst
                self._setze_zelle(blatt, schluessel.zeile, index, neuer_wert)
                saetze.append(
                    Aenderungssatz(
                        blatt=schluessel.blatt,
                        zeile=schluessel.zeile,
                        zelle=f"{get_column_letter(index)}{schluessel.zeile}",
                        spalte=spalte,
                        name=schluessel.name,
                        alter_wert=alter_wert,
                        neuer_wert=neuer_wert,
                    )
                )

            if not saetze:
                return []

            self._sicherung_anlegen()
            self._schreibe_mappe(mappe, stand)
            return saetze
        finally:
            mappe.close()

    def lege_person_an(self, blatt_name: str, werte: dict[str, Zellwert]) -> Personenschluessel:
        name = str(werte.get(SPALTE_NAME) or "").strip()
        if not name:
            raise ValueError("Ohne Namen kann keine Person angelegt werden.")

        stand = self._pruefe_bereit()
        mappe = openpyxl.load_workbook(self.pfad, data_only=False)
        try:
            blatt = mappe[blatt_name]
            ueberschriften = self._ueberschriften(blatt)
            name_spalte = ueberschriften.index(SPALTE_NAME) + 1

            letzte_person, summenzeile = self._zeilen_bestimmen(blatt, name_spalte)
            zielzeile = letzte_person + 1

            # Steht dort schon die Summenzeile, wird vorher Platz geschaffen.
            if summenzeile is not None and zielzeile >= summenzeile:
                blatt.insert_rows(zielzeile)

            if SPALTE_NR in ueberschriften and not werte.get(SPALTE_NR):
                werte = {**werte, SPALTE_NR: self._naechste_nummer(blatt, ueberschriften)}

            for spalte, wert in werte.items():
                if spalte not in ueberschriften or wert in (None, ""):
                    continue
                self._setze_zelle(blatt, zielzeile, ueberschriften.index(spalte) + 1, wert)

            self._erweitere_tabelle(blatt, zielzeile)
            self._sicherung_anlegen()
            self._schreibe_mappe(mappe, stand)
            return Personenschluessel(blatt_name, zielzeile, name)
        finally:
            mappe.close()

    @staticmethod
    def _zeilen_bestimmen(blatt: Worksheet, name_spalte: int) -> tuple[int, int | None]:
        """(letzte Personenzeile, Zeile der Fehlsumme oder None)."""
        letzte_person = 1
        for zeile in range(2, blatt.max_row + 1):
            wert = blatt.cell(row=zeile, column=name_spalte).value
            name = str(wert).strip() if wert is not None else ""
            if name.lower() == ENDE_MARKE:
                return letzte_person, zeile
            if name:
                letzte_person = zeile
        return letzte_person, None

    @staticmethod
    def _naechste_nummer(blatt: Worksheet, ueberschriften: list[str]) -> int:
        spalte = ueberschriften.index(SPALTE_NR) + 1
        groesste = 0
        for zeile in range(2, blatt.max_row + 1):
            wert = blatt.cell(row=zeile, column=spalte).value
            if isinstance(wert, (int, float)):
                groesste = max(groesste, int(wert))
        return groesste + 1

    @staticmethod
    def _erweitere_tabelle(blatt: Worksheet, zielzeile: int) -> None:
        """Zieht den Bereich der Excel-Tabelle ueber die neue Zeile."""
        for tabelle in getattr(blatt, "tables", {}).values():
            treffer = re.fullmatch(
                r"([A-Z]+)(\d+):([A-Z]+)(\d+)", str(tabelle.ref).upper()
            )
            if not treffer:
                continue
            von_spalte, von_zeile, bis_spalte, bis_zeile = treffer.groups()
            if int(von_zeile) != 1 or int(bis_zeile) >= zielzeile:
                continue
            tabelle.ref = f"{von_spalte}{von_zeile}:{bis_spalte}{zielzeile}"

    # ------------------------------------------------------------------
    # Aus- und wieder eingliedern
    # ------------------------------------------------------------------

    def _zeile_verschieben(
        self,
        mappe,
        von_blatt: str,
        zeile: int,
        nach_blatt: str,
        zusatz: dict[str, Zellwert],
    ) -> int:
        """Kopiert eine Personenzeile in ein anderes Blatt und loescht sie hier.

        Gibt die Zeilennummer im Zielblatt zurueck.
        """
        quelle = mappe[von_blatt]
        ziel = mappe[nach_blatt]
        kopf_quelle = self._ueberschriften(quelle)
        kopf_ziel = self._ueberschriften(ziel)
        name_spalte_ziel = kopf_ziel.index(SPALTE_NAME) + 1

        letzte, _ = self._zeilen_bestimmen(ziel, name_spalte_ziel)
        zielzeile = letzte + 1

        for spalte in kopf_quelle:
            if not spalte or spalte not in kopf_ziel:
                continue
            wert = quelle.cell(row=zeile, column=kopf_quelle.index(spalte) + 1).value
            if wert in (None, ""):
                continue
            zielzelle = ziel.cell(row=zielzeile, column=kopf_ziel.index(spalte) + 1)
            zielzelle.value = wert
            if isinstance(wert, (date, datetime)):
                zielzelle.number_format = DATUMSFORMAT

        for spalte, wert in zusatz.items():
            if spalte in kopf_ziel and wert is not None:
                zielzelle = ziel.cell(row=zielzeile, column=kopf_ziel.index(spalte) + 1)
                zielzelle.value = wert
                if isinstance(wert, (date, datetime)):
                    zielzelle.number_format = DATUMSFORMAT

        # Die Zeile im Herkunftsblatt entfernen; die Tabelle schrumpft mit.
        quelle.delete_rows(zeile)
        self._verkleinere_tabelle(quelle)
        return zielzeile

    @staticmethod
    def _verkleinere_tabelle(blatt: Worksheet) -> None:
        """Zieht den Tabellenbereich um eine Zeile zurueck."""
        for tabelle in getattr(blatt, "tables", {}).values():
            treffer = re.fullmatch(r"([A-Z]+)(\d+):([A-Z]+)(\d+)", str(tabelle.ref).upper())
            if not treffer:
                continue
            von_spalte, von_zeile, bis_spalte, bis_zeile = treffer.groups()
            neue_bis = max(int(von_zeile) + 1, int(bis_zeile) - 1)
            tabelle.ref = f"{von_spalte}{von_zeile}:{bis_spalte}{neue_bis}"

    def gliedere_aus(
        self, schluessel: Personenschluessel, austrittsdatum: date | None = None
    ) -> Personenschluessel:
        """Verschiebt eine Person in das Blatt der Ausgeschiedenen."""
        stand = self._pruefe_bereit()
        mappe = openpyxl.load_workbook(self.pfad, data_only=False)
        try:
            if BLATT_AUSGESCHIEDEN not in mappe.sheetnames:
                raise ZeileVeraendert(
                    f"Das Blatt „{BLATT_AUSGESCHIEDEN}“ fehlt in der Datei. "
                    "Bitte einmalig scripts/umstellen_eine_gruppe.py ausführen."
                )
            blatt = mappe[schluessel.blatt]
            kopf = self._ueberschriften(blatt)
            name_spalte = kopf.index(SPALTE_NAME) + 1
            vorhanden = blatt.cell(row=schluessel.zeile, column=name_spalte).value
            if str(vorhanden or "").strip() != schluessel.name:
                raise ZeileVeraendert(
                    f"In Zeile {schluessel.zeile} steht inzwischen "
                    f"„{str(vorhanden or '').strip() or '(leer)'}“ statt "
                    f"„{schluessel.name}“. Es wurde nichts verschoben."
                )

            self._sicherung_anlegen()
            zielzeile = self._zeile_verschieben(
                mappe,
                schluessel.blatt,
                schluessel.zeile,
                BLATT_AUSGESCHIEDEN,
                {SPALTE_AUSTRITT: austrittsdatum or date.today()},
            )
            self._schreibe_mappe(mappe, stand)
            return Personenschluessel(BLATT_AUSGESCHIEDEN, zielzeile, schluessel.name)
        finally:
            mappe.close()

    def hole_zurueck(self, schluessel: Personenschluessel) -> Personenschluessel:
        """Holt eine ausgeschiedene Person zurueck ins aktive Personal."""
        stand = self._pruefe_bereit()
        mappe = openpyxl.load_workbook(self.pfad, data_only=False)
        try:
            blatt = mappe[BLATT_AUSGESCHIEDEN]
            kopf = self._ueberschriften(blatt)
            name_spalte = kopf.index(SPALTE_NAME) + 1
            vorhanden = blatt.cell(row=schluessel.zeile, column=name_spalte).value
            if str(vorhanden or "").strip() != schluessel.name:
                raise ZeileVeraendert(
                    f"In Zeile {schluessel.zeile} des Blattes „{BLATT_AUSGESCHIEDEN}“ "
                    f"steht inzwischen jemand anderes. Es wurde nichts verschoben."
                )

            self._sicherung_anlegen()
            # Beim Zurueckholen wird das Austrittsdatum nicht mitgenommen.
            ziel = mappe[BLATT_GRUPPE_1]
            kopf_ziel = self._ueberschriften(ziel)
            letzte, summenzeile = self._zeilen_bestimmen(
                ziel, kopf_ziel.index(SPALTE_NAME) + 1
            )
            if summenzeile is not None and letzte + 1 >= summenzeile:
                ziel.insert_rows(letzte + 1)

            # Das Austrittsdatum wandert nicht mit: die Spalte gibt es im
            # aktiven Blatt nicht, und _zeile_verschieben kopiert nur Spalten,
            # die es in beiden Blaettern gibt.
            zielzeile = self._zeile_verschieben(
                mappe, BLATT_AUSGESCHIEDEN, schluessel.zeile, BLATT_GRUPPE_1, {}
            )
            self._erweitere_tabelle(ziel, zielzeile)
            self._schreibe_mappe(mappe, stand)
            return Personenschluessel(BLATT_GRUPPE_1, zielzeile, schluessel.name)
        finally:
            mappe.close()

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def schreibe_export(
        self, ueberschriften: list[str], zeilen: list[list[Zellwert]], ziel: Path
    ) -> Path:
        ziel.parent.mkdir(parents=True, exist_ok=True)
        mappe = openpyxl.Workbook()
        blatt = mappe.active
        blatt.title = "Tabelle1"
        blatt.append(ueberschriften)
        for zeile in zeilen:
            blatt.append(zeile)

        for reihe in blatt.iter_rows(min_row=2):
            for zelle in reihe:
                if isinstance(zelle.value, date):
                    zelle.number_format = DATUMSFORMAT

        blatt.freeze_panes = "A2"
        mappe.save(ziel)
        mappe.close()
        return ziel
