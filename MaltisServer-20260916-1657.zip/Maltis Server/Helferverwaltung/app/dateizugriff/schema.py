"""Aufbau der fuehrenden Excel-Datei und die Datentypen der Schnittstelle.

Die Spaltenueberschriften werden zur Laufzeit aus der Datei gelesen - sie sind
dort massgeblich. Die Listen hier dienen der Pruefung: weicht die Datei ab, soll
die Anwendung das melden und nicht stillschweigend raten.

Nach aussen gibt das Zugriffsmodul ausschliesslich die Dataclasses aus dieser
Datei heraus. Weder openpyxl-Objekte noch Zellbezuege verlassen das Modul, damit
die spaetere Umstellung auf Microsoft Graph den Rest der Anwendung nicht beruehrt.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from enum import Enum

# --------------------------------------------------------------------------
# Spalten der Gruppenblaetter
# --------------------------------------------------------------------------

# Achtung: "AMU Dok  in ARNO" enthaelt zwei Leerzeichen - so steht es in der
# Datei und so bleibt es.
#
# Seit der Umstellung im September 2026 (scripts/umstellen_eine_gruppe.py):
#   * das gesamte Personal steht in einem Blatt,
#   * "Eigene Kleidung / Dienstausweis" wurde zu "Eigene Dienstkleidung",
#     "Dienstausweis" kam als eigene Spalte dazu,
#   * "RS Fortbildung 2025" heisst jetzt "RS Fortbildung" und fuehrt ein Datum,
#   * "Status" und "Passiv seit" kamen dazu.
# Die drei neuen Spalten haengen hinten an, weil ein Einfuegen mitten in der
# Tabelle die bedingten Formatierungen und Tabellenbereiche verschoben haette.
ERWARTETE_SPALTEN: tuple[str, ...] = (
    "Nr", "Name", "Geburtsdatum", "Eintrittsdatum Gliederung", "Mitglied?",
    "Jahresgespräch", "Divera?", "Eigene Dienstkleidung", "Medizinisch",
    "RS Fortbildung", "Taktisch", "Führerschein", "Verpflichtung?",
    "Leistungserbringer", "Fahrzeugeinweisung GwSan", "Einweisung NTKW ZS",
    "Freigabeerklärungen", "G20", "G24", "G25", "G 26.1", "G 26.2", "G 26.3",
    "G 37", "G 41", "G 42", "BOKraft", "FeV 5/FeV 6", "Masern",
    "AMU Dok  in ARNO", "Freigaben abgeschlossen", "MGA 1", "MGA 2", "MGA 3",
    "MGA 4", "Präv 4 UE", "Präv 8 UE", "AV 15", "Funkunterweisung",
    "Führerschein2", "AV 21", "Unterweisung S/W-Rechte", "PSNV",
    "Allgemeiner KatS", "CBRN", "Betreuungshelfer", "Ausbilderblock B",
    "Sonstige", "Dienstausweis", "Status", "Passiv seit",
    "Telefon", "Fortbildungsstatus", "Welche Fortbildung",
    "GF", "Dienstkleidung Größe", "CBRN Kleidergröße",
)

SPALTE_NR = "Nr"
SPALTE_NAME = "Name"
SPALTE_DIENSTKLEIDUNG = "Eigene Dienstkleidung"
SPALTE_DIENSTAUSWEIS = "Dienstausweis"
SPALTE_RS_FORTBILDUNG = "RS Fortbildung"
SPALTE_STATUS = "Status"
SPALTE_PASSIV_SEIT = "Passiv seit"
SPALTE_AUSTRITT = "Austrittsdatum"
SPALTE_TELEFON = "Telefon"
SPALTE_FORTBILDUNG_STATUS = "Fortbildungsstatus"
SPALTE_FORTBILDUNG_WELCHE = "Welche Fortbildung"
SPALTE_JAHRESGESPRAECH = "Jahresgespräch"
SPALTE_UNTERWEISUNG_SW = "Unterweisung S/W-Rechte"
SPALTE_GF = "GF"
SPALTE_DIENSTKLEIDUNG_GROESSE = "Dienstkleidung Größe"
SPALTE_CBRN_GROESSE = "CBRN Kleidergröße"

GF_NIKLAS = "Niklas"
GF_NINO = "Nino"
GF_WERTE = (GF_NIKLAS, GF_NINO)

FORTBILDUNG_INTERESSE = "Interesse"
FORTBILDUNG_ANGEMELDET = "angemeldet"
FORTBILDUNG_STATUS_WERTE = (FORTBILDUNG_INTERESSE, FORTBILDUNG_ANGEMELDET)

STATUS_AKTIV = "aktiv"
STATUS_PASSIV = "passiv"
STATUS_WERTE = (STATUS_AKTIV, STATUS_PASSIV)

# Arbeitsmedizinische Untersuchungen.
# "G 26.3" und "Masern" stehen zwar im Blatt, haben aber keinen Eintrag im
# AMU-Katalog - sie werden ueberwacht, aber nie als fehlend gemeldet.
# "Schicht" gab es nur im frueheren Blatt "Gruppe 2" und war dort bei allen
# 13 Personen leer; die Spalte ist mit der Zusammenfuehrung entfallen.
AMU_SPALTEN: tuple[str, ...] = (
    "G20", "G24", "G25", "G 26.1", "G 26.2", "G 26.3", "G 37", "G 41", "G 42",
    "BOKraft", "FeV 5/FeV 6",
)

# Spalten, die eine Fortbildung oder Unterweisung abbilden und deshalb an den
# Fortbildungskatalog angebunden werden koennen.
FORTBILDUNGS_SPALTEN: tuple[str, ...] = (
    "MGA 1", "MGA 2", "MGA 3", "MGA 4", "Präv 4 UE", "Präv 8 UE", "AV 15",
    "Funkunterweisung", "Führerschein2", "AV 21", "Unterweisung S/W-Rechte",
    "PSNV", "Allgemeiner KatS", "CBRN", "Betreuungshelfer", "Ausbilderblock B",
)

# Was in der Uebersicht als "Qualifizierung" je Person angezeigt wird.
QUALIFIKATIONS_SPALTEN: tuple[str, ...] = (
    "MGA 1", "MGA 2", "MGA 3", "MGA 4", "Präv 4 UE", "Präv 8 UE", "AV 15",
    "AV 21", "Funkunterweisung", "Führerschein2",
    "PSNV", "Allgemeiner KatS", "CBRN", "Betreuungshelfer", "Ausbilderblock B",
    "Fahrzeugeinweisung GwSan", "Einweisung NTKW ZS",
)


class Feldart(str, Enum):
    """Wie ein Feld gelesen und angezeigt wird."""

    TEXT = "Text"
    ZAHL = "Zahl"
    DATUM = "Datum"
    JA_NEIN = "Ja/Nein"
    # Feste Auswahl, siehe AUSWAHLWERTE.
    AUSWAHL = "Auswahl"
    # In derselben Spalte kommen Datum, y/n und Freitext vor.
    GEMISCHT = "Gemischt"


# Feldarten je Spalte. Alles, was hier nicht steht, ist TEXT.
FELDARTEN: dict[str, Feldart] = {
    "Nr": Feldart.ZAHL,
    "Name": Feldart.TEXT,
    "Geburtsdatum": Feldart.DATUM,
    "Eintrittsdatum Gliederung": Feldart.DATUM,
    "Mitglied?": Feldart.TEXT,
    # Jaehrlich faellig, deshalb ein Datum - bis alles umgestellt ist steht dort
    # teils noch y/n.
    SPALTE_JAHRESGESPRAECH: Feldart.GEMISCHT,
    SPALTE_TELEFON: Feldart.TEXT,
    SPALTE_FORTBILDUNG_STATUS: Feldart.AUSWAHL,
    SPALTE_FORTBILDUNG_WELCHE: Feldart.TEXT,
    "Divera?": Feldart.JA_NEIN,
    SPALTE_DIENSTKLEIDUNG: Feldart.JA_NEIN,
    SPALTE_DIENSTAUSWEIS: Feldart.JA_NEIN,
    "Medizinisch": Feldart.TEXT,
    # Datum der letzten RS-Fortbildung; bis alle Eintraege umgestellt sind
    # steht dort teils noch Text ("HA", "angemeldet").
    SPALTE_RS_FORTBILDUNG: Feldart.GEMISCHT,
    SPALTE_STATUS: Feldart.AUSWAHL,
    SPALTE_PASSIV_SEIT: Feldart.DATUM,
    SPALTE_AUSTRITT: Feldart.DATUM,
    "Taktisch": Feldart.TEXT,
    "Führerschein": Feldart.TEXT,
    "Verpflichtung?": Feldart.GEMISCHT,
    "Leistungserbringer": Feldart.TEXT,
    "Fahrzeugeinweisung GwSan": Feldart.JA_NEIN,
    "Einweisung NTKW ZS": Feldart.JA_NEIN,
    "Freigabeerklärungen": Feldart.JA_NEIN,
    "Masern": Feldart.JA_NEIN,
    "AMU Dok  in ARNO": Feldart.JA_NEIN,
    "Freigaben abgeschlossen": Feldart.JA_NEIN,
    "Unterweisung S/W-Rechte": Feldart.GEMISCHT,
    "Sonstige": Feldart.TEXT,
    SPALTE_GF: Feldart.AUSWAHL,
    SPALTE_DIENSTKLEIDUNG_GROESSE: Feldart.TEXT,
    SPALTE_CBRN_GROESSE: Feldart.TEXT,
    **{spalte: Feldart.GEMISCHT for spalte in AMU_SPALTEN},
    **{
        spalte: Feldart.JA_NEIN
        for spalte in FORTBILDUNGS_SPALTEN
        if spalte not in ("Unterweisung S/W-Rechte",)
    },
}


# Feste Auswahlmoeglichkeiten je Spalte. Leer bleibt immer moeglich - das ist
# die Angabe "unbekannt".
AUSWAHLWERTE: dict[str, tuple[str, ...]] = {
    SPALTE_STATUS: STATUS_WERTE,
    SPALTE_FORTBILDUNG_STATUS: FORTBILDUNG_STATUS_WERTE,
    SPALTE_GF: GF_WERTE,
}


def feldart(spalte: str) -> Feldart:
    return FELDARTEN.get(spalte, Feldart.TEXT)


# --------------------------------------------------------------------------
# Datentypen der Schnittstelle
# --------------------------------------------------------------------------

Zellwert = str | int | float | date | None


@dataclass(frozen=True)
class Personenschluessel:
    """Verweist auf eine Zeile eines Gruppenblattes.

    ``name`` wird mitgefuehrt, damit vor dem Schreiben geprueft werden kann, ob
    in der Zielzeile immer noch dieselbe Person steht. Wurde in Excel
    zwischenzeitlich eine Zeile eingefuegt oder geloescht, faellt das dadurch auf,
    statt die falsche Person zu ueberschreiben.
    """

    blatt: str
    zeile: int
    name: str

    @property
    def kennung(self) -> str:
        """Stabile Kennung fuer Formulare und URLs."""
        return f"{self.blatt}|{self.zeile}|{self.name}"

    @classmethod
    def aus_kennung(cls, kennung: str) -> "Personenschluessel":
        blatt, zeile, name = kennung.split("|", 2)
        return cls(blatt=blatt, zeile=int(zeile), name=name)


@dataclass
class Person:
    """Eine Zeile eines Gruppenblattes als Rohwerte je Spaltenueberschrift."""

    schluessel: Personenschluessel
    werte: dict[str, Zellwert] = field(default_factory=dict)

    @property
    def name(self) -> str:
        return str(self.werte.get(SPALTE_NAME) or "").strip()

    @property
    def blatt(self) -> str:
        return self.schluessel.blatt

    def wert(self, spalte: str) -> Zellwert:
        return self.werte.get(spalte)


@dataclass
class AmuEintrag:
    """Eine Spalte des AMU-Katalogs (Zeilen 1-5 des Blattes "AMU")."""

    abkuerzung: str          # Zeile 1, z.B. "G 26.2"
    bezeichnung: str         # Zeile 2, z.B. "Atemschutz 2"
    zielgruppe: str          # Zeile 3, z.B. "alle" | "KF C" | "RS" | Personenname
    turnus: str              # Zeile 4 - Freitext, wird bewusst nicht ausgewertet
    freiwillig_roh: str      # Zeile 5, "y" | "n" | "ka"

    @property
    def ist_freiwillig(self) -> bool:
        return self.freiwillig_roh.strip().lower() == "y"


@dataclass
class Aenderungssatz:
    """Eine einzelne geschriebene Zelle - Grundlage des Protokolls."""

    blatt: str
    zeile: int
    zelle: str
    spalte: str
    name: str
    alter_wert: Zellwert
    neuer_wert: Zellwert


class DateiGesperrt(RuntimeError):
    """Die Datei ist gerade in Excel geoeffnet."""


class ZeileVeraendert(RuntimeError):
    """In der Zielzeile steht nicht mehr dieselbe Person."""


class DateiVeraendert(RuntimeError):
    """Die Datei wurde waehrend des Schreibens von aussen veraendert."""
