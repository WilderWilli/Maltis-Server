"""Anbindung an die fuehrende Excel-Datei in SharePoint ueber Microsoft Graph.

Die fuehrende Datei liegt in einer Documentbibliothek eines SharePoint-Sites
und wird als Ganzes heruntergeladen, in einer lokalen Arbeitskopie bearbeitet
und wieder hochgeladen. Die zellgenaue Verarbeitung mit openpyxl bleibt in
``sync_ordner.py`` - diese Datei kuemmert sich nur um OAuth, den Abgleich und
die Konflikterkennung.

So lange die Anwendung ohne App-Registrierung im Malteser-Tenant arbeitet
(``SHAREPOINT_AKTIV`` leer oder Zugangsdaten unvollstaendig), tritt der
lokale Sync-Ordner an die Stelle dieser Datei und es aendert sich fuer den
Rest der Anwendung nichts.

Konzepte:

* **Abholen** (pull): die Datei wird mit ihrem Momentanstand heruntergeladen.
  Schlaegt das fehl (Netz, Anmeldung), gilt der Offline-Fallback: die letzte
  lokale Arbeitskopie wird weiter benutzt und der Zustand entsprechend
  ausgewiesen.
* **Hochladen** (push): die lokale Arbeitskopie wird mit ``If-Match`` und dem
  beim Abholen gemerkten ``eTag`` zurueckgeschrieben. Antwortet SharePoint
  mit 412, hat jemand anderes zwischenzeitlich geschrieben - dann wird die
  frische Fassung zurueckgeholt und die Aenderung verworfen
  (``DateiVeraendert``).
* **Token**: Anmeldung per Client-Credentials; bei 401/403 wird das Token
  einmal bewusst neu besorgt und der Aufruf wiederholt, bevor ein
  Anmeldefehler gemeldet wird.
"""

from __future__ import annotations

import os
import urllib.parse
from datetime import datetime, timedelta
from pathlib import Path

import httpx
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app import models
from app.dateizugriff import Helferdatei
from app.dateizugriff.schema import (
    Aenderungssatz,
    AmuEintrag,
    DateiVeraendert,
    Person,
    Personenschluessel,
    Zellwert,
)
from app.dateizugriff.sync_ordner import SyncOrdnerHelferdatei


class GraphFehler(RuntimeError):
    """Ein Problem beim Abgleich mit Microsoft Graph."""


class GraphAuthFehler(GraphFehler):
    """Die Anmeldung bei Microsoft Graph ist fehlgeschlagen."""


class GraphNichtErreichbar(GraphFehler):
    """Microsoft Graph ist netzwerkseitig nicht erreichbar."""


def _fehlermeldung_aus(antwort: httpx.Response) -> str:
    """Verstaendliche Meldung aus einer fehlerhaften Graph-Antwort."""
    try:
        daten = antwort.json()
        fehler = daten.get("error") or {}
        meldung = fehler.get("message") or daten.get("message") or ""
    except ValueError:
        meldung = ""
    text = f"HTTP {antwort.status_code}"
    if meldung:
        text += f" – {meldung}"
    return text


class GraphClient:
    """OAuth2 (Client-Credentials) und die HTTP-Grundlagen auf Microsoft Graph.

    Ein transport-Objekt kann injiziert werden, damit die Tests ohne Netz
    laufen. ``token_vorbelegt`` ueberspringt den echten Token-Hol- und
    verhaelt sich wie ein bereits erworbenes Zugriffstoken.
    """

    TOKEN_URL = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
    BASIS_URL = "https://graph.microsoft.com/v1.0"

    def __init__(
        self,
        tenant: str = "",
        client_id: str = "",
        client_secret: str = "",
        transport: httpx.BaseTransport | None = None,
        timeout: float = 20.0,
        token_vorbelegt: str | None = None,
    ) -> None:
        self.tenant = tenant
        self.client_id = client_id
        self.client_secret = client_secret
        self._client = httpx.Client(
            base_url=self.BASIS_URL, transport=transport, timeout=timeout
        )
        self._token: str | None = None
        self._token_gueltig_bis: datetime | None = None
        if token_vorbelegt:
            self._token = token_vorbelegt
            self._token_gueltig_bis = datetime.now() + timedelta(hours=1)

    def schliessen(self) -> None:
        self._client.close()

    # ------------------------------------------------------------------
    # Token
    # ------------------------------------------------------------------

    def _token_holen(self) -> str:
        """Besorgt ein frisches Zugriffstoken ueber den Token-Endpunkt."""
        try:
            antwort = self._client.post(
                self.TOKEN_URL.format(tenant=self.tenant),
                data={
                    "grant_type": "client_credentials",
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "scope": "https://graph.microsoft.com/.default",
                },
            )
        except httpx.RequestError as fehler:
            raise GraphNichtErreichbar(
                f"Token-Endpunkt nicht erreichbar: {fehler}"
            ) from fehler
        if antwort.status_code != 200:
            raise GraphAuthFehler(
                f"Anmeldung bei Microsoft fehlgeschlagen "
                f"({_fehlermeldung_aus(antwort)})."
            )
        daten = antwort.json()
        token = daten.get("access_token")
        if not token:
            raise GraphAuthFehler("Microsoft lieferte kein Zugriffstoken.")
        rest = int(daten.get("expires_in", 3600)) - 60
        self._token = token
        self._token_gueltig_bis = datetime.now() + timedelta(seconds=max(rest, 60))
        return token

    def _akteur_token(self) -> str:
        """Das aktuell gueltige Token; ein abgelaufenes wird neu besorgt."""
        if self._token and self._token_gueltig_bis and datetime.now() < self._token_gueltig_bis:
            return self._token
        self._token = None
        self._token_gueltig_bis = None
        return self._token_holen()

    # ------------------------------------------------------------------
    # Aufrufe
    # ------------------------------------------------------------------

    def _starte_aufruf(self, methode: str, url: str, **kwargs) -> httpx.Response:
        kopf = dict(kwargs.pop("headers", {}))
        kopf.setdefault("Authorization", f"Bearer {self._akteur_token()}")
        return self._client.request(methode, url, headers=kopf, **kwargs)

    def anfrage(self, methode: str, url: str, wiederholt: bool = False, **kwargs) -> httpx.Response:
        """Graph-Aufruf; bei 401/403 wird das Token einmal neu geholt."""
        try:
            antwort = self._starte_aufruf(methode, url, **kwargs)
        except httpx.RequestError as fehler:
            raise GraphNichtErreichbar(f"Ort nicht erreichbar: {fehler}") from fehler
        if antwort.status_code in (401, 403):
            if not wiederholt and self._token:
                # Vermutlich abgelaufenes oder widerrufenes Token: bewusst neu
                # besorgen und genau einmal erneut versuchen.
                self._token = None
                self._token_gueltig_bis = None
                return self.anfrage(methode, url, wiederholt=True, **kwargs)
            raise GraphAuthFehler(
                f"Microsoft Graph verweigert den Zugriff "
                f"({_fehlermeldung_aus(antwort)})."
            )
        return antwort

    @staticmethod
    def _erwarte_ok(antwort: httpx.Response, vorhaben: str) -> None:
        if antwort.status_code < 400:
            return
        raise GraphFehler(
            f"{vorhaben} fehlgeschlagen ({_fehlermeldung_aus(antwort)})."
        )

    # ------------------------------------------------------------------
    # Fachliche Aufrufe
    # ------------------------------------------------------------------

    def metadaten(self, url: str) -> dict:
        """Kopfdaten des Elements (Name, eTag, letzte Aenderung, Groesse)."""
        antwort = self.anfrage(
            "GET", url, params={"$select": "id,eTag,name,lastModifiedDateTime,size"}
        )
        self._erwarte_ok(antwort, "Kopfdaten von SharePoint")
        return antwort.json()

    def herunterladen(self, url: str) -> tuple[bytes, str | None]:
        """Lae dt den Dateiinhalt; liefert (Inhalt, eTag)."""
        antwort = self.anfrage("GET", url)
        self._erwarte_ok(antwort, "Herunterladen aus SharePoint")
        etag = str(antwort.headers.get("etag") or "")
        return antwort.content, etag or None

    def hochladen(self, url: str, inhalt: bytes, etag: str | None = None) -> str | None:
        """Schreibt den Inhalt zurueck, mit If-Match gegen den gemerkten Stand.

        Bei ``412 Precondition Failed`` hat jemand anderes zwischenzeitlich
        geschrieben: das wirft ``DateiVeraendert`` (Konflikterkennung).
        """
        kopf = {
            "Content-Type": (
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
        }
        if etag:
            kopf["If-Match"] = etag
        antwort = self.anfrage("PUT", url, content=inhalt, headers=kopf)
        if antwort.status_code == 412:
            raise DateiVeraendert(
                "Die Datei wurde in SharePoint zwischenzeitlich von jemand anderem "
                "geändert – genau das erkennt die Anwendung am eTag. Es wurde "
                "nichts überschrieben. Die frische Fassung ist jetzt geladen; "
                "bitte speichern Sie erneut."
            )
        self._erwarte_ok(antwort, "Hochladen nach SharePoint")
        etag = str(antwort.headers.get("etag") or "")
        return etag or None


class GraphHelferdatei(Helferdatei):
    """Die fuehrende Datei in SharePoint, bearbeitet ueber eine lokale Kopie.

    Alle Lese- und Schreibmethoden der Schnittstelle arbeiten auf der lokalen
    Arbeitskopie (``inner``); vor dem ersten Zugriff wird der neueste Stand
    aus SharePoint geholt. Schreibvorgaenge laden die frische Datei erst dann
    wieder und schreiben sie mit eTag-Konfliktpruefung zurueck.
    """

    def __init__(
        self,
        client: GraphClient,
        site_id: str,
        pfad_in_bibliothek: str,
        lokal: Path,
        start_synchronisierung: bool = True,
    ) -> None:
        self.client = client
        self.site_id = site_id
        self.pfad_in_bibliothek = pfad_in_bibliothek.strip("/")
        self.pfad = Path(lokal)
        self.start_synchronisierung = start_synchronisierung

        self.inner = SyncOrdnerHelferdatei(self.pfad)
        self._etag: str | None = None
        self._offline = False
        self._ausstehend = False
        self._gestartet = False
        self._letzte_sync: datetime | None = None
        self._letzte_meldung = ""

    # ------------------------------------------------------------------
    # Pfade und Status
    # ------------------------------------------------------------------

    @property
    def datei_name(self) -> str:
        return self.pfad_in_bibliothek.rsplit("/", 1)[-1]

    def _graph_relativ(self, zusatz: str = "") -> str:
        """URL-Pfad auf das Element, Graph-Syntax (root:/Pfad) bleibt erhalten.

        Ohne ``zusatz`` ist es der Elementpfad (``root:/Pfad``); mit ``zusatz``
        wird die Graph-Aktion angehaengt (``root:/Pfad:/content``).
        """
        segmente = [urllib.parse.quote(t, safe="") for t in self.pfad_in_bibliothek.split("/") if t]
        basis = f"/sites/{self.site_id}/drive/root:/{'/'.join(segmente)}"
        if not zusatz:
            return basis
        return f"{basis}:/{zusatz}"

    def status_augenblick(self) -> dict:
        """Der Zustand der laufenden Instanz fuer die Anzeige in der Oberflaeche."""
        return {
            "offline": self._offline,
            "ausstehend": self._ausstehend,
            "letzte_synchronisierung": self._letzte_sync,
            "letzte_meldung": self._letzte_meldung,
        }

    # ------------------------------------------------------------------
    # Abgleich
    # ------------------------------------------------------------------

    def _schreibe_lokal(self, inhalt: bytes) -> None:
        self.pfad.parent.mkdir(parents=True, exist_ok=True)
        vorlaeufig = self.pfad.with_name(f".{self.pfad.name}.neu")
        vorlaeufig.write_bytes(inhalt)
        os.replace(vorlaeufig, self.pfad)

    def abholen(self) -> bool:
        """Laedt den neuesten Stand aus SharePoint.

        True bei Erfolg; bei Netz-/Anmeldefehler wird der Offline-Fallback
        aktiviert (False) und die lokale Kopie bleibt der letzte bekannte Stand.
        """
        try:
            inhalt, etag = self.client.herunterladen(self._graph_relativ("content"))
        except GraphFehler as fehler:
            self._offline = True
            self._letzte_meldung = str(fehler)
            return False
        self._schreibe_lokal(inhalt)
        self._etag = etag
        self._offline = False
        self._letzte_sync = datetime.now()
        self._letzte_meldung = ""
        return True

    def _hochladen(self) -> bool:
        """Schreibt die lokale Kopie nach SharePoint; True bei Erfolg.

        ``DateiVeraendert`` (412) steigt durch - das ist kein Offline-Fall.
        Netz-/Anmeldefehler setzen den Offline-Fallback und liefern False, die
        Aenderung bleibt dann lokal liegen.
        """
        try:
            inhalt = self.pfad.read_bytes()
        except OSError as fehler:
            self._letzte_meldung = f"Lokale Kopie nicht lesbar: {fehler}"
            return False
        try:
            self._etag = self.client.hochladen(
                self._graph_relativ("content"), inhalt, self._etag
            )
        except (GraphNichtErreichbar, GraphAuthFehler) as fehler:
            self._offline = True
            self._letzte_meldung = str(fehler)
            return False
        self._offline = False
        self._letzte_sync = datetime.now()
        self._letzte_meldung = ""
        return True

    def _schreibe_danach(self) -> None:
        """Nach einem lokalen Schreibvorgang: hochladen und Zustand pflegen."""
        try:
            hochgeladen = self._hochladen()
        except DateiVeraendert:
            # Fremde Aenderung: frische Fassung holen, eigene Aenderungen zurueck.
            self.abholen()
            self._ausstehend = False
            raise
        self._ausstehend = not hochgeladen

    def _start_abgleich(self) -> None:
        """Holz den Stand beim ersten Zugriff - danach immer die lokale Kopie."""
        if not self._gestartet and self.start_synchronisierung:
            self._gestartet = True
            self.abholen()

    def synchronisiere_jetzt(self) -> str:
        """Erzwingt den Abgleich; liefert eine Meldung fuer die Oberflaeche."""
        self._gestartet = True
        if self._ausstehend:
            self.abholen()
            if self._offline:
                return (
                    "Die Verbindung schlägt fehl. Die Änderungen bleiben lokal "
                    "gespeichert und sind als „nicht hochgeladen“ markiert."
                )
            try:
                self._hochladen()
            except DateiVeraendert as fehler:
                return str(fehler)
            self._ausstehend = False
            return "Synchronisiert – auch die noch offenen Änderungen wurden hochgeladen."
        self.abholen()
        if self._offline:
            return (
                "Die Verbindung schlägt fehl. Es gilt weiterhin der letzte "
                "lokale Stand."
            )
        return "Stand aus SharePoint übernommen."

    def pruefe_verbindung(self) -> tuple[bool, str]:
        """Lebende Probe gegen SharePoint (ohne die lokale Kopie anzufassen)."""
        try:
            meta = self.client.metadaten(self._graph_relativ())
        except GraphFehler as fehler:
            self._offline = True
            self._letzte_meldung = str(fehler)
            return False, str(fehler)
        self._offline = False
        name = meta.get("name") or self.datei_name
        return True, f"Mit SharePoint verbunden. Datei „{name}“ gefunden."

    # ------------------------------------------------------------------
    # Schnittstelle Helferdatei
    # ------------------------------------------------------------------

    def ist_erreichbar(self) -> bool:
        self._start_abgleich()
        return self.pfad.is_file()

    def ist_gesperrt(self) -> tuple[bool, str | None]:
        # In SharePoint gibt es keine lokale Sperrdatei. Gleichzeitige
        # Aenderungen werden stattdessen ueber das eTag beim Hochladen erkannt
        # (412 -> DateiVeraendert).
        return False, None

    def spalten(self, blatt: str) -> list[str]:
        self._start_abgleich()
        return self.inner.spalten(blatt)

    def lade_personen(self) -> list[Person]:
        self._start_abgleich()
        return self.inner.lade_personen()

    def lade_ausgeschiedene(self) -> list[Person]:
        self._start_abgleich()
        return self.inner.lade_ausgeschiedene()

    def lade_amu_katalog(self) -> list[AmuEintrag]:
        self._start_abgleich()
        return self.inner.lade_amu_katalog()

    def speichere_person(
        self, schluessel: Personenschluessel, aenderungen: dict[str, Zellwert]
    ) -> list[Aenderungssatz]:
        self._start_abgleich()
        saetze = self.inner.speichere_person(schluessel, aenderungen)
        if saetze:
            self._schreibe_danach()
        return saetze

    def lege_person_an(
        self, blatt: str, werte: dict[str, Zellwert]
    ) -> Personenschluessel:
        self._start_abgleich()
        ergebnis = self.inner.lege_person_an(blatt, werte)
        self._schreibe_danach()
        return ergebnis

    def gliedere_aus(
        self, schluessel: Personenschluessel, austrittsdatum=None
    ) -> Personenschluessel:
        self._start_abgleich()
        ergebnis = self.inner.gliedere_aus(schluessel, austrittsdatum)
        self._schreibe_danach()
        return ergebnis

    def hole_zurueck(self, schluessel: Personenschluessel) -> Personenschluessel:
        self._start_abgleich()
        ergebnis = self.inner.hole_zurueck(schluessel)
        self._schreibe_danach()
        return ergebnis

    def schreibe_export(
        self, ueberschriften: list[str], zeilen: list[list[Zellwert]], ziel: Path
    ) -> Path:
        # Der Export ist eine Wegwerf-Datei - er wird nicht hochgeladen.
        self._start_abgleich()
        return self.inner.schreibe_export(ueberschriften, zeilen, ziel)


# ---------------------------------------------------------------------------
# Zustand der Synchronisation (eine Zeile in der Datenbank)
# ---------------------------------------------------------------------------

def modus_aktuell() -> str:
    """Rechnet nach, ob die Anwendung gerade mit SharePoint arbeitet."""
    from app.config import graf_aktiv

    return "sharepoint" if graf_aktiv() else "lokal"


def sync_status_holen(db: Session) -> models.SyncStatus:
    """Der einzelne Statusdatensatz; wird bei Bedarf angelegt."""
    eintrag = db.get(models.SyncStatus, 1)
    if eintrag is not None:
        return eintrag
    neu = models.SyncStatus(
        id=1,
        modus=modus_aktuell(),
        offline=True,
        letzte_meldung="Es wurde noch keine Verbindung geprüft.",
    )
    db.add(neu)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        eintrag = db.get(models.SyncStatus, 1)
        if eintrag is not None:
            return eintrag
        raise
    return neu


def sync_status_aktualisieren(
    db: Session,
    *,
    modus: str | None = None,
    verbunden: bool | None = None,
    offline: bool | None = None,
    ausstehend: bool | None = None,
    letzte_synchronisierung: datetime | None = None,
    meldung: str | None = None,
) -> models.SyncStatus:
    """Schreibt die angegebenen Felder in den Statusdatensatz."""
    eintrag = sync_status_holen(db)
    if modus is not None:
        eintrag.modus = modus
    if verbunden is not None:
        eintrag.verbunden = verbunden
    if offline is not None:
        eintrag.offline = offline
    if ausstehend is not None:
        eintrag.ausstehende_aenderungen = ausstehend
    if letzte_synchronisierung is not None:
        eintrag.letzte_synchronisierung = letzte_synchronisierung
    if meldung is not None:
        eintrag.letzte_meldung = meldung
    db.commit()
    return eintrag


__all__ = [
    "GraphAuthFehler",
    "GraphClient",
    "GraphFehler",
    "GraphHelferdatei",
    "GraphNichtErreichbar",
    "modus_aktuell",
    "sync_status_aktualisieren",
    "sync_status_holen",
]