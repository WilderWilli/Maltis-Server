"""Zentrale Einstellungen der Anwendung.

Alles, was sich von Rechner zu Rechner unterscheidet, steht in der Datei .env
(Vorlage: .env.example). Alles, was fachlich festgelegt ist, steht hier.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from dotenv import load_dotenv


def _basis_ordner() -> Path:
    """Der Ordner des Anwendungscodes (Vorlagen, Statik).

    Nicht eingefroren ist es das Projektverzeichnis. Als Windows-Paket
    (PyInstaller, ``onedir``) liegt der Code samt Vorlagen und Statik in der
    Ablage ``_internal`` - genau dorthin zeigt ``sys._MEIPASS``. Der Rueckgriff
    auf ``__file__`` ergaebe dort denselben Pfad; ``sys._MEIPASS`` ist aber die
    dokumentierte, gegen Layout-Aenderungen von PyInstaller stabile Quelle.
    """
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", "")
        if meipass:
            return Path(meipass)
    return Path(__file__).resolve().parent.parent


BASE_DIR = _basis_ordner()

# Als Windows-Paket (PyInstaller) liegt der Programmcode in einem
# Unterordner "_internal", in den nicht geschrieben werden soll. Daten,
# Sicherungen und .env gehoeren dann neben die EXE, damit ein Tester sie
# sieht und das Ganze durch Loeschen des Ordners rueckstandslos verschwindet.
if getattr(sys, "frozen", False):
    PROGRAMM_DIR = Path(sys.executable).resolve().parent
else:
    PROGRAMM_DIR = BASE_DIR

DATA_DIR = PROGRAMM_DIR / "data"
DB_PATH = DATA_DIR / "helferverwaltung.db"

load_dotenv(PROGRAMM_DIR / ".env")


def _pfad(name: str, standard: Path) -> Path:
    wert = os.getenv(name, "").strip()
    return Path(wert).expanduser() if wert else standard


def _ja(name: str) -> bool:
    return os.getenv(name, "").strip().lower() in ("1", "true", "ja", "yes", "y")


# Die fuehrende Excel-Datei. Ohne .env wird gegen die Arbeitskopie gearbeitet -
# nie versehentlich gegen den echten Sync-Ordner.
HELFERDATEI_PFAD = _pfad(
    "HELFERDATEI_PFAD", DATA_DIR / "arbeitskopie" / "Personal_Bestandsaufnahme.xlsx"
)

# Ablage der erzeugten Export-Dateien fuer die PSA-Beauftragte.
EXPORT_ORDNER = _pfad("EXPORT_ORDNER", DATA_DIR / "export")

# ----------------------------------------------------------------------------
# SharePoint-Anbindung ueber Microsoft Graph (siehe
# app/dateizugriff/graph.py). Ohne ``SHAREPOINT_AKTIV=1`` arbeitet die
# Anwendung wie bisher mit dem lokalen Sync-Ordner; erst wenn die
# App-Registrierung im Malteser-Tenant vorliegt, wird umgestellt.
# ----------------------------------------------------------------------------
SHAREPOINT_AKTIV = _ja("SHAREPOINT_AKTIV")
GRAPH_TENANT_ID = os.getenv("GRAPH_TENANT_ID", "").strip()
GRAPH_CLIENT_ID = os.getenv("GRAPH_CLIENT_ID", "").strip()
# Zugriffsgeheimnis der App-Registrierung - gehoert ausschliesslich in die .env.
GRAPH_CLIENT_SECRET = os.getenv("GRAPH_CLIENT_SECRET", "").strip()
GRAPH_SITE_ID = os.getenv("GRAPH_SITE_ID", "").strip()
# Pfad der Datei innerhalb der Documentbibliothek (freigegebene Dokumente).
GRAPH_ORDNER = os.getenv("GRAPH_ORDNER", "Freigegebene Dokumente/Helfer - Bestand").strip()
GRAPH_DATEI = os.getenv("GRAPH_DATEI", "Personal_Bestandsaufnahme.xlsx").strip()
# Lokale Arbeitskopie, gegen die openpyxl arbeitet; der Abgleich mit
# SharePoint laeuft ueber diese Datei hinweg.
GRAPH_LOKAL_ORDNER = _pfad("GRAPH_LOKAL_ORDNER", DATA_DIR / "graph_kopie")

# Sicherungskopien liegen bewusst NICHT neben der fuehrenden Datei: laege der
# Ordner im SharePoint-Sync, wuerden 20 Kopien mit Gesundheitsdaten mit
# hochgeladen und wuerden die Dokumentbibliothek zumuellen.
SICHERUNGS_ORDNER = _pfad("SICHERUNGS_ORDNER", DATA_DIR / "sicherungen")
MAX_SICHERUNGEN = 20

# Wie lange vor dem eingetragenen Ablaufdatum eine arbeitsmedizinische
# Untersuchung im Dashboard gemeldet wird.
VORWARNUNG_MONATE = 3

# Blattnamen der fuehrenden Datei. Seit der Umstellung im September 2026 steht
# das gesamte Personal in einem Blatt; "Gruppe 2" ist leer und wird nicht mehr
# gelesen (siehe scripts/umstellen_eine_gruppe.py).
BLATT_GRUPPE_1 = "Gruppe 1"
BLATT_AUSGESCHIEDEN = "Ausgeschieden"
BLATT_AMU = "AMU"
GRUPPENBLAETTER = (BLATT_GRUPPE_1,)

# Kuerzel der angemeldeten Person (nur zur Protokollierung, kein Rechtesystem).
BENUTZER_COOKIE = "helferverwaltung_kuerzel"

DATA_DIR.mkdir(parents=True, exist_ok=True)


def graph_konfiguriert() -> str | None:
    """Fehlermeldung, wenn die SharePoint-Anbindung unvollstaendig ist."""
    fehlt = [
        name
        for name, wert in (
            ("GRAPH_TENANT_ID", GRAPH_TENANT_ID),
            ("GRAPH_CLIENT_ID", GRAPH_CLIENT_ID),
            ("GRAPH_CLIENT_SECRET", GRAPH_CLIENT_SECRET),
            ("GRAPH_SITE_ID", GRAPH_SITE_ID),
        )
        if not wert
    ]
    if fehlt:
        return "Es fehlen in der .env: " + ", ".join(fehlt) + "."
    return None


def graf_aktiv() -> bool:
    """Nutzt die Anwendung die SharePoint-Anbindung anstatt des Sync-Ordners?"""
    return SHAREPOINT_AKTIV and graph_konfiguriert() is None
