@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo.
echo    +--------------------------------------------+
echo    ^|          H E L F E R V E R W A L T U N G   ^|
echo    ^|             Ortsgruppe - Malteser          ^|
echo    +--------------------------------------------+
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo FEHLER: Python ist nicht installiert.
  echo Bitte von python.org installieren, dabei "Add Python to PATH" ankreuzen.
  pause
  exit /b 1
)

if not exist ".venv" (
  echo Richte die Arbeitsumgebung ein ^(dauert beim ersten Mal ein paar Minuten^)...
  python -m venv .venv
)

.venv\Scripts\python.exe -c "import fastapi" >nul 2>&1
if errorlevel 1 (
  echo Installiere die benoetigten Bausteine...
  .venv\Scripts\pip.exe install --quiet --disable-pip-version-check -r requirements.txt
)

if not exist ".env" (
  echo Lege die Einstellungsdatei .env an ^(aus .env.example^).
  copy ".env.example" ".env" >nul
)

echo.
echo Die Anwendung laeuft gleich unter:  http://127.0.0.1:8001
echo Dieses Fenster bitte offen lassen. Zum Beenden: Strg + C
echo.

start "" http://127.0.0.1:8001
.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8001
pause
