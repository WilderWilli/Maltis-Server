#!/usr/bin/env bash
# Startet die Helferverwaltung.
#
# Zum Starten gibt es drei Wege:
#   1. Doppelklick auf "Helferverwaltung" auf dem Schreibtisch
#      (angelegt mit ./schreibtisch_verknuepfung_anlegen.sh)
#   2. Doppelklick auf diese Datei - klappt nur, wenn der Dateimanager
#      Skripte ausfuehren darf. Unter COSMIC und GNOME tut er das nicht.
#   3. Im Terminal:  ./start.sh
cd "$(dirname "$0")"

fehler_anzeigen() {
  echo ""
  echo "-------------------------------------------------------------"
  echo " Es ist etwas schiefgegangen. Die Meldung steht oben."
  echo "-------------------------------------------------------------"
  echo ""
  read -r -p "Zum Schliessen die Eingabetaste druecken..."
  exit 1
}

echo ""
echo "   +--------------------------------------------+"
echo "   |          H E L F E R V E R W A L T U N G   |"
echo "   |             Ortsgruppe - Malteser          |"
echo "   +--------------------------------------------+"
echo ""

if ! command -v python3 >/dev/null 2>&1; then
  echo "FEHLER: Python 3 ist nicht installiert."
  echo "Bitte installieren und es noch einmal versuchen."
  fehler_anzeigen
fi

if [ ! -d .venv ]; then
  echo "Richte die Arbeitsumgebung ein (dauert beim ersten Mal ein paar Minuten)..."
  python3 -m venv .venv || fehler_anzeigen
fi

if ! .venv/bin/python -c "import fastapi" >/dev/null 2>&1; then
  echo "Installiere die benoetigten Bausteine..."
  .venv/bin/pip install --quiet --disable-pip-version-check -r requirements.txt || fehler_anzeigen
fi

if [ ! -f .env ]; then
  echo "Lege die Einstellungsdatei .env an (aus .env.example)."
  cp .env.example .env
fi

# Laeuft schon eine Anwendung auf dem Port? Dann nur den Browser oeffnen.
if (echo > /dev/tcp/127.0.0.1/8001) >/dev/null 2>&1; then
  echo "Die Helferverwaltung laeuft bereits."
  echo "Oeffne nur das Fenster im Browser: http://127.0.0.1:8001"
  (xdg-open http://127.0.0.1:8001 >/dev/null 2>&1 || true)
  sleep 2
  exit 0
fi

echo ""
echo "Die Anwendung laeuft gleich unter:  http://127.0.0.1:8001"
echo ""
echo "   Dieses Fenster bitte offen lassen."
echo "   Zum Beenden:  Strg + C  druecken oder das Fenster schliessen."
echo ""

( sleep 2; (xdg-open http://127.0.0.1:8001 >/dev/null 2>&1 || true) ) &

.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8001
ergebnis=$?

# 130 = Strg+C, 143 = Fenster geschlossen. Beides ist normales Beenden und
# soll keinen Fehlerhinweis erzeugen.
case $ergebnis in
  0|130|143) ;;
  *) fehler_anzeigen ;;
esac

echo ""
echo "Die Helferverwaltung wurde beendet."
sleep 1
