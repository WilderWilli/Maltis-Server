# Git Push – Diagnose und Lösung

## Befund (Stand: 16. September 2026)

| Prüfpunkt | Ergebnis |
|---|---|
| Remote `origin` | `https://github.com/WilderWilli/Maltis-Server.git` ✅ korrekt |
| Aktueller Branch | `main`, 5 Commits (Cycle 1–5) ✅ |
| Upstream-Tracking | **nicht konfiguriert** ⚠️ |
| `.gitmodules` | nicht vorhanden ✅ |
| `Backend` | leerer Datei-Stub (100644), kein Submodule/gitlink ✅ unproblematisch |
| Hooks | nur `.sample`-Dateien, keine aktiven ✅ |
| Arbeitsverzeichnis | sauber, nichts zu committen ✅ |
| **Push-Ergebnis** | `fatal: could not read Username for 'https://github.com': terminal prompts disabled` |

### Kernursache

Das System hat **keine GitHub-Anmeldedaten**:

- Kein `credential.helper` (weder lokal noch global)
- Keine Umgebungsvariablen `GITHUB_TOKEN` oder `GH_TOKEN`
- `gh`-CLI nicht installiert
- SSH: `Host key verification failed` (kein `github.com` in `known_hosts`)

Der lokalen Repository-Zustand ist einwandfrei. Das Problem ist rein die fehlende Authentifizierung.

---

## Schritt-für-Schritt-Lösung

Wähle **eine** der drei Methoden:

### Methode A – GitHub Personal Access Token (HTTPS, einfachste Lösung)

1. **Token erzeugen:**
   - GitHub → Einstellungen → Developer settings → Personal access tokens → Tokens (classic) → Generate new token
   - Berechtigungen: `repo` (voller Zugriff auf privates Repository) oder mindestens `public_repo` (nur wenn Repo public)
   - Ablaufdatum wählen; token wird nur einmal angezeigt

2. **Token in git Credential Store eintragen:**

   ```bash
   git config --global credential.helper store
   echo "https://<BENUTZERNAME>:<TOKEN>@github.com" > ~/.git-credentials
   chmod 600 ~/.git-credentials
   ```

   Oder ohne Store – bei jedem Push nachfragen (sicherer auf fremden Rechnern):
   ```bash
   git config --global credential.helper cache
   ```

3. **Pushen:**

   ```bash
   git push -u origin main
   ```

   Die Anmeldedaten werden beim ersten Push abgefragt (cache) bzw. automatisch
   aus `~/.git-credentials` gelesen (store).

### Methode B – SSH-Schlüssel (kein Token nötig)

1. **SSH-Schlüssel erzeugen** (falls noch keiner vorhanden):

   ```bash
   ssh-keygen -t ed25519 -C "deine@email.de"
   ```

2. **Öffentlichen Schlüssel in GitHub eintragen:**

   ```bash
   cat ~/.ssh/id_ed25519.pub
   ```

   GitHub → Einstellungen → SSH and GPG keys → New SSH key → Schlüssel einfügen

3. **GitHub Host-Key in `known_hosts` aufnehmen:**

   ```bash
   ssh-keyscan github.com >> ~/.ssh/known_hosts
   ```

4. **Remote-URL auf SSH umstellen:**

   ```bash
   git remote set-url origin git@github.com:WilderWilli/Maltis-Server.git
   ```

5. **Pushen:**

   ```bash
   git push -u origin main
   ```

### Methode C – gh CLI (bequemste Lösung)

1. **gh installieren:**

   ```bash
   # Ubuntu/Debian
   curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
   echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
   sudo apt update && sudo apt install gh
   ```

2. **Anmelden:**

   ```bash
   gh auth login
   ```

   Interaktiv: GitHub.com → HTTPS → Login with a web browser (oder token)

3. **Git-credential-helper automatisch konfigurieren:**

   ```bash
   gh auth setup-git
   ```

4. **Pushen:**

   ```bash
   git push -u origin main
   ```

---

## Upstream-Tracking einrichten

Nach dem ersten erfolgreichen Push mit `-u`:

```bash
git push -u origin main
```

wird `main` automatisch auf `origin/main` gesetzt. Prüfen mit:

```bash
git branch -vv
```

Erwartete Ausgabe:
```
* main 037484f [origin/main] Cycle 5: ...
```

Danach reicht `git push` ohne Argumente.

---

## Tags pushen

Es gibt aktuell keine Tags. Falls welche angelegt wurden:

```bash
git push origin --tags
```

---

## Häufige Fehler und Ursachen

| Fehler | Ursache |
|---|---|
| `could not read Username for 'https://github.com'` | Kein Token/GitHub-Login eingerichtet (← aktuelles Problem) |
| `Permission denied (publickey)` | SSH-Schlüssel nicht in GitHub hinterlegt oder nicht geladen |
| `Host key verification failed` | `github.com` fehlt in `~/.ssh/known_hosts` (→ `ssh-keyscan github.com >> ~/.ssh/known_hosts`) |
| `remote: Permission to WilderWilli/Maltis-Server.git denied` | Token hat keine Berechtigung für dieses Repository; prüfe Token-Bereich `repo` |
| `Updates were rejected because the remote contains work that you do not have locally` | Remote hat Commits, die lokal fehlen → `git pull --rebase origin main` zuerst |

---

## Repository-Status nach erfolgreichem Push

Der GitHub Actions Workflow `.github/workflows/build.yml` startet automatisch nach
jedem Push auf `main` und baut die Windows-EXE (Artifact `windows`).

Der Workflow:
- läuft auf `windows-latest`
- installiert Abhängigkeiten
- führt alle 145 Tests aus
- erzeugt Testdaten und Icon
- baut mit PyInstaller
- prüft gebündelte Ressourcen
- lädt das Paket als Artifact `windows` hoch

Ergebnis prüfen: GitHub → Repository → Actions → „Build Windows" → neuester Lauf.
