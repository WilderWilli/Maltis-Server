from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app import models
from app.database import get_db
from app.deps import base_context, current_user, templates
from app.logic.notify import benachrichtige_neue_nachbestellungen
from app.logic.quarter import aktuelles_quartal
from app.logic.quarterly_check import (
    artikel_entfernen,
    check_abschliessen,
    faellige_artikel,
    hole_oder_erstelle_check,
)
from app.logic.reorder import recompute_reorders

router = APIRouter()


@router.get("/quartalspruefung/{code}")
def quarterly_detail(code: str, request: Request, db: Session = Depends(get_db)):
    ctx = base_context(request, db)
    vehicle = db.query(models.Vehicle).filter_by(code=code).first()
    if vehicle is None:
        return RedirectResponse("/", status_code=302)

    check = hole_oder_erstelle_check(db, vehicle.id)
    faellige = faellige_artikel(db, vehicle.id)
    bereits_bearbeitet = {
        qci.stock_id
        for qci in db.query(models.QuarterlyCheckItem).filter_by(check_id=check.id).all()
    }
    offen = [s for s in faellige if s.id not in bereits_bearbeitet]
    jahr, quartal = aktuelles_quartal()

    ctx.update(
        {
            "vehicle": vehicle,
            "check": check,
            "offen": offen,
            "jahr": jahr,
            "quartal": quartal,
        }
    )
    return templates.TemplateResponse("quarterly.html", ctx)


@router.post("/quartalspruefung/{code}/entfernen/{stock_id}")
def remove_item(code: str, stock_id: int, request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if user is None:
        return RedirectResponse(f"/login?next=/quartalspruefung/{code}", status_code=302)

    vehicle = db.query(models.Vehicle).filter_by(code=code).first()
    stock = db.get(models.Stock, stock_id)
    if vehicle and stock:
        check = hole_oder_erstelle_check(db, vehicle.id)
        artikel_entfernen(db, check, stock, user.kuerzel)
        neue = recompute_reorders(db)
        benachrichtige_neue_nachbestellungen(db, neue)

    return RedirectResponse(f"/quartalspruefung/{code}", status_code=302)


@router.post("/quartalspruefung/{code}/abschliessen")
def complete_check(code: str, request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if user is None:
        return RedirectResponse(f"/login?next=/quartalspruefung/{code}", status_code=302)

    vehicle = db.query(models.Vehicle).filter_by(code=code).first()
    if vehicle:
        check = hole_oder_erstelle_check(db, vehicle.id)
        check_abschliessen(db, check, user.kuerzel)

    return RedirectResponse(f"/quartalspruefung/{code}", status_code=302)
