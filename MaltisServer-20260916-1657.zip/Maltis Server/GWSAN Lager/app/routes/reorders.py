import datetime as dt

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app import models
from app.database import get_db
from app.deps import base_context, current_user, templates

router = APIRouter()

GRUND_LABEL = {"fehlmenge": "Fehlmenge", "ablauf": "läuft bald ab"}
STATUS_LABEL = {"offen": "Offen", "bestellt": "Bestellt", "erledigt": "Erledigt"}


@router.get("/nachbestellungen")
def list_reorders(request: Request, status: str = "offen", db: Session = Depends(get_db)):
    ctx = base_context(request, db)

    q = db.query(models.Reorder)
    if status != "alle":
        q = q.filter_by(status=status)
    reorders = q.order_by(models.Reorder.erstellt_am.desc()).all()

    stock_lookup = {
        (s.vehicle_id, s.container_id, s.item_id): s
        for s in db.query(models.Stock).all()
    }
    zeilen = []
    for r in reorders:
        stock = stock_lookup.get((r.vehicle_id, r.container_id, r.item_id))
        zeilen.append(
            {
                "reorder": r,
                "ablauf_monat": stock.ablauf_monat if stock else None,
                "ablauf_jahr": stock.ablauf_jahr if stock else None,
            }
        )

    ctx.update(
        {
            "zeilen": zeilen,
            "status_filter": status,
            "grund_label": GRUND_LABEL,
            "status_label": STATUS_LABEL,
        }
    )
    return templates.TemplateResponse("reorders.html", ctx)


@router.post("/nachbestellungen/{reorder_id}/status")
def set_status(reorder_id: int, request: Request, status: str = Form(...), db: Session = Depends(get_db)):
    user = current_user(request, db)
    if user is None:
        return RedirectResponse("/login?next=/nachbestellungen", status_code=302)

    reorder = db.get(models.Reorder, reorder_id)
    if reorder and status in ("offen", "bestellt", "erledigt"):
        reorder.status = status
        reorder.erledigt_am = dt.datetime.now() if status == "erledigt" else None
        db.commit()

    return RedirectResponse(request.headers.get("referer", "/nachbestellungen"), status_code=302)
