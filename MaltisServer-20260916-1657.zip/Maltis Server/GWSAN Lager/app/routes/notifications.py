from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app import models
from app.database import get_db
from app.deps import base_context, current_user, templates

router = APIRouter()


@router.get("/benachrichtigungen")
def list_notifications(request: Request, db: Session = Depends(get_db)):
    ctx = base_context(request, db)
    user = ctx["current_user"]

    notifications = db.query(models.Notification).order_by(models.Notification.erstellt_am.desc()).all()
    gelesen_ids = set()
    if user:
        gelesen_ids = {
            r.notification_id
            for r in db.query(models.NotificationRead).filter_by(user_id=user.id).all()
        }
        neue_reads = [
            models.NotificationRead(notification_id=n.id, user_id=user.id)
            for n in notifications
            if n.id not in gelesen_ids
        ]
        db.add_all(neue_reads)
        db.commit()

    ctx.update({"notifications": notifications, "gelesen_ids": gelesen_ids})
    return templates.TemplateResponse("notifications.html", ctx)
