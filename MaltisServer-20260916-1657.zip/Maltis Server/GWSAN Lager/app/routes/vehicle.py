import datetime as dt

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app import models
from app.database import get_db
from app.deps import base_context, current_user, templates
from app.logic.notify import benachrichtige_neue_nachbestellungen
from app.logic.quarter import quartale_bis_ablauf
from app.logic.reorder import recompute_reorders
from app.logic.soll import alle_soll_fuer_vehicle

router = APIRouter()

BEREICHE = [
    ("fahrzeug", "Fahrzeug & Kisten"),
    ("EE1", "Rucksack EE1"),
    ("EE2", "Rucksack EE2"),
    ("EE3", "Rucksack EE3"),
    ("KK", "Rucksack Kinder"),
]


def _status(stock: models.Stock, soll_min: int, soll_max: int | None) -> str:
    if stock.ablauf_monat and stock.ablauf_jahr:
        q = quartale_bis_ablauf(stock.ablauf_monat, stock.ablauf_jahr)
        if q < 0:
            return "abgelaufen"
        if soll_min and stock.ist_menge < soll_min:
            return "fehlend"
        if q <= 3:
            return "bald_ablaufend"
    elif soll_min and stock.ist_menge < soll_min:
        return "fehlend"
    if soll_max is not None and stock.ist_menge < soll_max:
        return "auffuellen"
    return "ok"


def _container_sort_key(container: models.Container):
    code = container.code
    if code.startswith("K") and code[1:].isdigit():
        return (0, int(code[1:]))
    return (1, code)


@router.get("/fahrzeug/{code}")
def vehicle_detail(code: str, request: Request, bereich: str = "fahrzeug", db: Session = Depends(get_db)):
    ctx = base_context(request, db)
    vehicle = db.query(models.Vehicle).filter_by(code=code).first()
    if vehicle is None:
        return RedirectResponse("/", status_code=302)

    soll_map = alle_soll_fuer_vehicle(db, vehicle.id)
    containers = db.query(models.Container).filter_by(vehicle_id=vehicle.id).all()

    if bereich == "fahrzeug":
        relevant = [c for c in containers if c.kind in ("kfz", "kiste")]
    else:
        relevant = [c for c in containers if c.code == bereich]
    relevant.sort(key=_container_sort_key)

    gruppen = []
    for container in relevant:
        stocks = (
            db.query(models.Stock)
            .filter_by(vehicle_id=vehicle.id, container_id=container.id)
            .join(models.Item)
            .order_by(models.Item.name)
            .all()
        )
        zeilen = []
        for stock in stocks:
            soll_min, soll_max, ist_ausnahme = soll_map.get(
                (container.standard_code, stock.item_id), (0, None, False)
            )
            zeilen.append(
                {
                    "stock": stock,
                    "item": stock.item,
                    "soll_min": soll_min,
                    "soll_max": soll_max,
                    "ist_ausnahme": ist_ausnahme,
                    "status": _status(stock, soll_min, soll_max),
                }
            )
        if zeilen:
            gruppen.append({"container": container, "zeilen": zeilen})

    ctx.update(
        {
            "vehicle": vehicle,
            "bereiche": BEREICHE,
            "bereich": bereich,
            "gruppen": gruppen,
        }
    )
    return templates.TemplateResponse("vehicle.html", ctx)


@router.post("/fahrzeug/{code}/bestand/{stock_id}")
def update_stock(
    code: str,
    stock_id: int,
    request: Request,
    bereich: str = Form("fahrzeug"),
    ist_menge: int = Form(...),
    ablauf_monat: str = Form(""),
    ablauf_jahr: str = Form(""),
    db: Session = Depends(get_db),
):
    user = current_user(request, db)
    if user is None:
        return RedirectResponse(f"/login?next=/fahrzeug/{code}%3Fbereich%3D{bereich}", status_code=302)

    stock = db.get(models.Stock, stock_id)
    if stock is None:
        return RedirectResponse(f"/fahrzeug/{code}?bereich={bereich}", status_code=302)

    stock.ist_menge = max(ist_menge, 0)
    stock.ablauf_monat = int(ablauf_monat) if ablauf_monat.strip() else None
    stock.ablauf_jahr = int(ablauf_jahr) if ablauf_jahr.strip() else None
    stock.aktualisiert_am = dt.datetime.now()
    stock.aktualisiert_von = user.kuerzel
    db.commit()

    neue = recompute_reorders(db)
    benachrichtige_neue_nachbestellungen(db, neue)

    return RedirectResponse(f"/fahrzeug/{code}?bereich={bereich}", status_code=302)
