from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app import models
from app.database import get_db
from app.deps import USER_COOKIE, base_context, templates

router = APIRouter()


@router.get("/login")
def login_page(request: Request, next: str = "/", db: Session = Depends(get_db)):
    ctx = base_context(request, db)
    users = db.query(models.User).order_by(models.User.name).all()
    ctx.update({"users": users, "next": next})
    return templates.TemplateResponse("login.html", ctx)


@router.post("/login")
def login_submit(
    request: Request,
    next: str = Form("/"),
    kuerzel_bestehend: str = Form(""),
    name_neu: str = Form(""),
    kuerzel_neu: str = Form(""),
    db: Session = Depends(get_db),
):
    if kuerzel_bestehend.strip():
        kuerzel = kuerzel_bestehend.strip()
    elif name_neu.strip() and kuerzel_neu.strip():
        kuerzel = kuerzel_neu.strip().upper()[:10]
        existing = db.query(models.User).filter_by(kuerzel=kuerzel).first()
        if not existing:
            db.add(models.User(name=name_neu.strip(), kuerzel=kuerzel))
            db.commit()
    else:
        return RedirectResponse(f"/login?next={next}", status_code=302)

    response = RedirectResponse(next or "/", status_code=302)
    response.set_cookie(USER_COOKIE, kuerzel, max_age=60 * 60 * 24 * 365)
    return response


@router.post("/logout")
def logout(next: str = Form("/")):
    response = RedirectResponse(next or "/", status_code=302)
    response.delete_cookie(USER_COOKIE)
    return response
