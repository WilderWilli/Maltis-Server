from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app import models
from app.database import get_db
from app.deps import base_context, templates
from app.logic.bbk_reference import find_bbk_match
from app.logic.notify import benachrichtige_neue_nachbestellungen
from app.logic.reorder import recompute_reorders

router = APIRouter()


@router.get("/admin/datenpruefung")
def datenpruefung(request: Request, db: Session = Depends(get_db)):
    ctx = base_context(request, db)

    offene = (
        db.query(models.VehicleSollOverride)
        .filter_by(bestaetigt=False)
        .order_by(models.VehicleSollOverride.container_code)
        .all()
    )
    bestaetigte = (
        db.query(models.VehicleSollOverride)
        .filter_by(bestaetigt=True)
        .order_by(models.VehicleSollOverride.container_code)
        .all()
    )

    zeilen_offen = []
    for o in offene:
        standard = (
            db.query(models.StandardSoll)
            .filter_by(container_code=o.container_code, item_id=o.item_id)
            .first()
        )
        bbk = find_bbk_match(o.container_code, o.item.name)
        zeilen_offen.append({"override": o, "standard": standard, "bbk": bbk})

    ctx.update({"zeilen_offen": zeilen_offen, "bestaetigte": bestaetigte})
    return templates.TemplateResponse("admin_datenpruefung.html", ctx)


@router.post("/admin/datenpruefung/{override_id}/bestaetigen")
def bestaetigen(override_id: int, request: Request, db: Session = Depends(get_db)):
    override = db.get(models.VehicleSollOverride, override_id)
    if override:
        override.bestaetigt = True
        db.commit()
        neue = recompute_reorders(db)
        benachrichtige_neue_nachbestellungen(db, neue)
    return RedirectResponse("/admin/datenpruefung", status_code=302)


@router.post("/admin/datenpruefung/{override_id}/auf_standard")
def auf_standard_zuruecksetzen(override_id: int, request: Request, db: Session = Depends(get_db)):
    override = db.get(models.VehicleSollOverride, override_id)
    if override:
        db.delete(override)
        db.commit()
        neue = recompute_reorders(db)
        benachrichtige_neue_nachbestellungen(db, neue)
    return RedirectResponse("/admin/datenpruefung", status_code=302)


@router.post("/admin/datenpruefung/{override_id}/bearbeiten")
def bearbeiten(
    override_id: int,
    request: Request,
    soll_min: int = Form(...),
    soll_max: str = Form(""),
    db: Session = Depends(get_db),
):
    override = db.get(models.VehicleSollOverride, override_id)
    if override:
        override.soll_min = max(soll_min, 0)
        override.soll_max = int(soll_max) if soll_max.strip() else None
        override.bestaetigt = True
        db.commit()
        neue = recompute_reorders(db)
        benachrichtige_neue_nachbestellungen(db, neue)
    return RedirectResponse("/admin/datenpruefung", status_code=302)
