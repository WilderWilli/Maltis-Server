from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from app import models
from app.database import get_db
from app.deps import base_context, templates
from app.logic.quarter import quartale_bis_ablauf
from app.logic.soll import alle_soll_fuer_vehicle

router = APIRouter()


def vehicle_kennzahlen(db: Session, vehicle: models.Vehicle) -> dict:
    soll_map = alle_soll_fuer_vehicle(db, vehicle.id)
    containers = {c.id: c for c in db.query(models.Container).filter_by(vehicle_id=vehicle.id).all()}
    stocks = db.query(models.Stock).filter_by(vehicle_id=vehicle.id).all()

    fehlend = []
    bald_ablaufend = []
    for stock in stocks:
        container = containers.get(stock.container_id)
        if container is None:
            continue
        soll_min, soll_max, _ = soll_map.get((container.standard_code, stock.item_id), (0, None, False))
        if soll_min and stock.ist_menge < soll_min:
            fehlend.append((stock, container, soll_min, soll_max))
        if stock.ablauf_monat and stock.ablauf_jahr:
            q = quartale_bis_ablauf(stock.ablauf_monat, stock.ablauf_jahr)
            if q <= 3:
                bald_ablaufend.append((stock, container, q))

    offene_nachbestellungen = (
        db.query(models.Reorder).filter_by(vehicle_id=vehicle.id, status="offen").count()
    )

    return {
        "vehicle": vehicle,
        "fehlend_count": len(fehlend),
        "fehlend": fehlend,
        "bald_ablaufend_count": len(bald_ablaufend),
        "bald_ablaufend": bald_ablaufend,
        "offene_nachbestellungen": offene_nachbestellungen,
    }


@router.get("/")
def dashboard(request: Request, db: Session = Depends(get_db)):
    ctx = base_context(request, db)
    kennzahlen = [vehicle_kennzahlen(db, v) for v in ctx["vehicles"]]

    gesamt_fehlend = sum(k["fehlend_count"] for k in kennzahlen)
    gesamt_bald_ablaufend = sum(k["bald_ablaufend_count"] for k in kennzahlen)
    gesamt_offen = sum(k["offene_nachbestellungen"] for k in kennzahlen)

    ctx.update(
        {
            "kennzahlen": kennzahlen,
            "gesamt_fehlend": gesamt_fehlend,
            "gesamt_bald_ablaufend": gesamt_bald_ablaufend,
            "gesamt_offen": gesamt_offen,
        }
    )
    return templates.TemplateResponse("dashboard.html", ctx)
