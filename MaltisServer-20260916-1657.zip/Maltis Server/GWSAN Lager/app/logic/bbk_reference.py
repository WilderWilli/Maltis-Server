"""Lookup in der offiziellen BBK-Soll-Liste (aus dem Begleitheft-PDF extrahiert)
als zusaetzliche Referenz bei Soll-Abweichungen zwischen den 3 Fahrzeugen.

Wichtig: Nur eine Referenz/Tie-Breaker fuer die Datenpruefung, KEINE
automatisch uebernommene Wahrheit - das BBK-Dokument kann laut Nutzer
vereinzelt kleine Fehler enthalten.
"""

import difflib
import json
import re
from functools import lru_cache

from app.config import BASE_DIR

BBK_PATH = BASE_DIR / "data" / "bbk_reference.json"

K_CODE_RE = re.compile(r"K\s*(\d+)", re.IGNORECASE)


def _normalize(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", name.lower()).strip()


def _normalize_kisten(kiste_field: str | None) -> set[str]:
    if not kiste_field:
        return set()
    return {f"K{m.group(1)}" for m in K_CODE_RE.finditer(kiste_field)}


@lru_cache(maxsize=1)
def _load() -> list[dict]:
    if not BBK_PATH.exists():
        return []
    eintraege = json.loads(BBK_PATH.read_text(encoding="utf-8"))
    for e in eintraege:
        e["_norm"] = _normalize(e["artikel"])
        e["_kisten"] = _normalize_kisten(e.get("kiste"))
    return eintraege


def find_bbk_match(container_code: str, item_name: str, cutoff: float = 0.78) -> dict | None:
    """Bester Treffer in der BBK-Liste fuer einen Artikel, bevorzugt aus
    derselben Kiste. Gibt None zurueck, wenn nichts ausreichend Aehnliches
    gefunden wurde."""
    eintraege = _load()
    if not eintraege:
        return None

    ziel = _normalize(item_name)

    def beste_uebereinstimmung(kandidaten: list[dict]) -> dict | None:
        if not kandidaten:
            return None
        namen = [e["_norm"] for e in kandidaten]
        treffer = difflib.get_close_matches(ziel, namen, n=1, cutoff=cutoff)
        if not treffer:
            return None
        idx = namen.index(treffer[0])
        return kandidaten[idx]

    ist_kisten_code = bool(K_CODE_RE.fullmatch(container_code or ""))
    if ist_kisten_code:
        # Bei echten Kisten NUR innerhalb derselben Kiste vergleichen - sonst
        # entstehen falsche Treffer durch aehnlich klingende Artikel aus
        # ganz anderen Kapiteln (z.B. Rucksack statt Kiste).
        gleiche_kiste = [e for e in eintraege if container_code in e["_kisten"]]
        return beste_uebereinstimmung(gleiche_kiste)

    # Ruecksack-Artikel (EE/KK) haben in der BBK-Liste kein Kisten-Feld,
    # hier ist ein globaler Namensvergleich die einzige Option.
    return beste_uebereinstimmung(eintraege)
