"""Geführte Quartalsprüfung: abgelaufene Artikel je Fahrzeug erkennen und entfernen."""

import datetime as dt

from sqlalchemy.orm import Session

from app import models
from app.logic.quarter import aktuelles_quartal, quartale_bis_ablauf


def hole_oder_erstelle_check(db: Session, vehicle_id: int) -> models.QuarterlyCheck:
    jahr, quartal = aktuelles_quartal()
    check = (
        db.query(models.QuarterlyCheck)
        .filter_by(vehicle_id=vehicle_id, jahr=jahr, quartal=quartal)
        .first()
    )
    if check is None:
        check = models.QuarterlyCheck(vehicle_id=vehicle_id, jahr=jahr, quartal=quartal, status="offen")
        db.add(check)
        db.commit()
    return check


def faellige_artikel(db: Session, vehicle_id: int) -> list[models.Stock]:
    """Artikel, deren Ablaufquartal erreicht oder ueberschritten ist und die noch
    auf Lager sind (ist_menge > 0) - Kandidaten zum Entfernen bei der Quartalspruefung."""
    stocks = (
        db.query(models.Stock)
        .filter(models.Stock.vehicle_id == vehicle_id, models.Stock.ist_menge > 0)
        .filter(models.Stock.ablauf_monat.isnot(None), models.Stock.ablauf_jahr.isnot(None))
        .all()
    )
    return [s for s in stocks if quartale_bis_ablauf(s.ablauf_monat, s.ablauf_jahr) <= 0]


def artikel_entfernen(db: Session, check: models.QuarterlyCheck, stock: models.Stock, kuerzel: str, kommentar: str | None = None) -> None:
    alte_menge = stock.ist_menge
    stock.ist_menge = 0
    stock.aktualisiert_am = dt.datetime.now()
    stock.aktualisiert_von = kuerzel

    db.add(
        models.QuarterlyCheckItem(
            check_id=check.id,
            stock_id=stock.id,
            aktion="entfernt",
            alte_menge=alte_menge,
            neue_menge=0,
            kommentar=kommentar,
        )
    )
    if check.status == "offen" and check.gestartet_am is None:
        check.gestartet_von = kuerzel
        check.gestartet_am = dt.datetime.now()
    db.commit()


def check_abschliessen(db: Session, check: models.QuarterlyCheck, kuerzel: str) -> None:
    check.status = "abgeschlossen"
    check.abgeschlossen_von = kuerzel
    check.abgeschlossen_am = dt.datetime.now()
    db.commit()
