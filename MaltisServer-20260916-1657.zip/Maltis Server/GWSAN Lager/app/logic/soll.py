"""Ermittlung des effektiven Sollbestands: Fahrzeug-Ausnahme schlaegt Standard."""

from sqlalchemy.orm import Session

from app import models


def effektiver_soll(
    db: Session, vehicle_id: int, container_code: str, item_id: int
) -> tuple[int, int | None, bool]:
    """Gibt (soll_min, soll_max, ist_ausnahme) zurueck."""
    override = (
        db.query(models.VehicleSollOverride)
        .filter_by(vehicle_id=vehicle_id, container_code=container_code, item_id=item_id)
        .first()
    )
    if override:
        return override.soll_min, override.soll_max, True

    standard = (
        db.query(models.StandardSoll)
        .filter_by(container_code=container_code, item_id=item_id)
        .first()
    )
    if standard:
        return standard.soll_min, standard.soll_max, False

    return 0, None, False


def alle_soll_fuer_vehicle(db: Session, vehicle_id: int) -> dict[tuple[str, int], tuple[int, int | None, bool]]:
    """Baut eine Lookup-Map (container_code, item_id) -> (soll_min, soll_max, ist_ausnahme)
    fuer ein Fahrzeug in wenigen Queries statt N+1."""
    result: dict[tuple[str, int], tuple[int, int | None, bool]] = {}

    for s in db.query(models.StandardSoll).all():
        result[(s.container_code, s.item_id)] = (s.soll_min, s.soll_max, False)

    overrides = db.query(models.VehicleSollOverride).filter_by(vehicle_id=vehicle_id).all()
    for o in overrides:
        result[(o.container_code, o.item_id)] = (o.soll_min, o.soll_max, True)

    return result
