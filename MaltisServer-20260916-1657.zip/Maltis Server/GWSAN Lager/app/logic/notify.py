"""In-App-Benachrichtigungen und E-Mail-Digest fuer neue Nachbestellungen."""

import datetime as dt
import smtplib
from email.mime.text import MIMEText

from sqlalchemy.orm import Session

from app import config, models

GRUND_TEXT = {
    "fehlmenge": "Fehlmenge",
    "ablauf": "läuft bald ab",
}


def _artikel_zeile(db: Session, r: models.Reorder) -> str:
    item = db.get(models.Item, r.item_id)
    vehicle = db.get(models.Vehicle, r.vehicle_id)
    container = db.get(models.Container, r.container_id)
    grund = GRUND_TEXT.get(r.grund, r.grund)
    if r.grund == "ablauf":
        stock = (
            db.query(models.Stock)
            .filter_by(vehicle_id=r.vehicle_id, container_id=r.container_id, item_id=r.item_id)
            .first()
        )
        if stock and stock.ablauf_monat and stock.ablauf_jahr:
            grund = f"{grund} ({stock.ablauf_monat:02d}/{stock.ablauf_jahr})"
    return f"- {item.name} | {vehicle.name} / {container.name} | {grund} | Menge: {r.menge}"


def benachrichtige_neue_nachbestellungen(db: Session, neue_reorders: list[models.Reorder]) -> None:
    """Legt eine In-App-Benachrichtigung an und verschickt eine Digest-Mail,
    sofern konfiguriert. Idempotent: reorders die bereits eine E-Mail
    ausgeloest haben, werden nicht erneut gemailt."""
    if not neue_reorders:
        return

    zeilen = [_artikel_zeile(db, r) for r in neue_reorders]
    text = (
        f"{len(neue_reorders)} neue(r) Artikel zur Nachbestellung erkannt:\n\n"
        + "\n".join(zeilen)
    )

    notification = models.Notification(
        typ="nachbestellung",
        titel=f"{len(neue_reorders)} neue Nachbestellung(en)",
        text=text,
    )
    db.add(notification)
    db.commit()

    zu_mailen = [r for r in neue_reorders if r.email_gesendet_am is None]
    if zu_mailen and config.GMAIL_ADDRESS and config.GMAIL_APP_PASSWORD and config.NOTIFY_EMAIL_TO:
        betreff = f"GwSan Lager: {len(zu_mailen)} neue Nachbestellung(en)"
        koerper = (
            "Automatische Benachrichtigung der GwSan-Lagersoftware.\n\n"
            + "\n".join(_artikel_zeile(db, r) for r in zu_mailen)
        )
        try:
            _sende_mail(betreff, koerper)
        except Exception as exc:  # SMTP-Fehler sollen den Check nicht abbrechen
            print(f"[notify] E-Mail-Versand fehlgeschlagen: {exc}")
        else:
            jetzt = dt.datetime.now()
            for r in zu_mailen:
                r.email_gesendet_am = jetzt
            db.commit()


def _sende_mail(betreff: str, koerper: str) -> None:
    msg = MIMEText(koerper, _charset="utf-8")
    msg["Subject"] = betreff
    msg["From"] = config.GMAIL_ADDRESS
    msg["To"] = config.NOTIFY_EMAIL_TO

    with smtplib.SMTP("smtp.gmail.com", 587, timeout=20) as server:
        server.starttls()
        server.login(config.GMAIL_ADDRESS, config.GMAIL_APP_PASSWORD)
        server.sendmail(config.GMAIL_ADDRESS, [config.NOTIFY_EMAIL_TO], msg.as_string())
