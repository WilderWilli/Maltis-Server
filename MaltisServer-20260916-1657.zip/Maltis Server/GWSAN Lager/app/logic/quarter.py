"""Quartals-Arithmetik: Monat/Jahr <-> Quartal, sowie Vergleiche."""

import datetime as dt


def quartal_von_monat(monat: int) -> int:
    return ((monat - 1) // 3) + 1


def quartals_index(jahr: int, quartal: int) -> int:
    """Fortlaufender Quartalsindex zum Vergleichen (z.B. 2026/2 -> 8106)."""
    return jahr * 4 + quartal


def quartals_index_von_monat_jahr(monat: int, jahr: int) -> int:
    return quartals_index(jahr, quartal_von_monat(monat))


def aktuelles_quartal(heute: dt.date | None = None) -> tuple[int, int]:
    """Gibt (jahr, quartal) fuer das aktuelle Datum zurueck."""
    heute = heute or dt.date.today()
    return heute.year, quartal_von_monat(heute.month)


def quartale_bis_ablauf(ablauf_monat: int, ablauf_jahr: int, heute: dt.date | None = None) -> int:
    """Anzahl Quartale zwischen jetzt und dem Ablaufquartal (negativ = bereits abgelaufen)."""
    jahr, quartal = aktuelles_quartal(heute)
    return quartals_index_von_monat_jahr(ablauf_monat, ablauf_jahr) - quartals_index(jahr, quartal)


def formatiere_quartal(jahr: int, quartal: int) -> str:
    return f"{jahr}/{quartal}"
