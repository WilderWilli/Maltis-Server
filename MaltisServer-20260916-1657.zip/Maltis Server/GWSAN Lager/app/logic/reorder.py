"""Erkennung von Nachbestell-Bedarf: Fehlmenge und bald ablaufende Artikel.

Wird sowohl vom taeglichen Hintergrund-Job (in-app Scheduler und
scripts/daily_check.py) als auch nach manuellen Bestandsaenderungen aufgerufen.
"""

import datetime as dt

from sqlalchemy.orm import Session

from app import models
from app.config import REORDER_LEAD_QUARTERS
from app.logic.quarter import quartale_bis_ablauf
from app.logic.soll import alle_soll_fuer_vehicle


def _get_or_create_open(
    db: Session, vehicle_id: int, container_id: int, item_id: int, grund: str
) -> tuple[models.Reorder, bool]:
    existing = (
        db.query(models.Reorder)
        .filter_by(vehicle_id=vehicle_id, container_id=container_id, item_id=item_id, grund=grund, status="offen")
        .first()
    )
    if existing:
        return existing, False
    neu = models.Reorder(
        vehicle_id=vehicle_id,
        container_id=container_id,
        item_id=item_id,
        grund=grund,
        menge=0,
        status="offen",
    )
    db.add(neu)
    return neu, True


def recompute_reorders(db: Session) -> list[models.Reorder]:
    """Aktualisiert die Nachbestell-Liste anhand des aktuellen Bestands.

    Erzeugt neue offene Reorder-Eintraege, aktualisiert die Menge bestehender,
    und schliesst automatisch, was sich erledigt hat (aufgefuellt / Ablauf verschoben).
    Gibt die NEU erzeugten Eintraege zurueck (fuer Benachrichtigungen).
    """
    neu_erzeugt: list[models.Reorder] = []

    vehicles = db.query(models.Vehicle).all()
    for vehicle in vehicles:
        soll_map = alle_soll_fuer_vehicle(db, vehicle.id)
        containers = {c.id: c for c in db.query(models.Container).filter_by(vehicle_id=vehicle.id).all()}

        # offene Reorders dieses Fahrzeugs, um spaeter automatisch zu schliessen was nicht mehr zutrifft
        offene = (
            db.query(models.Reorder)
            .filter_by(vehicle_id=vehicle.id, status="offen")
            .all()
        )
        offene_keys = {(r.container_id, r.item_id, r.grund): r for r in offene}
        noch_gueltig: set[tuple[int, int, str]] = set()

        stocks = db.query(models.Stock).filter_by(vehicle_id=vehicle.id).all()
        for stock in stocks:
            container = containers.get(stock.container_id)
            if container is None:
                continue
            soll_min, soll_max, _ = soll_map.get((container.standard_code, stock.item_id), (0, None, False))

            # Echte Fehlmenge: unter dem Mindestbestand. Ein Bestand zwischen
            # Soll-Min und Soll-Max ist normal (Verbrauchsspanne) und loest
            # bewusst KEINE Nachbestellung/E-Mail aus, nur die "auffuellen"-
            # Markierung in der Bestandsansicht.
            if soll_min and stock.ist_menge < soll_min:
                menge = soll_min - stock.ist_menge
                key = (stock.container_id, stock.item_id, "fehlmenge")
                r, ist_neu = _get_or_create_open(db, vehicle.id, stock.container_id, stock.item_id, "fehlmenge")
                r.menge = menge
                if ist_neu:
                    neu_erzeugt.append(r)
                noch_gueltig.add(key)

            # Bald ablaufend
            if stock.ablauf_monat and stock.ablauf_jahr:
                q = quartale_bis_ablauf(stock.ablauf_monat, stock.ablauf_jahr)
                if q <= REORDER_LEAD_QUARTERS:
                    key = (stock.container_id, stock.item_id, "ablauf")
                    r, ist_neu = _get_or_create_open(db, vehicle.id, stock.container_id, stock.item_id, "ablauf")
                    r.menge = stock.ist_menge
                    if ist_neu:
                        neu_erzeugt.append(r)
                    noch_gueltig.add(key)

        # alles, was jetzt nicht mehr zutrifft, automatisch erledigen
        for key, r in offene_keys.items():
            if key not in noch_gueltig:
                r.status = "erledigt"
                r.erledigt_am = dt.datetime.now()

    db.commit()
    return neu_erzeugt
