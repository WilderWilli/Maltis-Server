from contextlib import asynccontextmanager

from apscheduler.schedulers.background import BackgroundScheduler
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.database import Base, SessionLocal, engine
from app.logic.notify import benachrichtige_neue_nachbestellungen
from app.logic.reorder import recompute_reorders
from app.routes import admin, dashboard, notifications, quarterly, reorders, users, vehicle

Base.metadata.create_all(engine)

scheduler = BackgroundScheduler()


def taeglicher_check():
    db = SessionLocal()
    try:
        neue = recompute_reorders(db)
        benachrichtige_neue_nachbestellungen(db, neue)
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    taeglicher_check()  # einmal beim Start, damit neue Daten sofort sichtbar sind
    scheduler.add_job(taeglicher_check, "cron", hour=6, minute=0, id="taeglicher_check")
    scheduler.start()
    yield
    scheduler.shutdown(wait=False)


app = FastAPI(title="GwSan Lagersoftware", lifespan=lifespan)
app.mount("/static", StaticFiles(directory="app/static"), name="static")

app.include_router(dashboard.router)
app.include_router(vehicle.router)
app.include_router(reorders.router)
app.include_router(notifications.router)
app.include_router(quarterly.router)
app.include_router(users.router)
app.include_router(admin.router)
