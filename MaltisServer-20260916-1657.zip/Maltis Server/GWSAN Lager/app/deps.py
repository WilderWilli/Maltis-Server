from fastapi import Request
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app import models

templates = Jinja2Templates(directory="app/templates")

USER_COOKIE = "gwsan_user_kuerzel"


def current_user(request: Request, db: Session) -> models.User | None:
    kuerzel = request.cookies.get(USER_COOKIE)
    if not kuerzel:
        return None
    return db.query(models.User).filter_by(kuerzel=kuerzel).first()


def ungelesene_benachrichtigungen(db: Session, user: models.User | None) -> int:
    gesamt = db.query(models.Notification).count()
    if user is None:
        return gesamt
    gelesen = db.query(models.NotificationRead).filter_by(user_id=user.id).count()
    return max(gesamt - gelesen, 0)


def base_context(request: Request, db: Session) -> dict:
    user = current_user(request, db)
    return {
        "request": request,
        "current_user": user,
        "unread_count": ungelesene_benachrichtigungen(db, user),
        "vehicles": db.query(models.Vehicle).order_by(models.Vehicle.code).all(),
    }
