import datetime as dt

from sqlalchemy import (
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def now() -> dt.datetime:
    return dt.datetime.now()


class Vehicle(Base):
    __tablename__ = "vehicles"

    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True)  # GwSan5
    name: Mapped[str] = mapped_column(String(100))  # GwSan 5
    kennzeichen: Mapped[str] = mapped_column(String(20))  # HH-8077

    containers: Mapped[list["Container"]] = relationship(back_populates="vehicle")


class Container(Base):
    """Ein Fach/eine Kiste/ein Rucksack innerhalb eines konkreten Fahrzeugs."""

    __tablename__ = "containers"
    __table_args__ = (UniqueConstraint("vehicle_id", "code"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    vehicle_id: Mapped[int] = mapped_column(ForeignKey("vehicles.id"))
    code: Mapped[str] = mapped_column(String(30))  # K1, EE1, EE2, EE3, KK, Fahrerhaus...
    name: Mapped[str] = mapped_column(String(200))
    kind: Mapped[str] = mapped_column(String(30))  # kiste, kfz, rucksack_erwachsene, rucksack_kinder
    geraeteraum: Mapped[str | None] = mapped_column(String(50), nullable=True)
    # der fahrzeugübergreifende Code für Soll-Vergleiche (K1..K38 identisch,
    # EE1/EE2/EE3 -> "EE", KK -> "KK", Fahrerhaus/Rueckbank -> sich selbst)
    standard_code: Mapped[str] = mapped_column(String(30))

    vehicle: Mapped["Vehicle"] = relationship(back_populates="containers")


class Item(Base):
    __tablename__ = "items"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(300), unique=True)
    kategorie: Mapped[str] = mapped_column(String(50))
    ist_mhd_zusatz: Mapped[bool] = mapped_column(Boolean, default=False)


class StandardSoll(Base):
    """Fahrzeugübergreifender Standard-Sollbestand je (Fach-Code, Artikel)."""

    __tablename__ = "standard_soll"
    __table_args__ = (UniqueConstraint("container_code", "item_id"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    container_code: Mapped[str] = mapped_column(String(30))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    soll_min: Mapped[int] = mapped_column(Integer, default=0)
    soll_max: Mapped[int | None] = mapped_column(Integer, nullable=True)

    item: Mapped["Item"] = relationship()


class VehicleSollOverride(Base):
    """Bewusste Ausnahme vom Standard fuer ein einzelnes Fahrzeug."""

    __tablename__ = "vehicle_soll_overrides"
    __table_args__ = (UniqueConstraint("vehicle_id", "container_code", "item_id"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    vehicle_id: Mapped[int] = mapped_column(ForeignKey("vehicles.id"))
    container_code: Mapped[str] = mapped_column(String(30))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    soll_min: Mapped[int] = mapped_column(Integer, default=0)
    soll_max: Mapped[int | None] = mapped_column(Integer, nullable=True)
    grund: Mapped[str | None] = mapped_column(String(300), nullable=True)
    bestaetigt: Mapped[bool] = mapped_column(Boolean, default=False)

    vehicle: Mapped["Vehicle"] = relationship()
    item: Mapped["Item"] = relationship()


class Stock(Base):
    """Aktueller Bestand eines Artikels in einem Fach eines Fahrzeugs."""

    __tablename__ = "stock"
    __table_args__ = (UniqueConstraint("vehicle_id", "container_id", "item_id"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    vehicle_id: Mapped[int] = mapped_column(ForeignKey("vehicles.id"))
    container_id: Mapped[int] = mapped_column(ForeignKey("containers.id"))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    ist_menge: Mapped[int] = mapped_column(Integer, default=0)
    ablauf_monat: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ablauf_jahr: Mapped[int | None] = mapped_column(Integer, nullable=True)
    aktualisiert_am: Mapped[dt.datetime] = mapped_column(DateTime, default=now)
    aktualisiert_von: Mapped[str | None] = mapped_column(String(50), nullable=True)

    vehicle: Mapped["Vehicle"] = relationship()
    container: Mapped["Container"] = relationship()
    item: Mapped["Item"] = relationship()


class Reorder(Base):
    __tablename__ = "reorders"

    id: Mapped[int] = mapped_column(primary_key=True)
    vehicle_id: Mapped[int] = mapped_column(ForeignKey("vehicles.id"))
    container_id: Mapped[int] = mapped_column(ForeignKey("containers.id"))
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"))
    grund: Mapped[str] = mapped_column(String(20))  # fehlmenge | ablauf
    menge: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(20), default="offen")  # offen|bestellt|erledigt
    erstellt_am: Mapped[dt.datetime] = mapped_column(DateTime, default=now)
    email_gesendet_am: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    erledigt_am: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)

    vehicle: Mapped["Vehicle"] = relationship()
    container: Mapped["Container"] = relationship()
    item: Mapped["Item"] = relationship()


class Notification(Base):
    __tablename__ = "notifications"

    id: Mapped[int] = mapped_column(primary_key=True)
    typ: Mapped[str] = mapped_column(String(30))  # nachbestellung | quartalspruefung
    titel: Mapped[str] = mapped_column(String(200))
    text: Mapped[str] = mapped_column(String(2000))
    ref_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    erstellt_am: Mapped[dt.datetime] = mapped_column(DateTime, default=now)


class NotificationRead(Base):
    __tablename__ = "notification_reads"
    __table_args__ = (UniqueConstraint("notification_id", "user_id"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    notification_id: Mapped[int] = mapped_column(ForeignKey("notifications.id"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))


class QuarterlyCheck(Base):
    __tablename__ = "quarterly_checks"
    __table_args__ = (UniqueConstraint("vehicle_id", "jahr", "quartal"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    vehicle_id: Mapped[int] = mapped_column(ForeignKey("vehicles.id"))
    jahr: Mapped[int] = mapped_column(Integer)
    quartal: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), default="offen")  # offen|abgeschlossen
    gestartet_von: Mapped[str | None] = mapped_column(String(50), nullable=True)
    gestartet_am: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    abgeschlossen_von: Mapped[str | None] = mapped_column(String(50), nullable=True)
    abgeschlossen_am: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)

    vehicle: Mapped["Vehicle"] = relationship()


class QuarterlyCheckItem(Base):
    __tablename__ = "quarterly_check_items"

    id: Mapped[int] = mapped_column(primary_key=True)
    check_id: Mapped[int] = mapped_column(ForeignKey("quarterly_checks.id"))
    stock_id: Mapped[int] = mapped_column(ForeignKey("stock.id"))
    aktion: Mapped[str] = mapped_column(String(20))  # entfernt|bestaetigt|korrigiert
    alte_menge: Mapped[int] = mapped_column(Integer)
    neue_menge: Mapped[int] = mapped_column(Integer)
    kommentar: Mapped[str | None] = mapped_column(String(300), nullable=True)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    kuerzel: Mapped[str] = mapped_column(String(10), unique=True)
