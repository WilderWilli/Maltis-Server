function initTableFilter(searchInputId, onlyDeviationId, tableSelector) {
    const search = document.getElementById(searchInputId);
    const onlyDeviation = document.getElementById(onlyDeviationId);
    const table = document.querySelector(tableSelector);
    if (!table) return;

    function apply() {
        const term = (search && search.value ? search.value : "").toLowerCase().trim();
        const onlyDev = onlyDeviation && onlyDeviation.checked;
        table.querySelectorAll("tbody tr[data-artikel]").forEach((row) => {
            const matchesSearch = !term || row.dataset.artikel.toLowerCase().includes(term);
            const matchesDeviation = !onlyDev || row.dataset.status !== "ok";
            row.style.display = matchesSearch && matchesDeviation ? "" : "none";
        });
        table.querySelectorAll("tbody tr[data-group-heading]").forEach((row) => {
            row.style.display = "";
        });
    }

    if (search) search.addEventListener("input", apply);
    if (onlyDeviation) onlyDeviation.addEventListener("change", apply);
    apply();
}
