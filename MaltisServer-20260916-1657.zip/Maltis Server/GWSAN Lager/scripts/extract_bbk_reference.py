"""Extrahiert die offizielle BBK-Sollmenge (Artikel/Stk/Kiste) aus dem
Begleitheft-PDF als Referenzdaten fuer die Datenpruefung.

Wichtig: Die BBK-Liste dient laut Nutzer nur als ZUSAETZLICHE Referenz
("Tie-Breaker") bei Abweichungen zwischen den 3 Fahrzeugen - sie kann selbst
kleine Fehler enthalten und wird NICHT automatisch als Wahrheit uebernommen.

Aufruf: python scripts/extract_bbk_reference.py
Erzeugt: data/bbk_reference.json
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pdfplumber

PDF_PATH = Path(__file__).resolve().parent.parent / "data" / "source" / "BBK_Begleitheft.pdf"
OUT_PATH = Path(__file__).resolve().parent.parent / "data" / "bbk_reference.json"

# Sanitaets-/Kfz-/Kommunikationsausstattung (mit Kisten-Zuordnung) + die
# beiden Notfallrucksack-Kapitel (ohne Kisten-Zuordnung, da im Rucksack).
PAGES = list(range(3, 9)) + list(range(11, 15))


def clean(v):
    if v is None:
        return None
    v = str(v).replace("\xa0", " ").replace("\n", " ").strip()
    v = re.sub(r"\s+", " ", v)
    return v or None


def extract():
    eintraege = []
    with pdfplumber.open(PDF_PATH) as pdf:
        for pno in PAGES:
            page = pdf.pages[pno - 1]
            tables = page.extract_tables()
            if not tables:
                continue
            table = tables[0]
            header = [clean(c) for c in table[0]]
            try:
                idx_artikel = header.index("Artikel")
                idx_stk = header.index("Stk")
            except ValueError:
                continue
            idx_kiste = header.index("Kiste") if "Kiste" in header else None

            for row in table[1:]:
                row = [clean(c) for c in row]
                nr = row[0]
                if not nr or "." not in nr:
                    continue  # Kapitel-Ueberschriften ohne echte Nr. ueberspringen
                artikel = row[idx_artikel] if idx_artikel < len(row) else None
                stk = row[idx_stk] if idx_stk < len(row) else None
                kiste = row[idx_kiste] if idx_kiste is not None and idx_kiste < len(row) else None
                if not artikel or not stk:
                    continue
                try:
                    stk_int = int(float(stk))
                except ValueError:
                    continue
                eintraege.append(
                    {
                        "nr": nr,
                        "artikel": artikel,
                        "stk": stk_int,
                        "kiste": kiste,
                        "seite": pno,
                    }
                )
    return eintraege


def main():
    eintraege = extract()
    OUT_PATH.write_text(json.dumps(eintraege, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{len(eintraege)} BBK-Referenzeintraege nach {OUT_PATH} geschrieben.")


if __name__ == "__main__":
    main()
