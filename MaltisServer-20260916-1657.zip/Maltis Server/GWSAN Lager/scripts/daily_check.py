"""Taeglicher Hintergrund-Check ohne laufende App - fuer den Windows-Taskplaner.

Berechnet Nachbestell-Bedarf neu (Fehlmengen + Artikel, die in <= 3 Quartalen
ablaufen) und verschickt bei neuen Treffern eine Sammel-E-Mail sowie eine
In-App-Benachrichtigung (sichtbar, sobald jemand die App wieder oeffnet).

Aufruf: python scripts/daily_check.py
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.database import SessionLocal
from app.logic.notify import benachrichtige_neue_nachbestellungen
from app.logic.reorder import recompute_reorders


def main():
    db = SessionLocal()
    try:
        neue = recompute_reorders(db)
        benachrichtige_neue_nachbestellungen(db, neue)
        print(f"Check abgeschlossen: {len(neue)} neue Nachbestellung(en).")
    finally:
        db.close()


if __name__ == "__main__":
    main()
