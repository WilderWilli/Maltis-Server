"""Einmaliger Import der bestehenden Belade- und Pruefliste-Excel-Dateien in die
SQLite-Datenbank der Lagersoftware.

Aufruf:  python scripts/import_initial_data.py

Quelle: data/source/GwSan5.xlsx, GwSan6.xlsx, GwSan7.xlsx
(Kopien der Original-Downloads, siehe Belade- und Pruefliste GWSan 5/6/7.)

Legt an:
- vehicles, containers (aus "Gesamtuebersicht" + Fahrerhaus/Rueckbank/lose
  Geraeteraum-Positionen + EE1/EE2/EE3/KK Ruecksaecke)
- items (fahrzeuguebergreifender Artikelstamm)
- standard_soll (haeufigster Sollwert je Fach-Code+Artikel ueber die 3 Fahrzeuge)
- vehicle_soll_overrides (echte Abweichungen -> muessen im Admin-Bereich
  "Datenpruefung" bestaetigt werden; MHD-Zusatz-Artikel IMMER als Ausnahme,
  keine Standardisierung)
- stock (aktueller Ist-Bestand inkl. Ablaufdatum je Fahrzeug/Fach/Artikel)
"""

import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import openpyxl

from app import models
from app.database import Base, SessionLocal, engine

SOURCE_DIR = Path(__file__).resolve().parent.parent / "data" / "source"

VEHICLES = {
    "GwSan5": {"name": "GwSan 5", "kennzeichen": "HH-8077", "file": SOURCE_DIR / "GwSan5.xlsx"},
    "GwSan6": {"name": "GwSan 6", "kennzeichen": "HH-8655", "file": SOURCE_DIR / "GwSan6.xlsx"},
    "GwSan7": {"name": "GwSan 7", "kennzeichen": "HH-8656", "file": SOURCE_DIR / "GwSan7.xlsx"},
}

RUCKSAECKE = {
    "Rucksack EE1": ("EE1", "Notfallrucksack Erwachsene 1", "rucksack_erwachsene", "EE"),
    "Rucksack EE2": ("EE2", "Notfallrucksack Erwachsene 2", "rucksack_erwachsene", "EE"),
    "Rucksack EE3": ("EE3", "Notfallrucksack Erwachsene 3", "rucksack_erwachsene", "EE"),
    "Rucksack KK": ("KK", "Notfallrucksack Kinder", "rucksack_kinder", "KK"),
}

MHD_ZUSATZ_RE = re.compile(r"mhd[\s-]*zusatz", re.IGNORECASE)
K_CODE_RE = re.compile(r"^K\s*(\d+)$", re.IGNORECASE)
# Vereinzelt steht in der Artikel-Spalte ein Kontrolldatum-Vermerk statt
# eines echten Artikels (z.B. "Kontrolliert 30.07.2025") - kein Inventar.
KONTROLLVERMERK_RE = re.compile(r"^kontrolliert\b", re.IGNORECASE)


def clean(v):
    if v is None:
        return None
    if isinstance(v, str):
        v = v.replace("\xa0", " ").strip()
        v = re.sub(r"\s+", " ", v)
        return v if v != "" else None
    return v


def to_int(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return int(v)
    if isinstance(v, str):
        v = v.strip()
        if v in ("", "-"):
            return None
        try:
            return int(float(v))
        except ValueError:
            return None
    return None


def normalize_box_code(v):
    """'K 19' / 'K19' / 'k19' -> 'K19'. Gibt None zurueck wenn kein K-Code."""
    if not v:
        return None
    m = K_CODE_RE.match(v.strip())
    if m:
        return f"K{int(m.group(1))}"
    return None


# ---------------------------------------------------------------------------
# Excel-Parsing (Struktur der 3 Dateien bereits verifiziert)
# ---------------------------------------------------------------------------


def parse_gesamtuebersicht(ws):
    boxes = {}
    started = False
    for row in ws.iter_rows(values_only=True):
        row = [clean(c) for c in row]
        if row[0] == "Kisten-Nr.":
            started = True
            continue
        if not started or row[0] is None:
            continue
        code = normalize_box_code(row[0]) or row[0]
        boxes[code] = {"name": row[1] or code, "geraeteraum": row[2]}
    return boxes


def parse_item_table(rows, start_idx, col_map, end_idx=None):
    items = []
    cur_loc = None
    cur_box_raw = None
    end_idx = len(rows) if end_idx is None else end_idx
    for i in range(start_idx, end_idx):
        row = [clean(c) for c in rows[i]]

        def g(key):
            idx = col_map.get(key)
            return row[idx] if idx is not None and idx < len(row) else None

        loc = g("loc")
        box = g("box")
        artikel = g("artikel")

        if loc:
            cur_loc = loc
        if box:
            # In der Fahrzeug-Tabelle folgt auf einen echten Kisten-Code (z.B.
            # "K 15") gelegentlich eine rein dekorative Unterueberschrift wie
            # "- Medikamente -" in derselben Spalte. Die soll den aktiven
            # Kisten-Code NICHT ueberschreiben, sonst geht die Kisten-Zuordnung
            # der folgenden Artikel verloren.
            if normalize_box_code(box) or cur_box_raw is None:
                cur_box_raw = box

        if not artikel or KONTROLLVERMERK_RE.match(artikel):
            continue

        items.append(
            {
                "loc": cur_loc,
                "box_raw": cur_box_raw,
                "artikel": artikel,
                "soll_min": g("min"),
                "soll_max": g("max"),
                "ist": g("ist"),
                "exp_month": to_int(g("exp_m")),
                "exp_year": to_int(g("exp_y")),
            }
        )
    return items


def parse_fahrzeug(ws):
    rows = [[clean(c) for c in row] for row in ws.iter_rows(values_only=True)]
    header_idxs = [i for i, row in enumerate(rows) if "Artikel" in row]
    col_map = {"loc": 0, "box": 1, "min": 2, "max": 3, "artikel": 4, "ist": 5, "exp_m": 6, "exp_y": 7}
    all_items = []
    for idx, h in enumerate(header_idxs):
        end = header_idxs[idx + 1] if idx + 1 < len(header_idxs) else len(rows)
        all_items.extend(parse_item_table(rows, h + 2, col_map, end_idx=end))
    return all_items


def parse_rucksack(ws):
    rows = [[clean(c) for c in row] for row in ws.iter_rows(values_only=True)]
    header_idx = next(i for i, row in enumerate(rows) if row[0] == "Fach")
    col_map = {"loc": 0, "box": 1, "min": 2, "ist": 3, "artikel": 4, "exp_m": 5, "exp_y": 6}
    items = parse_item_table(rows, header_idx + 2, col_map)
    # Ruecksaecke haben keine eigene max-Spalte: Sollmenge ist ein fixer Zielwert
    for it in items:
        it["soll_max"] = it["soll_min"]
    return items


# ---------------------------------------------------------------------------
# Container-Auflösung: welchem Fach/welcher Kiste gehoert eine Zeile an
# ---------------------------------------------------------------------------


def container_key_for_fahrzeug_item(it, box_registry):
    box_code = normalize_box_code(it["box_raw"])
    if box_code:
        info = box_registry.get(box_code, {"name": box_code, "geraeteraum": None})
        return box_code, info["name"], "kiste", info["geraeteraum"]
    # keine Kiste -> Fach/Ort selbst ist der Container (Fahrerhaus, Rueckbank,
    # oder lose Ausstattung in einem Geraeteraum ohne eigene Kiste)
    loc = it["loc"] or "Sonstiges"
    return loc, loc, "kfz", None


def main():
    print("Erzeuge Tabellen ...")
    Base.metadata.create_all(engine)
    db = SessionLocal()

    if db.query(models.Vehicle).count() > 0:
        print("Datenbank enthaelt bereits Fahrzeuge - Abbruch (kein erneuter Import).")
        print("Zum Neuimport vorher data/gwsan.db loeschen.")
        return

    # 1) Fahrzeuge + Rohdaten je Fahrzeug parsen -----------------------------
    raw_by_vehicle = {}
    box_registry_by_vehicle = {}
    vehicles_db = {}

    for code, meta in VEHICLES.items():
        print(f"Lese {meta['file'].name} ...")
        wb = openpyxl.load_workbook(meta["file"], data_only=True)

        vehicle = models.Vehicle(code=code, name=meta["name"], kennzeichen=meta["kennzeichen"])
        db.add(vehicle)
        db.flush()
        vehicles_db[code] = vehicle

        box_registry = parse_gesamtuebersicht(wb["Gesamtübersicht"])
        box_registry_by_vehicle[code] = box_registry

        entries = []  # (container_code, container_name, kind, geraeteraum, artikel, soll_min, soll_max, ist, exp_m, exp_y)
        for it in parse_fahrzeug(wb["Fahrzeug"]):
            ccode, cname, kind, graum = container_key_for_fahrzeug_item(it, box_registry)
            entries.append((ccode, cname, kind, graum, it))

        for sheet_name, (ccode, cname, kind, std_code) in RUCKSAECKE.items():
            for it in parse_rucksack(wb[sheet_name]):
                entries.append((ccode, cname, kind, None, it))

        raw_by_vehicle[code] = entries

    # 2) Container anlegen ----------------------------------------------------
    # standard_code: bei Kisten/Fahrerhaus/Rueckbank/lose Positionen = eigener
    # Code (K1..K38 etc. sind ueber alle Fahrzeuge gleich benannt), bei
    # Ruecksaecken EE1/EE2/EE3 -> gemeinsamer Code "EE", KK -> "KK".
    container_by_vehicle_code: dict[tuple[str, str], models.Container] = {}

    def std_code_for(ccode, kind):
        if kind == "rucksack_erwachsene":
            return "EE"
        if kind == "rucksack_kinder":
            return "KK"
        return ccode

    for vcode, entries in raw_by_vehicle.items():
        vehicle = vehicles_db[vcode]
        seen = {}
        for ccode, cname, kind, graum, it in entries:
            if ccode not in seen:
                seen[ccode] = (cname, kind, graum)
        for ccode, (cname, kind, graum) in seen.items():
            container = models.Container(
                vehicle_id=vehicle.id,
                code=ccode,
                name=cname,
                kind=kind,
                geraeteraum=graum,
                standard_code=std_code_for(ccode, kind),
            )
            db.add(container)
            db.flush()
            container_by_vehicle_code[(vcode, ccode)] = container

    # 3) Artikelstamm ----------------------------------------------------------
    kategorie_by_kind = {
        "kiste": "Kisten-Material",
        "kfz": "Kfz-Ausstattung",
        "rucksack_erwachsene": "Rucksack Erwachsene",
        "rucksack_kinder": "Rucksack Kinder",
    }
    items_by_name: dict[str, models.Item] = {}

    def get_item(name: str, kind: str) -> models.Item:
        item = items_by_name.get(name)
        if item is None:
            item = models.Item(
                name=name,
                kategorie=kategorie_by_kind.get(kind, "Sonstiges"),
                ist_mhd_zusatz=bool(MHD_ZUSATZ_RE.search(name)),
            )
            db.add(item)
            db.flush()
            items_by_name[name] = item
        return item

    # 4) Soll-Werte je (container_code, item) sammeln, um Standard vs.
    #    Ausnahme zu bestimmen -------------------------------------------------
    soll_samples: dict[tuple[str, str], dict[str, tuple[int | None, int | None]]] = defaultdict(dict)
    # (std_code, item_name) -> { vehicle_code: (soll_min, soll_max) }

    for vcode, entries in raw_by_vehicle.items():
        for ccode, cname, kind, graum, it in entries:
            std_code = std_code_for(ccode, kind)
            name = it["artikel"]
            smin = to_int(it["soll_min"])
            smax = to_int(it["soll_max"])
            if smax is None and kind not in ("rucksack_erwachsene", "rucksack_kinder"):
                pass  # bleibt None -> "kein Maximum" (Einzelstueck-Ausstattung)
            soll_samples[(std_code, name)][vcode] = (smin or 0, smax)

    n_standard = 0
    n_override = 0
    for (std_code, name), by_vehicle in soll_samples.items():
        item = get_item(name, "kiste")  # kategorie wird ggf. unten korrigiert
        is_mhd = item.ist_mhd_zusatz

        if is_mhd:
            for vcode, (smin, smax) in by_vehicle.items():
                db.add(
                    models.VehicleSollOverride(
                        vehicle_id=vehicles_db[vcode].id,
                        container_code=std_code,
                        item_id=item.id,
                        soll_min=smin,
                        soll_max=smax,
                        grund="Zusatzmaterial (MHD-Zusatz), fahrzeugspezifisch aufgeladen",
                        bestaetigt=True,
                    )
                )
                n_override += 1
            continue

        werte = list(by_vehicle.values())
        haeufigster, _ = Counter(werte).most_common(1)[0]
        db.add(
            models.StandardSoll(
                container_code=std_code,
                item_id=item.id,
                soll_min=haeufigster[0],
                soll_max=haeufigster[1],
            )
        )
        n_standard += 1

        for vcode, wert in by_vehicle.items():
            if wert != haeufigster:
                db.add(
                    models.VehicleSollOverride(
                        vehicle_id=vehicles_db[vcode].id,
                        container_code=std_code,
                        item_id=item.id,
                        soll_min=wert[0],
                        soll_max=wert[1],
                        grund="Abweichung zur Excel-Vorlage der anderen Fahrzeuge erkannt - bitte pruefen",
                        bestaetigt=False,
                    )
                )
                n_override += 1

    # Kategorien nachtraeglich korrigieren: erste Fundstelle je Artikel bestimmt Kategorie
    kategorie_gesetzt = set()
    for vcode, entries in raw_by_vehicle.items():
        for ccode, cname, kind, graum, it in entries:
            item = items_by_name.get(it["artikel"])
            if item and item.id not in kategorie_gesetzt:
                item.kategorie = kategorie_by_kind.get(kind, "Sonstiges")
                kategorie_gesetzt.add(item.id)

    db.commit()
    print(f"Artikelstamm: {len(items_by_name)} Artikel, {n_standard} Standard-Sollwerte, {n_override} Fahrzeug-Ausnahmen")

    # 5) Bestand (stock) --------------------------------------------------------
    n_stock = 0
    n_duplikate = 0
    for vcode, entries in raw_by_vehicle.items():
        vehicle = vehicles_db[vcode]
        stock_cache: dict[tuple[int, int], models.Stock] = {}
        for ccode, cname, kind, graum, it in entries:
            container = container_by_vehicle_code[(vcode, ccode)]
            item = items_by_name[it["artikel"]]
            ist_menge = to_int(it["ist"]) or 0
            cache_key = (container.id, item.id)
            existing = stock_cache.get(cache_key)
            if existing:
                # doppelte Zeile fuer denselben Artikel im selben Fach: Mengen
                # addieren, das frueheste Ablaufdatum behalten
                n_duplikate += 1
                existing.ist_menge += ist_menge
                if it["exp_month"] and it["exp_year"]:
                    neu_key = it["exp_year"] * 12 + it["exp_month"]
                    alt_key = (
                        existing.ablauf_jahr * 12 + existing.ablauf_monat
                        if existing.ablauf_jahr and existing.ablauf_monat
                        else None
                    )
                    if alt_key is None or neu_key < alt_key:
                        existing.ablauf_monat = it["exp_month"]
                        existing.ablauf_jahr = it["exp_year"]
            else:
                stock = models.Stock(
                    vehicle_id=vehicle.id,
                    container_id=container.id,
                    item_id=item.id,
                    ist_menge=ist_menge,
                    ablauf_monat=it["exp_month"],
                    ablauf_jahr=it["exp_year"],
                )
                db.add(stock)
                stock_cache[cache_key] = stock
                n_stock += 1
    db.commit()
    print(f"Bestand: {n_stock} Positionen importiert ({n_duplikate} doppelte Zeilen zusammengefuehrt)")

    for vcode in VEHICLES:
        n = db.query(models.Container).join(models.Vehicle).filter(models.Vehicle.code == vcode).count()
        print(f"  {vcode}: {n} Container")

    db.close()
    print("Import abgeschlossen.")


if __name__ == "__main__":
    main()
