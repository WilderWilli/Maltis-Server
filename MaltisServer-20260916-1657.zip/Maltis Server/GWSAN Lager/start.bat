@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo    ___________________________
echo   ^|  o-o              o-o    ^|
echo   ^|=========================^|      GWSAN LAGERSOFTWARE
echo   ^|   T A T U E T A T A !   ^|
echo    ---------------------------
echo.

set /a spruch_idx=%RANDOM% %% 6
if %spruch_idx%==0 set spruch=Diagnose: Lager wird geladen. Therapie: kurz Kaffee holen.
if %spruch_idx%==1 set spruch=Einsatzstichwort: Bestandspruefung. Status: RTW faehrt vor.
if %spruch_idx%==2 set spruch=Vitalzeichen der Software: stabil. Weiterfahren!
if %spruch_idx%==3 set spruch=MHD der guten Laune: unbegrenzt gueltig.
if %spruch_idx%==4 set spruch=Sonderrechte aktiviert - die App hat Vorfahrt.
if %spruch_idx%==5 set spruch=Uebergabe an den Server laeuft. Bitte kurz Platz machen.
echo   %spruch%
echo.

echo ============================================
echo   GwSan Lagersoftware wird vorbereitet ...
echo ============================================

where python >nul 2>nul
if errorlevel 1 (
    echo.
    echo FEHLER: Python wurde nicht gefunden.
    echo Bitte Python von https://www.python.org/downloads/ installieren
    echo ^(beim Installieren unbedingt das Haekchen "Add python.exe to PATH" setzen^)
    echo und diese Datei danach erneut per Doppelklick starten.
    echo.
    pause
    exit /b 1
)

python -c "import fastapi" >nul 2>nul
if errorlevel 1 (
    echo Benoetigte Programmteile werden einmalig installiert, bitte kurz warten ...
    python -m pip install --quiet -r requirements.txt
    if errorlevel 1 (
        echo.
        echo FEHLER bei der Installation. Bitte diese Meldung an die IT-Unterstuetzung weitergeben.
        pause
        exit /b 1
    )
)

if not exist ".env" (
    copy /y ".env.example" ".env" >nul
    echo Es wurde eine .env-Datei fuer die E-Mail-Einstellungen angelegt.
    echo Ohne Eintraege darin funktioniert die App normal, nur E-Mails werden nicht verschickt.
)

if not exist "data\gwsan.db" (
    echo Ersteinrichtung: bestehende Bestandsdaten werden importiert, bitte kurz warten ...
    python scripts\import_initial_data.py
    if errorlevel 1 (
        echo.
        echo FEHLER beim Import. Bitte diese Meldung an die IT-Unterstuetzung weitergeben.
        pause
        exit /b 1
    )
)

echo.
echo Starte GwSan Lagersoftware ...
echo Dieses Fenster bitte waehrend der Nutzung geoeffnet lassen.
echo Zum Beenden: Fenster einfach schliessen oder Strg+C druecken.
echo.

start "" http://127.0.0.1:8000
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

pause
