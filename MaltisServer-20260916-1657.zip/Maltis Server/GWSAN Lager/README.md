# GwSan Lagersoftware

Lokale Lagersoftware für die Bestandsführung der drei Gerätewagen Sanität
(GwSan 5 / HH-8077, GwSan 6 / HH-8655, GwSan 7 / HH-8656): Soll-/Ist-Bestand,
Ablaufdatum-Tracking, geführte Quartalsprüfung, automatische
Nachbestell-Erkennung sowie In-App- und E-Mail-Benachrichtigungen.

## Schnellstart (kein Terminal nötig)

1. Diesen Ordner öffnen (Explorer).
2. Doppelklick auf **`start.bat`**.
   - Es öffnet sich kurz ein schwarzes Fenster. Beim allerersten Start
     installiert es automatisch alles Nötige und richtet die Datenbank ein
     (dauert einmalig ein bis zwei Minuten, danach geht's schnell).
   - Danach öffnet sich automatisch der Browser mit der Lagersoftware.
3. Dieses schwarze Fenster **während der Nutzung offen lassen** – es ist der
   "Motor" der App. Schließt du es, ist die App zu; einfach `start.bat`
   erneut doppelklicken, um sie wieder zu öffnen.

Das war's – mehr ist für die normale Nutzung nicht nötig. Falls beim ersten
Start eine Fehlermeldung zu Python erscheint: Python von
https://www.python.org/downloads/ installieren (beim Installationsassistenten
unbedingt das Häkchen **"Add python.exe to PATH"** setzen) und `start.bat`
danach erneut doppelklicken.

Beim ersten Bestandsupdate wirst du in der App gebeten, dich mit Name/Kürzel
anzumelden (kein Passwort) – damit lässt sich später nachvollziehen, wer eine
Änderung vorgenommen hat.

## Nach dem ersten Start: Datenprüfung

Unter **Datenprüfung** (oben in der Navigation) stehen alle Artikel, bei
denen sich die drei Fahrzeuge in ihrer bisherigen Excel-Datei in der
Soll-Menge unterschieden haben (gut 20 Fälle, z.B. unterschiedliche
Maximalmengen bei Wundkompressen). Der wahrscheinlichste Wert wurde bereits
als Standard übernommen; bitte pro Zeile kurz bestätigen, zurücksetzen oder
korrigieren.

Als zusätzlicher Anhaltspunkt zeigt die Zeile, wo automatisch ein passender
Artikel gefunden wurde, die offizielle Sollmenge aus dem BBK-Begleitheft. Das
ist bewusst nur ein Hinweis, keine automatische Korrektur – auch das
Begleitheft kann an einzelnen Stellen kleine Fehler enthalten.

## E-Mail-Benachrichtigungen einrichten (optional)

Ohne diesen Schritt funktioniert die App normal, es werden nur keine E-Mails
verschickt (die Benachrichtigungen in der App selbst funktionieren trotzdem).

1. Im Ordner die Datei **`.env`** mit einem Texteditor öffnen (Rechtsklick →
   Öffnen mit → Editor/Notepad). Sie wurde beim ersten Start automatisch aus
   `.env.example` angelegt.
2. Bei `niklasjargstorff@gmail.com` ein App-Passwort erzeugen (setzt
   2-Faktor-Authentifizierung voraus, ggf. vorher unter
   https://myaccount.google.com/security aktivieren):
   https://myaccount.google.com/apppasswords → App auswählen ("Sonstig(es)",
   z.B. "GwSan Lager") → erzeugtes Passwort kopieren.
3. In der `.env`-Datei hinter `GMAIL_APP_PASSWORD=` das kopierte Passwort
   einfügen und speichern. Die Zeile sieht dann z.B. so aus:
   ```
   GMAIL_APP_PASSWORD=abcdwxyzabcdwxyz
   ```
4. Das schwarze Fenster schließen und `start.bat` erneut doppelklicken.

Die Software verschickt danach eine Sammel-E-Mail an
behandlungsfuehrung.sgshamburg@malteser.org, sobald neue Artikel zur Nachbestellung
erkannt werden (Fehlmenge oder Ablauf in ≤ 3 Quartalen) – nicht bei jedem
Check erneut für dieselben Artikel.

## Täglichen Hintergrund-Check einrichten (optional, für Fortgeschrittene)

Solange `start.bat` läuft, prüft die App ohnehin jeden Morgen um 06:00 Uhr
automatisch. Dieser Schritt sorgt zusätzlich dafür, dass auch geprüft wird,
wenn die App gerade **nicht** offen ist. Dafür braucht es einmalig ein
Terminal (PowerShell):

1. Im Explorer in diesem Ordner in die Adressleiste klicken, `powershell`
   eintippen und Enter drücken – es öffnet sich ein blaues Fenster, bereits
   in diesem Ordner geöffnet.
2. Darin folgenden Befehl eintippen und Enter drücken, um den Python-Pfad zu
   sehen:
   ```powershell
   where python
   ```
3. Den ersten angezeigten Pfad kopieren und in den folgenden Befehl an der
   markierten Stelle einsetzen, dann den ganzen Befehl in dasselbe Fenster
   einfügen und Enter drücken:
   ```powershell
   schtasks /create /tn "GwSan Lager Taeglicher Check" /tr "\"PFAD_ZU_PYTHON.EXE\" \"C:\Users\nikla\OneDrive - MalteserCloud\Behandlung\GwSan-Lager\scripts\daily_check.py\"" /sc daily /st 07:00
   ```

Das legt einen Task an, der täglich um 07:00 Uhr läuft, unabhängig davon, ob
die App-Oberfläche offen ist. Zum Entfernen später im selben Fenster:

```powershell
schtasks /delete /tn "GwSan Lager Taeglicher Check" /f
```

## Für technisch Interessierte

- Setup und Start laufen komplett über `start.bat`. Manuell entspricht das:
  `pip install -r requirements.txt`, danach
  `python scripts/import_initial_data.py` (nur beim ersten Mal, legt
  `data/gwsan.db` an) und `python -m uvicorn app.main:app --host 127.0.0.1 --port 8000`.
- Für einen kompletten Neuimport (z.B. nach einer Korrektur an den
  Excel-Quelldateien in `data/source/`) vorher `data/gwsan.db` löschen und
  `python scripts/import_initial_data.py` erneut ausführen.
- Die BBK-Referenzdaten (`data/bbk_reference.json`) lassen sich bei Bedarf
  aus dem PDF neu erzeugen: `python scripts/extract_bbk_reference.py`.
- Projektaufbau: `app/main.py` (Einstiegspunkt), `app/logic/`
  (Kernlogik: Quartalsrechnung, Nachbestell-Erkennung, Quartalsprüfung,
  Benachrichtigungen, BBK-Referenzabgleich), `app/routes/` (Webseiten),
  `scripts/` (Datenimport, täglicher Check).
