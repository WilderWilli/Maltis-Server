"""Start ohne Konfiguration: Beispieldaten entstehen, die Oberflaeche geht auf.

Die Anwendung soll aus dem Stand funktionieren - keine .env, kein Sync-Ordner.
Erwartung: Beim Start entsteht im Standardpfad eine Datei mit erfundenen
Personen, und gegen diese Datei arbeitet die Oberflaeche vollstaendig. Ein
bewusst konfigurierter HELFERDATEI_PFAD oder ein aktiver SharePoint-Modus
verhindert die Erzeugung - dort meint der Tester eine echte Datei.
"""

from __future__ import annotations

import sys
from pathlib import Path

TESTS = Path(__file__).resolve().parent
PROJEKT = TESTS.parent
for pfad in (PROJEKT, TESTS):
    if str(pfad) not in sys.path:
        sys.path.insert(0, str(pfad))

from app.config import PROGRAMM_DIR, _pfad  # noqa: E402
from app.dateizugriff.schema import ERWARTETE_SPALTEN, SPALTE_GF  # noqa: E402
from app.dateizugriff.sync_ordner import SyncOrdnerHelferdatei  # noqa: E402
from app.dateizugriff.testdaten import (  # noqa: E402
    stelle_start_testdaten_bereit,
    stelle_testdatei_bereit,
)
from test_end_to_end_integration import _baue_web_app  # noqa: E402


# ---------------------------------------------------------------------------
# Das Erzeugen und seine Schutzwirkung
# ---------------------------------------------------------------------------

def test_fehlende_datei_wird_angelegt(tmp_path):
    ziel = tmp_path / "arbeitskopie" / "Personal_Bestandsaufnahme.xlsx"
    assert stelle_testdatei_bereit(ziel) is True
    assert ziel.exists()


def test_vorhandene_datei_bleibt_unangetastet(tmp_path):
    ziel = tmp_path / "vorhanden.xlsx"
    ziel.write_bytes(b"echter Inhalt")
    assert stelle_testdatei_bereit(ziel) is False
    assert ziel.read_bytes() == b"echter Inhalt"


def test_testdatei_ist_eine_lesbare_fuehrende_datei(tmp_path):
    ziel = tmp_path / "Personal_Bestandsaufnahme.xlsx"
    stelle_testdatei_bereit(ziel)

    datei = SyncOrdnerHelferdatei(ziel)
    assert datei.ist_erreichbar()
    assert tuple(datei.spalten("Gruppe 1")) == ERWARTETE_SPALTEN

    personen = datei.lade_personen()
    assert len(personen) >= 5
    gruppen = {str(p.wert(SPALTE_GF) or "") for p in personen}
    assert {"Niklas", "Nino", ""}.issubset(gruppen)
    assert datei.lade_amu_katalog()


def test_bereit_legt_datei_nur_im_unkonfigurierten_betrieb_an(tmp_path, monkeypatch):
    import app.config as konfig
    import app.dateizugriff.testdaten as testdaten

    ziel = tmp_path / "arbeitskopie" / "Personal_Bestandsaufnahme.xlsx"
    monkeypatch.setattr(konfig, "HELFERDATEI_PFAD", ziel)
    monkeypatch.setattr(konfig, "HELFERDATEI_PFAD_ANGEBEN", False)
    monkeypatch.setattr(konfig, "graf_aktiv", lambda: False)
    testdaten.stelle_start_testdaten_bereit()
    assert ziel.exists()


def test_bereit_ueberspringt_bei_konfiguriertem_pfad(tmp_path, monkeypatch):
    import app.config as konfig
    import app.dateizugriff.testdaten as testdaten

    ziel = tmp_path / "konfiguriert.xlsx"
    monkeypatch.setattr(konfig, "HELFERDATEI_PFAD", ziel)
    monkeypatch.setattr(konfig, "HELFERDATEI_PFAD_ANGEBEN", True)
    monkeypatch.setattr(konfig, "graf_aktiv", lambda: False)
    testdaten.stelle_start_testdaten_bereit()
    assert not ziel.exists()


def test_bereit_ueberspringt_wenn_sharepoint_aktiv(tmp_path, monkeypatch):
    import app.config as konfig
    import app.dateizugriff.testdaten as testdaten

    ziel = tmp_path / "arbeitskopie" / "Personal_Bestandsaufnahme.xlsx"
    monkeypatch.setattr(konfig, "HELFERDATEI_PFAD", ziel)
    monkeypatch.setattr(konfig, "HELFERDATEI_PFAD_ANGEBEN", False)
    monkeypatch.setattr(konfig, "graf_aktiv", lambda: True)
    testdaten.stelle_start_testdaten_bereit()
    assert not ziel.exists()


# ---------------------------------------------------------------------------
# Pfadaufloesung relativ zum Programmordner (startunabhaengig)
# ---------------------------------------------------------------------------

def test_relativer_env_pfad_haengt_am_programmordner(monkeypatch):
    monkeypatch.setenv("TEST_PFAD", "data/beispiel/datei.xlsx")
    ausgabe = _pfad("TEST_PFAD", Path("/unbenutzt"))
    assert ausgabe == (PROGRAMM_DIR / "data" / "beispiel" / "datei.xlsx").resolve()


def test_absoluter_env_pfad_bleibt_wie_angegeben(monkeypatch):
    ziel = Path("/tmp/beispiel.xlsx")
    monkeypatch.setenv("TEST_PFAD", str(ziel))
    assert _pfad("TEST_PFAD", Path("/unbenutzt")) == ziel


# ---------------------------------------------------------------------------
# Ende-zu-Ende: Die Oberflaeche arbeitet gegen die erzeugte Datei
# ---------------------------------------------------------------------------

def test_start_ohne_konfig_laedt_dashboard_mit_inhalt(tmp_path, monkeypatch):
    ziel = tmp_path / "arbeitskopie" / "Personal_Bestandsaufnahme.xlsx"
    stelle_testdatei_bereit(ziel)
    datei_objekt = SyncOrdnerHelferdatei(ziel)
    client, sitzung = _baue_web_app(tmp_path, monkeypatch, datei_objekt)
    try:
        startseite = client.get("/")
        assert startseite.status_code == 200
        assert "Helferinnen und Helfer" in startseite.text
        assert "Modus: lokaler Ordner" in startseite.text
        assert "Anna Beispiel" in startseite.text
        assert "Ben Muster" in startseite.text

        gruppen = client.get("/gruppenfuehrer")
        assert gruppen.status_code == 200
        assert "Niklas" in gruppen.text
        assert "Nino" in gruppen.text
    finally:
        sitzung.close()