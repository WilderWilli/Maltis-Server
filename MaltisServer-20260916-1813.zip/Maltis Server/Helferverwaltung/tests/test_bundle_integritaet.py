"""Integritaet des Windows-Pakets: Spec, Vorlagen, Statik und Workflow.

Schraegt die Luecken der String-Tests von test_paket_bereitschaft.py zu:

* die Quell-Pfade des ``helferverwaltung.spec`` (datas, icon, version) und
  alle ``hiddenimports`` muessen wirklich existieren bzw. importierbar sein,
* jede von einer Route ausgelieferte Vorlage und jedes benoetigte Statik-File
  muss mit ins Paket gehen - hier wird geprueft, dass sie auf der Platte
  liegen, bevor ein Build auf windows-latest das ueberhaupt erreichen kann,
* die GitHub-Actions-Pipeline (``.github/workflows/build.yml``) wird als YAML
  gelesen: Ausloeser, Runner, Reihenfolge und Artefakt-Name ``windows``.

Wichtig: ``testdaten/`` und ``helferverwaltung.ico`` sind bewusst aus dem
Repository ausgenommen und entstehen erst im Workflow-Schritt vor dem Bau
(``testdaten_erzeugen.py`` bzw. ``ico_erzeugen.py``). Deshalb wird hier nur
geprueft, dass die Erzeuger und die Spec-Referenzen vorhanden sind.
"""

from __future__ import annotations

import ast
import importlib
import re
from pathlib import Path

PROJEKT = Path(__file__).resolve().parent.parent
PAKET = PROJEKT / "windows-paket"
WORKFLOW = PROJEKT.parent / ".github" / "workflows" / "build.yml"
VORLAGEN = PROJEKT / "app" / "templates"
STATIK = PROJEKT / "app" / "static"
ROUTEN = PROJEKT / "app" / "routes"


def _workflow_dict():
    import yaml

    daten = yaml.safe_load(WORKFLOW.read_text(encoding="utf-8"))
    # YAML 1.1 liest den unquotierten Schluessel ``on`` als boolean; GitHub
    # behandelt ihn regulaer. Beide Formen werden akzeptiert.
    impulsen = daten.get("on") or daten.get(True)
    assert isinstance(impulsen, dict), "Schluessel 'on' nicht gefunden"
    return daten, impulsen


def _analysis_kwargs(text: str) -> dict[str, ast.AST]:
    """Sammelt die Keyword-Argumente des ``Analysis(...)``-Aufrufs im Spec."""
    baum = ast.parse(text)
    for knoten in ast.walk(baum):
        if (
            isinstance(knoten, ast.Call)
            and isinstance(knoten.func, ast.Name)
            and knoten.func.id == "Analysis"
        ):
            return {kw.arg: kw.value for kw in knoten.keywords}
    raise AssertionError("Kein Analysis(...)-Aufruf im Spec gefunden")


def _schritt_name(schritt: dict) -> str:
    return schritt.get("name") or (
        schritt.get("uses", "").split("/")[-1].split("@")[0] or "(run)"
    )


# ---------------------------------------------------------------------------
# Das Bau-Spec
# ---------------------------------------------------------------------------

class TestSpec:
    def test_datas_quellen_vorhanden(self):
        text = (PAKET / "helferverwaltung.spec").read_text(encoding="utf-8")
        datas = _analysis_kwargs(text)["datas"]
        assert isinstance(datas, ast.List) and datas.elts

        abhaengig_von_bau = {"app/templates", "app/static", "testdaten"}
        ziele = set()
        for element in datas.elts:
            assert isinstance(element, ast.Tuple) and len(element.elts) == 2
            # Das Ziel (zweites Argument) ist immer ein Stringliteral, z.B.
            # 'app/templates'. Die Quelle ist ein Pfadausdruck (PROJEKT/...)
            # und muss auf der Platte liegen, sonst scheitert der Build.
            ziel = ast.literal_eval(element.elts[1])
            ziele.add(ziel)
            if isinstance(element.elts[0], ast.Constant):
                assert Path(ast.literal_eval(element.elts[0])).exists()

        assert abhaengig_von_bau <= ziele, abhaengig_von_bau - ziele
        # Die Quellordner, auf die das Spec zeigt, existieren gefuellt.
        assert (PROJEKT / "app" / "templates").is_dir()
        assert (PROJEKT / "app" / "static").is_dir()

    def test_hiddenimports_importierbar(self):
        text = (PAKET / "helferverwaltung.spec").read_text(encoding="utf-8")
        hidden = _analysis_kwargs(text)["hiddenimports"]
        assert isinstance(hidden, ast.List) and hidden.elts
        for element in hidden.elts:
            name = ast.literal_eval(element)
            try:
                assert importlib.util.find_spec(name) is not None, name
            except (ImportError, ModuleNotFoundError) as fehler:
                raise AssertionError(f"hiddenimport nicht importierbar: {name}") from fehler

    def test_icon_und_versionsressource_referenziert(self):
        text = (PAKET / "helferverwaltung.spec").read_text(encoding="utf-8")
        assert "'helferverwaltung.ico'" in text
        assert "'version_info.txt'" in text
        assert (PAKET / "version_info.txt").is_file()
        # Die ICO-Datei ist ausgenommen und entsteht im Workflow. Ihr Erzeuger
        # und der des Testdaten-Pakets muessen deshalb vorhanden sein.
        assert (PAKET / "ico_erzeugen.py").is_file()
        assert (PAKET / "testdaten_erzeugen.py").is_file()
        assert (PAKET / "starter.py").is_file()


# ---------------------------------------------------------------------------
# Vorlagen und Statik, die in den Datenteil des Pakets muessen
# ---------------------------------------------------------------------------

class TestVorlagenUndStatik:
    def test_jede_route_vorlage_existiert(self):
        fehlend: list[str] = []
        for quelle in ROUTEN.glob("*.py"):
            baum = ast.parse(quelle.read_text(encoding="utf-8"))
            for knoten in ast.walk(baum):
                if isinstance(knoten, ast.Call):
                    funktion = knoten.func
                    if (
                        isinstance(funktion, ast.Attribute)
                        and funktion.attr == "TemplateResponse"
                        and knoten.args
                        and isinstance(knoten.args[0], ast.Constant)
                    ):
                        name = knoten.args[0].value
                        if not (VORLAGEN / name).is_file():
                            fehlend.append(f"{quelle.name}: {name}")
        assert not fehlend, "fehlende Vorlagen: " + ", ".join(fehlend)

    def test_statik_dateien_der_vorlagen_existieren(self):
        referenzen = set()
        for quelle in VORLAGEN.glob("*.html"):
            text = quelle.read_text(encoding="utf-8")
            referenzen.update(re.findall(r'/static/([A-Za-z0-9_.-]+)', text))
        fehlend = [r for r in referenzen if not (STATIK / r).is_file()]
        assert not fehlend, "fehlende Statik: " + ", ".join(fehlend)


# ---------------------------------------------------------------------------
# Die GitHub-Actions-Pipeline
# ---------------------------------------------------------------------------

class TestWorkflowYaml:
    def test_ausloeser_und_runner(self):
        daten, impulsen = _workflow_dict()
        assert "windows" in daten["jobs"]
        job = daten["jobs"]["windows"]
        assert job["runs-on"] == "windows-latest"
        assert "workflow_dispatch" in impulsen
        zweig = impulsen["push"]["branches"]
        assert "main" in zweig

    def test_reihenfolge_tests_dann_bau_dann_hochladen(self):
        daten, _ = _workflow_dict()
        namen = [_schritt_name(s) for s in daten["jobs"]["windows"]["steps"]]
        assert namen.index("Run tests") < namen.index("Build with PyInstaller")
        assert namen.index("Build with PyInstaller") < namen.index("Upload Windows artifact")

    def test_artefakt_heisst_windows_und_zeigt_auf_dist(self):
        daten, _ = _workflow_dict()
        upload = daten["jobs"]["windows"]["steps"][-1]
        assert upload["name"] == "Upload Windows artifact"
        assert upload["uses"] == "actions/upload-artifact@v4"
        assert upload["with"]["name"] == "windows"
        assert upload["with"]["if-no-files-found"] == "error"
        assert "dist/Helferverwaltung" in upload["with"]["path"]

    def test_workflow_pfade_existieren(self):
        text = WORKFLOW.read_text(encoding="utf-8")
        wurzel = PROJEKT.parent
        fehlend = []
        for relativ in (
            "Helferverwaltung/windows-paket/requirements-windows.txt",
            "Helferverwaltung/windows-paket/testdaten_erzeugen.py",
            "Helferverwaltung/windows-paket/ico_erzeugen.py",
            "Helferverwaltung/windows-paket/helferverwaltung.spec",
        ):
            if not (wurzel / relativ).exists():
                fehlend.append(f"{relativ} (fehlt auf der Platte)")
            if relativ not in text:
                fehlend.append(f"{relativ} (nicht im Workflow genannt)")
        assert not fehlend, "; ".join(fehlend)

    def test_testdaten_und_symbol_entstehen_vor_dem_bau(self):
        daten, _ = _workflow_dict()
        namen = [_schritt_name(s) for s in daten["jobs"]["windows"]["steps"]]
        bau = namen.index("Build with PyInstaller")
        assert namen.index("Generate test data") < bau
        assert namen.index("Generate EXE icon if missing") < bau

    def test_signierung_liest_aus_secrets_und_baut_ohne_unsigniert(self):
        text = WORKFLOW.read_text(encoding="utf-8")
        assert "WINDOWS_SIGN_CERT_BASE64" in text
        assert "secrets.WINDOWS_SIGN_CERT_BASE64" in text
        # Keine Zertifikatsdatei darf in den Workflow eingebettet sein.
        assert "MII" not in text
        # Das Verzeichnis fuer Signaturmaterial bleibt ausgenommen. Ein lokal
        # erzeugtes (unverfolgtes) Zertifikat ist erlaubt - es wird nie
        # eingecheckt.
        gitignore_text = (PROJEKT.parent / ".gitignore").read_text(encoding="utf-8")
        assert "windows-paket/zertifikat/" in gitignore_text


class TestAnforderungenBundling:
    def test_testdaten_erzeugen_baut_personal_bestandsaufnahme(self):
        # Der Name, den der Workflow nach dem Bau im Paket prueft, stammt aus
        # dem Erzeuger - beide muessen uebereinstimmen.
        erzeuger = (PAKET / "testdaten_erzeugen.py").read_text(encoding="utf-8")
        assert "Personal_Bestandsaufnahme.xlsx" in erzeuger
        starter = (PAKET / "starter.py").read_text(encoding="utf-8")
        assert "Personal_Bestandsaufnahme.xlsx" in starter