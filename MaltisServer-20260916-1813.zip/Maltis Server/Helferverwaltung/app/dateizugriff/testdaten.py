"""Automatisch erzeugte Beispieldaten fuer den Start ohne Konfiguration.

Startet die Anwendung frisch (noch keine .env, noch keine Arbeitskopie), dann
waere die Oberflaeche leer, bis der Sync-Ordner eingerichtet ist. Damit die
Anwendung sofort mit Inhalt startet, legt ``stelle_start_testdaten_bereit``
eine echte fuehrende Excel-Datei mit erfundenen Personen an - im Standardpfad
der Arbeitskopie, unter der die Anwendung auch im Normalbetrieb arbeitet.

Eine bereits vorhandene Datei wird niemals angefasst: Hier hat der Tester
entweder selbst Beispieldaten eingetragen oder einen echten Bestand gelegt.
"""

from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

from app.config import BLATT_AMU, BLATT_AUSGESCHIEDEN, BLATT_GRUPPE_1
from app.dateizugriff.schema import (
    ERWARTETE_SPALTEN,
    GF_NIKLAS,
    GF_NINO,
)


def _datum(heute: date, tage: int) -> date:
    return heute + timedelta(days=tage)


def _zeile(nr: int, name: str, **werte) -> list:
    """Eine Zeile im Aufbau von ``ERWARTETE_SPALTEN``."""
    z: dict[str, object] = {s: None for s in ERWARTETE_SPALTEN}
    z["Nr"], z["Name"] = nr, name
    z["Mitglied?"] = "y"
    z["Divera?"] = "y"
    z["Eigene Dienstkleidung"] = "y"
    z["Dienstausweis"] = "y"
    z["Freigaben abgeschlossen"] = "y"
    z["Masern"] = "y"
    z.update(werte)
    return [z.get(s) for s in ERWARTETE_SPALTEN]


def _erzeuge_mappe():
    """Baut eine fuenfkreisige Beispiel-Datei im realen Aufbau."""
    import openpyxl

    heute = date.today()

    mappe = openpyxl.Workbook()
    blatt = mappe.active
    blatt.title = BLATT_GRUPPE_1
    blatt.append(list(ERWARTETE_SPALTEN))

    blatt.append(_zeile(
        1, "Anna Beispiel",
        Status="aktiv", Telefon="0170 1234000", Medizinisch="n",
        **{"Jahresgespräch": heute,
           "RS Fortbildung": heute,
           "Fahrzeugeinweisung GwSan": "y",
           "Einweisung NTKW ZS": "y",
           "Unterweisung S/W-Rechte": heute,
           "Führerschein": "B",
           "G 26.2": _datum(heute, 400),
           "GF": GF_NIKLAS,
           "Dienstkleidung Größe": "M", "CBRN Kleidergröße": "L"},
    ))
    blatt.append(_zeile(
        2, "Ben Muster",
        Status="aktiv", Telefon="0170 1234001", Medizinisch="RS",
        **{"Jahresgespräch": heute,
           "RS Fortbildung": heute,
           "G 26.2": _datum(heute, -500),
           "GF": GF_NINO,
           "Dienstkleidung Größe": "L", "CBRN Kleidergröße": "XL"},
    ))
    blatt.append(_zeile(
        3, "Chris Test",
        Status="aktiv", Telefon="0170 1234002",
        **{"G 26.2": _datum(heute, -3 * 365)},
    ))
    blatt.append(_zeile(
        4, "Dora Demo",
        Status="passiv", Telefon="0170 1234003", Medizinisch="n",
        **{"Passiv seit": _datum(heute, -200),
           "Jahresgespräch": heute,
           "G 26.2": _datum(heute, 600),
           "GF": GF_NIKLAS,
           "Dienstkleidung Größe": "M", "CBRN Kleidergröße": "M"},
    ))
    blatt.append(_zeile(
        5, "Emil Probe",
        Status="aktiv", Telefon="0170 1234004", Medizinisch="RS",
        **{"Jahresgespräch": heute,
           "RS Fortbildung": heute,
           "Fahrzeugeinweisung GwSan": "y",
           "Einweisung NTKW ZS": "n",
           "Unterweisung S/W-Rechte": heute,
           "Führerschein": "B",
           "G 26.2": _datum(heute, 120),
           "GF": GF_NINO,
           "Dienstkleidung Größe": "XL", "CBRN Kleidergröße": "XL"},
    ))

    amu = mappe.create_sheet(BLATT_AMU)
    amu["A1"], amu["A2"], amu["A3"], amu["A4"], amu["A5"] = (
        "Abkürzung", "Bezeichnung", "Zielgruppe", "Turnus", "freiwillig?"
    )
    katalog = (
        ("G20", "Lichtschirmarbeit", "alle", "alle zwei Jahre", "n"),
        ("G24", "Haut", "alle", "alle zwei Jahre", "n"),
        ("G25", "Tätigkeit als Fahrer", "alle", "alle zwei Jahre", "n"),
        ("G 26.1", "Atemschutz 1", "alle", "alle zwei Jahre", "n"),
        ("G 26.2", "Atemschutz 2", "alle", "alle zwei Jahre", "n"),
        ("G 26.3", "Atemschutz 3", "alle", "alle zwei Jahre", "n"),
        ("G37", "Bürotätigkeit", "alle", "alle zwei Jahre", "n"),
        ("G42", "Pflege", "alle", "alle zwei Jahre", "n"),
    )
    for i, (abk, bez, ziel, turnus, frei) in enumerate(katalog, start=2):
        amu.cell(row=1, column=i).value = abk
        amu.cell(row=2, column=i).value = bez
        amu.cell(row=3, column=i).value = ziel
        amu.cell(row=4, column=i).value = turnus
        amu.cell(row=5, column=i).value = frei

    ausgeschieden = mappe.create_sheet(BLATT_AUSGESCHIEDEN)
    ausgeschieden.append(["Nr", "Name", "Austrittsdatum"])
    ausgeschieden.append([1, "Oma Test", _datum(heute, -300)])

    return mappe


def stelle_testdatei_bereit(ziel: Path) -> bool:
    """Legt die Beispiel-Datei an, sofern dort keine Datei liegt."""
    if ziel.exists():
        return False
    ziel.parent.mkdir(parents=True, exist_ok=True)
    mappe = _erzeuge_mappe()
    mappe.save(ziel)
    mappe.close()
    return True


def stelle_start_testdaten_bereit() -> None:
    """Bootstrap fuer den Start ohne Konfiguration (kein Netz, keine Pfade).

    Nur aktiv, wenn der Tester nicht bewusst einen HELFERDATEI_PFAD in der
    .env gesetzt hat und SharePoint (Graph) nicht laeuft. Erzeugt wird immer
    nur die Standard-Arbeitskopie, nie eine konfigurierte Datei.
    """
    from app.config import (
        HELFERDATEI_PFAD,
        HELFERDATEI_PFAD_ANGEBEN,
        graf_aktiv,
    )

    if HELFERDATEI_PFAD_ANGEBEN or graf_aktiv():
        return
    stelle_testdatei_bereit(HELFERDATEI_PFAD)